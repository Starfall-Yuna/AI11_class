﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza {

    public partial class ComponentControl : UserControl {

        public delegate int evtButton(object Sender, object aObject);   // delegate 선언
        public event evtButton OnClickDelete;
        private int m_Topping_price = 0;
        [Category("UserProperty"), Description("IngredientName")]

        public string IngredientName {
            get {
                return lbl_name.Text;// Convert.ToInt32(this.label_issue_num.Text);
            }
            set {
                lbl_name.Text = value;
            }
        }
        public int IngredientCode {
            get {
                return Convert.ToInt32(lbl_name.Tag);// Convert.ToInt32(this.label_issue_num.Text);
            }
            set {
                lbl_name.Tag = value;
            }
        }

        [Category("UserProperty"), Description("Consumption")]

        public int Consumption {
            get {
                return Convert.ToInt32(tbox_consumption.Text);// Convert.ToInt32(this.label_issue_num.Text);
            }
            set {
                tbox_consumption.Text = value.ToString();
            }
        }
        public ComponentControl() {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e) {

        }

        private void btn_delete_Click(object sender, EventArgs e) {

            if (OnClickDelete != null) {
                OnClickDelete(this, IngredientCode);
            }
        }
    }
}
