﻿using Lib.Frame;
using Lib.Util;
using Pizza.Manager;
using Pizza.Windows.Pop;
using Pizza.Windows.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza
{
    public partial class MainForm : Form
    {
        List<MasterView> m_Views = new List<MasterView>();
        DBManager m_dbManager = null;
        SessionManager m_sessionManager = null;
        public MainForm()
        {
            InitializeComponent();
            CreateObject();
            InitializeObject();
        }
        private void CreateObject()
        {
            m_dbManager = new DBManager();
            m_sessionManager = new SessionManager();
        }

        private void InitializeObject()
        {
            App.Self().MainForm = this;
            //ini파일에서 접속정보를 읽어서 app에 보관하기
            ReadIniFile();
            m_dbManager.SetConnectInfo(App.Self().db_addr, App.Self().db_port, App.Self().db_id, App.Self().db_pwd, App.Self().db_database);
            App.Self().DBManager = m_dbManager;
            App.Self().SessionManager = m_sessionManager;
            m_Views.Add(new DrinkView());
            m_Views.Add(new OrderView());
            m_Views.Add(new SupplyView());
            m_Views.Add(new MemberView());
            m_Views.Add(new InventoryView());
            m_Views.Add(new SalesView());
        }

        private void ReadIniFile()
        {
            IniAssist _iniAssist = new IniAssist();
            _iniAssist.Path = System.IO.Directory.GetCurrentDirectory() + "/information.ini";
            App.Self().db_addr = _iniAssist.ReadString("db", "addr");
            App.Self().db_port = _iniAssist.ReadInteger("db", "port");
            App.Self().db_id = _iniAssist.ReadString("db", "id");
            App.Self().db_pwd = _iniAssist.ReadString("db", "pwd");
            App.Self().db_database = _iniAssist.ReadString("db", "database");
        }
        private MasterView ShowView(Type aType)
        {
            MasterView _currentView = null;
            foreach (MasterView view in m_Views)
            {
                if (view.GetType() == aType)
                {
                    view.Parent = ViewBase;
                    view.Dock = DockStyle.Fill;
                    view.Visible = true;
                    _currentView = view;
                }
                else
                {
                    view.Visible = false;
                }
            }
            return _currentView;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_order_Click(object sender, EventArgs e)
        {
            MasterView _view = ShowView(typeof(OrderView));
            //_view.InitializeView("menu_kind", "normal");

        }

        private void btn_drink_Click(object sender, EventArgs e)
        {
            MasterView _view = ShowView(typeof(DrinkView));
            //_view.InitializeView("menu_kind", "drink");
        }
        private void btn_sup_Click(object sender, EventArgs e) {
            MasterView _view = ShowView(typeof(SupplyView));
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            AddMenuPop _pop = new AddMenuPop();
            _pop.ShowDialog(this);

            MasterView _view = ShowView(typeof(OrderView));
            _view.InitializeView("", "");
        }

        private void btn_logIn_Click(object sender, EventArgs e)
        {
            LogInPop _pop = new LogInPop();
            _pop.ShowDialog(this);
        }

        private void btn_option_Click(object sender, EventArgs e)
        {
            SetupPop _pop = new SetupPop();
            DialogResult _dr = _pop.ShowDialog();
            if (_dr == DialogResult.OK)
            {
                //17
                App.Self().db_addr = _pop.Addr;
                App.Self().db_port = _pop.Port;
                App.Self().db_id = _pop.Id;
                App.Self().db_pwd = _pop.Pwd;
                App.Self().db_database = _pop.Database;
                m_dbManager.SetConnectInfo(App.Self().db_addr,
                    App.Self().db_port, App.Self().db_id, App.Self().db_pwd, App.Self().db_database);
            }
        }

        private void btn_member_Click(object sender, EventArgs e) {
            MemberCheckPop _mbrpop = new MemberCheckPop();
            _mbrpop.ShowPop(ePopMode.None);
        }

        private void btn_kiosk_Click(object sender, EventArgs e) {
            KioskPop _pop = new KioskPop();
            _pop.ShowPop(ePopMode.None);
        }
    }
}
