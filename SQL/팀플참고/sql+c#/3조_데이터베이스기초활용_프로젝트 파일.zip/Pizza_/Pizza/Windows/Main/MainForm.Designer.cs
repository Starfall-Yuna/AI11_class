﻿namespace Pizza
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.oven4 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.oven3 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.oven2 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btn_option = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_order = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btn_kiosk = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_member = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_sup = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_logIn = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.oven1 = new System.Windows.Forms.Label();
            this.ViewBase = new System.Windows.Forms.Panel();
            this.btn_add = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1081, 50);
            this.panel1.TabIndex = 3;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 11;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.555555F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.555555F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.555555F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.555555F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.panel13, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel12, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel11, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel9, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel8, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel10, 7, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1081, 50);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.oven4);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(1023, 3);
            this.panel13.Name = "panel13";
            this.panel13.Padding = new System.Windows.Forms.Padding(3);
            this.panel13.Size = new System.Drawing.Size(55, 44);
            this.panel13.TabIndex = 16;
            // 
            // oven4
            // 
            this.oven4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.oven4.Location = new System.Drawing.Point(3, 3);
            this.oven4.Name = "oven4";
            this.oven4.Size = new System.Drawing.Size(49, 38);
            this.oven4.TabIndex = 0;
            this.oven4.Text = "오븐4";
            this.oven4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.oven3);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(963, 3);
            this.panel12.Name = "panel12";
            this.panel12.Padding = new System.Windows.Forms.Padding(3);
            this.panel12.Size = new System.Drawing.Size(54, 44);
            this.panel12.TabIndex = 15;
            // 
            // oven3
            // 
            this.oven3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.oven3.Location = new System.Drawing.Point(3, 3);
            this.oven3.Name = "oven3";
            this.oven3.Size = new System.Drawing.Size(48, 38);
            this.oven3.TabIndex = 0;
            this.oven3.Text = "오븐3";
            this.oven3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.oven2);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(903, 3);
            this.panel11.Name = "panel11";
            this.panel11.Padding = new System.Windows.Forms.Padding(3);
            this.panel11.Size = new System.Drawing.Size(54, 44);
            this.panel11.TabIndex = 14;
            // 
            // oven2
            // 
            this.oven2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.oven2.Location = new System.Drawing.Point(3, 3);
            this.oven2.Name = "oven2";
            this.oven2.Size = new System.Drawing.Size(48, 38);
            this.oven2.TabIndex = 0;
            this.oven2.Text = "오븐2";
            this.oven2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btn_option);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(723, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(114, 44);
            this.panel9.TabIndex = 12;
            // 
            // btn_option
            // 
            this.btn_option.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_option.Location = new System.Drawing.Point(0, 0);
            this.btn_option.Name = "btn_option";
            this.btn_option.Size = new System.Drawing.Size(114, 44);
            this.btn_option.TabIndex = 0;
            this.btn_option.Text = "환경설정";
            this.btn_option.UseVisualStyleBackColor = true;
            this.btn_option.Click += new System.EventHandler(this.btn_option_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btn_order);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(3, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(114, 44);
            this.panel8.TabIndex = 8;
            // 
            // btn_order
            // 
            this.btn_order.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_order.Location = new System.Drawing.Point(0, 0);
            this.btn_order.Name = "btn_order";
            this.btn_order.Size = new System.Drawing.Size(114, 44);
            this.btn_order.TabIndex = 0;
            this.btn_order.Text = "주문";
            this.btn_order.UseVisualStyleBackColor = true;
            this.btn_order.Click += new System.EventHandler(this.btn_order_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btn_kiosk);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(483, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(114, 44);
            this.panel7.TabIndex = 4;
            // 
            // btn_kiosk
            // 
            this.btn_kiosk.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_kiosk.Location = new System.Drawing.Point(0, 0);
            this.btn_kiosk.Name = "btn_kiosk";
            this.btn_kiosk.Size = new System.Drawing.Size(114, 44);
            this.btn_kiosk.TabIndex = 0;
            this.btn_kiosk.Text = "키오스크";
            this.btn_kiosk.UseVisualStyleBackColor = true;
            this.btn_kiosk.Click += new System.EventHandler(this.btn_kiosk_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btn_member);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(363, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(114, 44);
            this.panel6.TabIndex = 3;
            // 
            // btn_member
            // 
            this.btn_member.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_member.Location = new System.Drawing.Point(0, 0);
            this.btn_member.Name = "btn_member";
            this.btn_member.Size = new System.Drawing.Size(114, 44);
            this.btn_member.TabIndex = 0;
            this.btn_member.Text = "회원관리";
            this.btn_member.UseVisualStyleBackColor = true;
            this.btn_member.Click += new System.EventHandler(this.btn_member_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btn_sup);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(243, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(114, 44);
            this.panel5.TabIndex = 2;
            // 
            // btn_sup
            // 
            this.btn_sup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_sup.Location = new System.Drawing.Point(0, 0);
            this.btn_sup.Name = "btn_sup";
            this.btn_sup.Size = new System.Drawing.Size(114, 44);
            this.btn_sup.TabIndex = 0;
            this.btn_sup.Text = "재고 및 매출 관리";
            this.btn_sup.UseVisualStyleBackColor = true;
            this.btn_sup.Click += new System.EventHandler(this.btn_sup_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_logIn);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(603, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(114, 44);
            this.panel2.TabIndex = 11;
            // 
            // btn_logIn
            // 
            this.btn_logIn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_logIn.Location = new System.Drawing.Point(0, 0);
            this.btn_logIn.Name = "btn_logIn";
            this.btn_logIn.Size = new System.Drawing.Size(114, 44);
            this.btn_logIn.TabIndex = 0;
            this.btn_logIn.Text = "로그인";
            this.btn_logIn.UseVisualStyleBackColor = true;
            this.btn_logIn.Click += new System.EventHandler(this.btn_logIn_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.oven1);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(843, 3);
            this.panel10.Name = "panel10";
            this.panel10.Padding = new System.Windows.Forms.Padding(3);
            this.panel10.Size = new System.Drawing.Size(54, 44);
            this.panel10.TabIndex = 13;
            // 
            // oven1
            // 
            this.oven1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.oven1.Location = new System.Drawing.Point(3, 3);
            this.oven1.Name = "oven1";
            this.oven1.Size = new System.Drawing.Size(48, 38);
            this.oven1.TabIndex = 0;
            this.oven1.Text = "오븐1";
            this.oven1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ViewBase
            // 
            this.ViewBase.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ViewBase.Location = new System.Drawing.Point(0, 50);
            this.ViewBase.Name = "ViewBase";
            this.ViewBase.Size = new System.Drawing.Size(1081, 548);
            this.ViewBase.TabIndex = 4;
            // 
            // btn_add
            // 
            this.btn_add.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_add.Location = new System.Drawing.Point(0, 0);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(114, 44);
            this.btn_add.TabIndex = 0;
            this.btn_add.Text = "메뉴추가";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btn_add);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(123, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(114, 44);
            this.panel4.TabIndex = 1;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1081, 598);
            this.Controls.Add(this.ViewBase);
            this.Controls.Add(this.panel1);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btn_order;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btn_kiosk;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btn_member;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_sup;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_logIn;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label oven4;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label oven3;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label oven2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btn_option;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label oven1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Panel ViewBase;
    }
}

