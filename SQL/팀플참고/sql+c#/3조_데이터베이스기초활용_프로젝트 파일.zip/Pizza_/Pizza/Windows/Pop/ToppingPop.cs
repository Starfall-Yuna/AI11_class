﻿using Lib.Frame;
using Pizza.Manager;
using Pizza.Windows.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza.Windows.Pop
{
    public partial class ToppingPop : MasterPop
    {
        private int _iBuffer = 1;
        private int m_btn_width = 100;
        private int m_btn_height = 100;
        public ToppingPop()
        {
            InitializeComponent();
            InitializeMenu();
        }

        private void InitializeMenu()
        {
            DataTable _dt = App.Self().DBManager.ReadTopping();
            if (_dt != null)
            {
                panel_goods.Controls.Clear();
                foreach (DataRow _dr in _dt.Rows)
                {
                    int _price = 0;
                    if (_dr["it_Price"] != DBNull.Value)
                    {
                        _price = Convert.ToInt32(_dr["it_Price"]);
                    }

                    AddButton(_dr["it_Name"].ToString(), _price);
                }

            }
        }
        private void AddButton(string aGoodsName, int aPrice)
        {
            Button _btn_ = new Button();
            _btn_.Size = new Size(m_btn_width, m_btn_height);
            //_btn_.BackColor = Color.Aqua;

            _btn_.Tag = new GoodsInfo(aGoodsName, aPrice);
            _btn_.BackgroundImage = Properties.Resources.pizza_0;
            _btn_.BackgroundImageLayout = ImageLayout.Stretch;
            _iBuffer += 3;
            _btn_.Paint += _pizza__Paint;
            _btn_.Click += _btn__Click;
            panel_goods.Controls.Add(_btn_);

            int _goods_count = panel_goods.Controls.Count;
            int _goods_width = panel_goods.Width;
            int _current_goods_index = _goods_count - 1;
            int _column_count = _goods_width / m_btn_width;
            int _row_index = _current_goods_index / _column_count;
            panel_goods.Height = m_btn_height * (_row_index + 1);

            ReLayout();
        }

        private void ReLayout()
        {
            int _goods_count = panel_goods.Controls.Count;
            int _goods_width = panel_goods.Width;
            int _current_goods_index = _goods_count - 1;
            int _column_count = _goods_width / m_btn_width;
            int _index = 0;
            foreach (object item in panel_goods.Controls)
            {
                Button _btn_ = item as Button;
                if (_btn_ != null)
                {
                    int _row_index = _index / _column_count;
                    int _col_index = _index % _column_count;
                    _btn_.Location = new Point(_col_index * m_btn_width, _row_index * m_btn_height);
                    _index++;
                }
            }
        }
        private void panel_goods_Resize(object sender, EventArgs e)
        {
            ReLayout();
        }
        private void _pizza__Paint(object sender, PaintEventArgs e)
        {
            StringFormat _fmt = new StringFormat();
            _fmt.Alignment = StringAlignment.Center;
            _fmt.LineAlignment = StringAlignment.Center;
            Button _btn_ = sender as Button;
            Graphics _g = e.Graphics;
            GoodsInfo _info = _btn_.Tag as GoodsInfo;
            if (_info != null)
            {
                _g.DrawString(_info.GoodsName, this.Font, Brushes.Red, new Rectangle(0, 50, 100, 25), _fmt);

                using (Pen pen = new Pen(Color.White, 2))
                {
                    Rectangle _rc = new Rectangle(0, 75, 100, 25);
                    _rc.Offset(1, 1);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(-2, 0);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(0, -2);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(2, 0);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(-1, 1);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, pen.Brush, _rc, _fmt);
                }
                //_g.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Red, ,_fmt);
            }
        }
        private void _btn__Click(object sender, EventArgs e)
        {
            Button _btn_ = sender as Button;
            if (_btn_ != null)
            {
                string _msg;
                GoodsInfo _info = _btn_.Tag as GoodsInfo;
                if (_info != null)
                {
                    _msg = _info.GoodsName + "\n" + _info.GoodsPrice.ToString();
                    MessageBox.Show(_msg);
                }
            }
        }
    }
    public class GoodsInfo
    {
        public string GoodsName { get; set; }
        public int GoodsPrice { get; set; }
        public GoodsInfo() { }
        public GoodsInfo(string aGoodsName, int aGoodsPrice)
        {
            GoodsName = aGoodsName;
            GoodsPrice = aGoodsPrice;
        }
    }
}
