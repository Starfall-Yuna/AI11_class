﻿using Lib.Control;
using Lib.Frame;
using Pizza.Manager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza.Windows.Pop {
    public partial class Ingreident : MasterPop {
        public Ingreident() {
            InitializeComponent();
            InitializeControl();
        }
        private void InitializeControl() {
            //장르 콤보박스초기화

            DataTable _dt = App.Self().DBManager.ReadIngredient5("");
          
            foreach (DataRow _dr in _dt.Rows) {
                string _idg_code = Convert.ToString(_dr["idg_code"]);
                string _idg_name = Convert.ToString(_dr["idg_name"]);
                
            }
            if (_dt.Rows.Count > 0) {
               
            }
        }
        public override void Initialize(ePopMode popMode, object aParam) {
            base.Initialize(popMode, aParam);
            SetLayout(aParam);
            DoSearchIngredient();
        }
        private void SetLayout(object aParam) {
            cbox_idg_kind.SelectedIndex = 0;

        }
        private void DoSearchIngredient() {

            int _idg_kind = cbox_idg_kind.SelectedIndex;
            string _idg_seed = tbox_idg_seed.Text;
            DataTable _dt = null;
            if (_idg_kind == 0) {
                _dt = App.Self().DBManager.ReadIngredient2(_idg_seed);
            }
            else if (_idg_kind == 1) {
                _dt = App.Self().DBManager.ReadIngredient2(_idg_seed);
            }
            if (_dt != null) {
                DataTable _dtidg = DisplaySet.Tables["dp_idg"];
                _dtidg.Rows.Clear();
                foreach (DataRow row in _dt.Rows) {
                    DataRow dtrow = _dtidg.NewRow();
                    dtrow["idg_code"] = row["idg_code"];
                    dtrow["idg_name"] = row["idg_name"];
                    dtrow["idg_unit"] = row["idg_unit"];
                    dtrow["idg_stock"] = row["idg_stock"];
                    _dtidg.Rows.Add(dtrow);
                }
            }
        }
        private void label2_Click(object sender, EventArgs e) {

        }

        private void tbox_name_TextChanged(object sender, EventArgs e) {

        }

        private void tbox_gram_TextChanged(object sender, EventArgs e) {

        }

        private void tbox_code_TextChanged(object sender, EventArgs e) {

        }



        private void Ingreident_Load(object sender, EventArgs e) {
            tbox_name.ReadOnly = true;
            tbox_gram.ReadOnly = true;
            //tbox_code.ReadOnly = true;
            tbox_eag.ReadOnly = true;
        }

        private void btn_add_Click_1(object sender, EventArgs e) {
            int num = Convert.ToInt32(btn_add.Tag);
            if (num == 1) {
                tbox_name.ReadOnly = false;
                tbox_gram.ReadOnly = false;
                //tbox_code.ReadOnly = false;
                tbox_eag.ReadOnly = false;
                btn_add.Tag = 2;
            }
        }
        private bool ValidateTest() {
            bool _result = true;
            string _msg = "";
            if (tbox_name.Text.Length <= 0) {
                if (_msg.Length == 0) { tbox_name.Focus(); }
                else { _msg += "\r\n"; }
                _msg += "재료명을 입력해주세요.";
            }
         /*   if (tbox_gram.Text.Length <= 0) {
                if (_msg.Length == 0) { tbox_gram.Focus(); }
                else { _msg += "\r\n"; }
                _msg += "입고무게를 입력해주세요";
            }*/
           /* if (tbox_code.Text.Length <= 0) {
                if (_msg.Length == 0) { tbox_code.Focus(); }
                else { _msg += "\r\n"; }
                _msg += "코드를 입력해주세요";
            }*/
            if (_msg.Length > 0) {
                _result = false;
                MessageBox.Show(_msg);
            }
            return _result;
        }
        private void btn_save_Click(object sender, EventArgs e) {
            int num = Convert.ToInt32(btn_add.Tag);
            if (num == 2) {
                if (MessageBox.Show("변경사항을 저장하시겠습니까?", "확인", MessageBoxButtons.YesNo) == DialogResult.Yes) {
                    if (ValidateTest()) {
                        string idg_name = tbox_name.Text;
                        int idg_price = Convert.ToInt32(tbox_gram.Text);
                        //string idg_code = tbox_code.Text;
                        string idg_eag = tbox_eag.Text;
                        string idg_picture = "";
                        if (pbox_picture_sp.Tag != null) {
                            idg_picture = pbox_picture_sp.Tag.ToString();
                        }



                        int _result = App.Self().DBManager.AddIngr(idg_name,idg_price , idg_eag, idg_picture);
                        if (_result > 0) {
                            MessageBox.Show("저장되었습니다.");
                        }
                        else {
                            MessageBox.Show("저장이 실패하였습니다.");
                        }
                    }
                }
                else {
                    MessageBox.Show("취소되었습니다.");
                }
                

            }
        
        }

        private void btn_format_Click(object sender, EventArgs e) {
            tbox_name.Text = "";
            tbox_gram.Text = "";
            //tbox_code.Text = "";
        }

        private void btn_file_sp_Click(object sender, EventArgs e) {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "PNG|*.png|JPG|*.jpg|BMP|*.bmp|all files|*.*";
            ofd.InitialDirectory = Application.StartupPath;
            if (ofd.ShowDialog() == DialogResult.OK) {
                pbox_picture_sp.Image = Bitmap.FromFile(ofd.FileName);

                FileStream fs = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read); ;
                byte[] bImage = new byte[fs.Length];
                fs.Read(bImage, 0, (int)fs.Length);

                StringBuilder hex = new StringBuilder(bImage.Length * 2);
                foreach (byte b in bImage) {
                    hex.AppendFormat("{0:X2}", b);
                }
                string _hex_image = hex.ToString();
                //MessageBox.Show(_hex_image);
                pbox_picture_sp.Tag = _hex_image;
            }
        }

        private void cbox_unit_SelectedIndexChanged(object sender, EventArgs e) {

        }
    }
}
