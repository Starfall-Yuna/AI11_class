﻿namespace Pizza.Windows.Pop
{
    partial class MemberCheckPop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.btn_format = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.tbox_addr = new System.Windows.Forms.TextBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.tbox_phone = new System.Windows.Forms.TextBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.tbox_id = new System.Windows.Forms.TextBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.tbox_name = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.grid_member = new System.Windows.Forms.DataGridView();
            this.mbrcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mbrnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mbridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mbrphoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mbraddrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DisplaySet = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbox_member_seed = new System.Windows.Forms.TextBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.btn_add_staff = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.cbtn_search_member = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.cbox_member_kind = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_member)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            this.panel5.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(516, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(284, 450);
            this.panel1.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel4);
            this.groupBox2.Controls.Add(this.panel21);
            this.groupBox2.Controls.Add(this.panel7);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(8);
            this.groupBox2.Size = new System.Drawing.Size(284, 450);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "회원조회";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(8, 183);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.panel4.Size = new System.Drawing.Size(268, 229);
            this.panel4.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.DataMember = "dp_staff";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 5);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowHeadersWidth = 20;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(262, 221);
            this.dataGridView1.TabIndex = 0;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel21.Location = new System.Drawing.Point(8, 412);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(268, 30);
            this.panel21.TabIndex = 2;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.btn_format);
            this.panel22.Controls.Add(this.btn_save);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel22.Location = new System.Drawing.Point(80, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(188, 30);
            this.panel22.TabIndex = 0;
            // 
            // btn_format
            // 
            this.btn_format.Enabled = false;
            this.btn_format.Location = new System.Drawing.Point(100, 3);
            this.btn_format.Name = "btn_format";
            this.btn_format.Size = new System.Drawing.Size(74, 22);
            this.btn_format.TabIndex = 4;
            this.btn_format.Text = "취소";
            this.btn_format.UseVisualStyleBackColor = true;
            this.btn_format.Click += new System.EventHandler(this.btn_format_Click);
            // 
            // btn_save
            // 
            this.btn_save.Enabled = false;
            this.btn_save.Location = new System.Drawing.Point(20, 3);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(74, 22);
            this.btn_save.TabIndex = 3;
            this.btn_save.Text = "수정";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.tableLayoutPanel2);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(8, 22);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(268, 161);
            this.panel7.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel20, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.panel19, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.panel15, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.panel14, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.panel13, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel12, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel11, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel10, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(268, 161);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.tbox_addr);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(103, 123);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(162, 35);
            this.panel20.TabIndex = 9;
            // 
            // tbox_addr
            // 
            this.tbox_addr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_addr.Location = new System.Drawing.Point(0, 0);
            this.tbox_addr.Name = "tbox_addr";
            this.tbox_addr.Size = new System.Drawing.Size(162, 21);
            this.tbox_addr.TabIndex = 2;
            this.tbox_addr.TextChanged += new System.EventHandler(this.tbox_addr_TextChanged);
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.label5);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(3, 123);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(94, 35);
            this.panel19.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 35);
            this.label5.TabIndex = 1;
            this.label5.Text = "주소";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.tbox_phone);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(103, 83);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(162, 34);
            this.panel15.TabIndex = 7;
            // 
            // tbox_phone
            // 
            this.tbox_phone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_phone.Location = new System.Drawing.Point(0, 0);
            this.tbox_phone.Name = "tbox_phone";
            this.tbox_phone.Size = new System.Drawing.Size(162, 21);
            this.tbox_phone.TabIndex = 2;
            this.tbox_phone.TextChanged += new System.EventHandler(this.tbox_phone_TextChanged);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label4);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(3, 83);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(94, 34);
            this.panel14.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 34);
            this.label4.TabIndex = 1;
            this.label4.Text = "번호";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.tbox_id);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(103, 43);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(162, 34);
            this.panel13.TabIndex = 5;
            // 
            // tbox_id
            // 
            this.tbox_id.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_id.Location = new System.Drawing.Point(0, 0);
            this.tbox_id.Name = "tbox_id";
            this.tbox_id.Size = new System.Drawing.Size(162, 21);
            this.tbox_id.TabIndex = 2;
            this.tbox_id.TextChanged += new System.EventHandler(this.tbox_id_TextChanged);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label3);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(3, 43);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(94, 34);
            this.panel12.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 34);
            this.label3.TabIndex = 1;
            this.label3.Text = "ID";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.tbox_name);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(103, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(162, 34);
            this.panel11.TabIndex = 3;
            // 
            // tbox_name
            // 
            this.tbox_name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_name.Location = new System.Drawing.Point(0, 0);
            this.tbox_name.Name = "tbox_name";
            this.tbox_name.Size = new System.Drawing.Size(162, 21);
            this.tbox_name.TabIndex = 2;
            this.tbox_name.TextChanged += new System.EventHandler(this.tbox_name_TextChanged);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label2);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(94, 34);
            this.panel10.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 34);
            this.label2.TabIndex = 1;
            this.label2.Text = "이름";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(516, 450);
            this.panel2.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel6);
            this.groupBox1.Controls.Add(this.panel5);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(8);
            this.groupBox1.Size = new System.Drawing.Size(516, 450);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "회원조회";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.grid_member);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(8, 50);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.panel6.Size = new System.Drawing.Size(500, 392);
            this.panel6.TabIndex = 1;
            // 
            // grid_member
            // 
            this.grid_member.AllowUserToAddRows = false;
            this.grid_member.AllowUserToDeleteRows = false;
            this.grid_member.AutoGenerateColumns = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_member.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.grid_member.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_member.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mbrcodeDataGridViewTextBoxColumn,
            this.mbrnameDataGridViewTextBoxColumn,
            this.mbridDataGridViewTextBoxColumn,
            this.mbrphoneDataGridViewTextBoxColumn,
            this.mbraddrDataGridViewTextBoxColumn});
            this.grid_member.DataMember = "dp_mbr";
            this.grid_member.DataSource = this.DisplaySet;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_member.DefaultCellStyle = dataGridViewCellStyle5;
            this.grid_member.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_member.Location = new System.Drawing.Point(3, 5);
            this.grid_member.MultiSelect = false;
            this.grid_member.Name = "grid_member";
            this.grid_member.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_member.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.grid_member.RowHeadersWidth = 20;
            this.grid_member.RowTemplate.Height = 23;
            this.grid_member.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_member.Size = new System.Drawing.Size(494, 384);
            this.grid_member.TabIndex = 0;
            this.grid_member.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_member_CellContentClick);
            this.grid_member.SelectionChanged += new System.EventHandler(this.grid_member_SelectionChanged);
            // 
            // mbrcodeDataGridViewTextBoxColumn
            // 
            this.mbrcodeDataGridViewTextBoxColumn.DataPropertyName = "mbr_code";
            this.mbrcodeDataGridViewTextBoxColumn.HeaderText = "mbr_code";
            this.mbrcodeDataGridViewTextBoxColumn.Name = "mbrcodeDataGridViewTextBoxColumn";
            this.mbrcodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.mbrcodeDataGridViewTextBoxColumn.Visible = false;
            // 
            // mbrnameDataGridViewTextBoxColumn
            // 
            this.mbrnameDataGridViewTextBoxColumn.DataPropertyName = "mbr_name";
            this.mbrnameDataGridViewTextBoxColumn.HeaderText = "회원이름";
            this.mbrnameDataGridViewTextBoxColumn.Name = "mbrnameDataGridViewTextBoxColumn";
            this.mbrnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // mbridDataGridViewTextBoxColumn
            // 
            this.mbridDataGridViewTextBoxColumn.DataPropertyName = "mbr_id";
            this.mbridDataGridViewTextBoxColumn.HeaderText = "회원 아이디";
            this.mbridDataGridViewTextBoxColumn.Name = "mbridDataGridViewTextBoxColumn";
            this.mbridDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // mbrphoneDataGridViewTextBoxColumn
            // 
            this.mbrphoneDataGridViewTextBoxColumn.DataPropertyName = "mbr_phone";
            this.mbrphoneDataGridViewTextBoxColumn.HeaderText = "회원번호";
            this.mbrphoneDataGridViewTextBoxColumn.Name = "mbrphoneDataGridViewTextBoxColumn";
            this.mbrphoneDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // mbraddrDataGridViewTextBoxColumn
            // 
            this.mbraddrDataGridViewTextBoxColumn.DataPropertyName = "mbr_addr";
            this.mbraddrDataGridViewTextBoxColumn.HeaderText = "회원 주소";
            this.mbraddrDataGridViewTextBoxColumn.Name = "mbraddrDataGridViewTextBoxColumn";
            this.mbraddrDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // DisplaySet
            // 
            this.DisplaySet.DataSetName = "NewDataSet";
            this.DisplaySet.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4,
            this.dataColumn5});
            this.dataTable1.TableName = "dp_mbr";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "mbr_code";
            this.dataColumn1.DataType = typeof(int);
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "mbr_name";
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "mbr_id";
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "mbr_phone";
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "mbr_addr";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tableLayoutPanel1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(8, 22);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(500, 28);
            this.panel5.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel18, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel17, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel16, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(500, 28);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbox_member_seed);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(103, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(234, 22);
            this.panel3.TabIndex = 3;
            // 
            // tbox_member_seed
            // 
            this.tbox_member_seed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_member_seed.Location = new System.Drawing.Point(0, 0);
            this.tbox_member_seed.Name = "tbox_member_seed";
            this.tbox_member_seed.Size = new System.Drawing.Size(234, 21);
            this.tbox_member_seed.TabIndex = 1;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.btn_add_staff);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(423, 3);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(74, 22);
            this.panel18.TabIndex = 2;
            // 
            // btn_add_staff
            // 
            this.btn_add_staff.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_add_staff.Location = new System.Drawing.Point(0, 0);
            this.btn_add_staff.Name = "btn_add_staff";
            this.btn_add_staff.Size = new System.Drawing.Size(74, 22);
            this.btn_add_staff.TabIndex = 2;
            this.btn_add_staff.Text = "추가";
            this.btn_add_staff.UseVisualStyleBackColor = true;
            this.btn_add_staff.Click += new System.EventHandler(this.btn_add_staff_Click);
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.cbtn_search_member);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(343, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(74, 22);
            this.panel17.TabIndex = 1;
            // 
            // cbtn_search_member
            // 
            this.cbtn_search_member.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbtn_search_member.Location = new System.Drawing.Point(0, 0);
            this.cbtn_search_member.Name = "cbtn_search_member";
            this.cbtn_search_member.Size = new System.Drawing.Size(74, 22);
            this.cbtn_search_member.TabIndex = 2;
            this.cbtn_search_member.Text = "조회";
            this.cbtn_search_member.UseVisualStyleBackColor = true;
            this.cbtn_search_member.Click += new System.EventHandler(this.cbtn_search_member_Click);
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.cbox_member_kind);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(3, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(94, 22);
            this.panel16.TabIndex = 0;
            // 
            // cbox_member_kind
            // 
            this.cbox_member_kind.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbox_member_kind.FormattingEnabled = true;
            this.cbox_member_kind.Items.AddRange(new object[] {
            "회원이름",
            "회원아이디"});
            this.cbox_member_kind.Location = new System.Drawing.Point(0, 0);
            this.cbox_member_kind.Name = "cbox_member_kind";
            this.cbox_member_kind.Size = new System.Drawing.Size(94, 20);
            this.cbox_member_kind.TabIndex = 0;
            this.cbox_member_kind.SelectedIndexChanged += new System.EventHandler(this.cbox_member_kind_SelectedIndexChanged);
            // 
            // MemberCheckPop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "MemberCheckPop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MemberCheckPop";
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_member)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox tbox_addr;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox tbox_phone;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox tbox_id;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox tbox_name;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView grid_member;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbox_member_seed;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Button btn_add_staff;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button cbtn_search_member;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.ComboBox cbox_member_kind;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Button btn_format;
        private System.Windows.Forms.Button btn_save;
        private System.Data.DataSet DisplaySet;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn mbrcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mbrnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mbridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mbrphoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mbraddrDataGridViewTextBoxColumn;
    }
}