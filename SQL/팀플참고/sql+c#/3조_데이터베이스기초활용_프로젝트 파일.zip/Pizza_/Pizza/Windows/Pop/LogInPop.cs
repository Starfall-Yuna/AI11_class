﻿using Lib.Frame;
using Pizza.Manager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza.Windows.Pop
{
    public partial class LogInPop : MasterPop
    {
        public LogInPop()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string _login_id = tBox_ID.Text;
            string _login_pwd = tBox_Pwd.Text;
            DataTable _db_staff = App.Self().DBManager.ReadStaff(_login_id, _login_pwd);
            if (_db_staff != null)
            {
                if (_db_staff.Rows.Count > 0)
                {
                    DataRow _row = _db_staff.Rows[0];
                    string _id = Convert.ToString(_row["stf_id"]);
                    int _chk_pwd = Convert.ToInt32(_row["chk_pwd"]);
                    if (_chk_pwd != 1)
                    {
                        MessageBox.Show("비밀번호가 틀립니다.");
                    }
                    else
                    {
                        MessageBox.Show("로그인 하였습니다.");
                        DialogResult = DialogResult.OK;
                    }
                }
                else
                {
                    MessageBox.Show("해당아이디는 없습니다.");
                }
            }
        }
    }
}
