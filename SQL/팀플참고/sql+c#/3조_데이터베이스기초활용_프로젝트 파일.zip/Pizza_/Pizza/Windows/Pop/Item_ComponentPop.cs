﻿using Lib.Frame;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Pizza.Windows.Pop {
    public partial class Item_ComponentPop : MasterPop {
        
        public Item_ComponentPop() {
            InitializeComponent();
            resize_scroll();
        }

        private void Item_ComponentPop_Load(object sender, EventArgs e) {
        }
        public override void Initialize(ePopMode popMode, object aParam) {
            m_PopMode = popMode;
            DataRow[] _rows = aParam as DataRow[];
            int _idx = 0;
            foreach (DataRow row in _rows) {
                ComponentControl _ctrl = new ComponentControl();
                pnl_base.Controls.Add(_ctrl);
                _ctrl.Width = pnl_base.Width;
                _ctrl.Location = new Point(0, _idx * 30);
                _ctrl.IngredientName = row["idg_name"].ToString();
                _ctrl.IngredientCode = Convert.ToInt32(row["idg_code"]);
                _ctrl.Consumption = 0;
                _idx++;
            }
            pnl_base.Height = _idx * 30;
        }

        private void pnl_scorll_Resize(object sender, EventArgs e) {
            resize_scroll();
        }

        private void resize_scroll() {
            if (pnl_base.Height > pnl_scorll.Height) {
                pnl_base.Width = pnl_scorll.Width - 25;
            }
            else {

                pnl_base.Width = pnl_scorll.Width;
            }

        }

        private void btn_save_cp_Click(object sender, EventArgs e) {
            foreach (object _obj in pnl_base.Controls) { 
                ComponentControl ctrl = _obj as ComponentControl;
                if(ctrl != null) {
                    //string _a = ctrl.IngredientName;
                    int idg_code = ctrl.IngredientCode;
                    int _s = ctrl.Consumption;     
                    
                }
            }
        }
    }
}
