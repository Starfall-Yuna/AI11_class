﻿using Lib.Control;
using Lib.Frame;

using Pizza.Manager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza.Windows.Pop {
    public partial class Ingreident_Add : MasterPop {
        private int m_seq_pizza = -1;
        public Ingreident_Add() {
            InitializeComponent();
            InitializeControl();
        }
        private void InitializeControl() {
            //장르 콤보박스초기화

            DataTable _dt = App.Self().DBManager.ReadIngredient2("");
            cbtn_name.Items.Clear();
            foreach (DataRow _dr in _dt.Rows) {
                string _idg_code = Convert.ToString(_dr["idg_code"]);
                string _idg_name = Convert.ToString(_dr["idg_name"]);
                cbtn_name.Items.Add(new ComboItem(_idg_name, _idg_code));
            }
            if (_dt.Rows.Count > 0) {
                cbtn_name.SelectedIndex = 0;
            }
        }
        private void Ingreident_Add_Load(object sender, EventArgs e) {

        }

        private void tbox_name_add_TextChanged(object sender, EventArgs e) {

        }
        private bool ValidateTest() { return true; }
        //33
        private void saveAdd() {
            if (ValidateTest() == true) {
                ComboItem _item = cbtn_name.SelectedItem as ComboItem;
                string _idg_code = _item.Value.ToString();
                string _tbox_gram_add = tbox_gram_add.Text;
                string _tbox_ea_add = tbox_ea_add.Text;
                DateTime _dt_date = dt_date.Value;

                int _result = App.Self().DBManager.AddIngreident(_idg_code, _tbox_gram_add, _tbox_ea_add, _dt_date);
                if (_result > 0) {
                    MessageBox.Show("재료추가성공");
                }
                else {
                    MessageBox.Show("재료추가실패");
                }


            }
        }

        private void btn_save_Click(object sender, EventArgs e) {
            saveAdd();
        }

        private void cbtn_name_SelectedIndexChanged(object sender, EventArgs e) {
            switch (Convert.ToInt32(cbtn_name.SelectedIndex)) {
                case 9:
                case 10:
                case 11:
                case 12:
                    tbox_ea_add.Enabled = true;
                    tbox_gram_add.Enabled = false;
                    tbox_gram_add.Text = "";
                    break;
                default:
                    tbox_ea_add.Enabled = false;
                    tbox_gram_add.Enabled = true;
                    tbox_ea_add.Text = "";
                    break;
            }
        }
    }
}
