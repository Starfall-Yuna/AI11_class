﻿namespace Pizza.Windows.Pop {
    partial class Item_ComponentPop {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_save_cp = new System.Windows.Forms.Button();
            this.pnl_scorll = new System.Windows.Forms.Panel();
            this.pnl_base = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnl_scorll.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 437);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(473, 32);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.btn_save_cp);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(308, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(165, 32);
            this.panel2.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(84, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "닫기";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // btn_save_cp
            // 
            this.btn_save_cp.Location = new System.Drawing.Point(3, 3);
            this.btn_save_cp.Name = "btn_save_cp";
            this.btn_save_cp.Size = new System.Drawing.Size(75, 23);
            this.btn_save_cp.TabIndex = 0;
            this.btn_save_cp.Text = "저장";
            this.btn_save_cp.UseVisualStyleBackColor = true;
            this.btn_save_cp.Click += new System.EventHandler(this.btn_save_cp_Click);
            // 
            // pnl_scorll
            // 
            this.pnl_scorll.AutoScroll = true;
            this.pnl_scorll.Controls.Add(this.pnl_base);
            this.pnl_scorll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_scorll.Location = new System.Drawing.Point(0, 0);
            this.pnl_scorll.Name = "pnl_scorll";
            this.pnl_scorll.Size = new System.Drawing.Size(473, 437);
            this.pnl_scorll.TabIndex = 1;
            this.pnl_scorll.Resize += new System.EventHandler(this.pnl_scorll_Resize);
            // 
            // pnl_base
            // 
            this.pnl_base.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pnl_base.Location = new System.Drawing.Point(0, 0);
            this.pnl_base.Name = "pnl_base";
            this.pnl_base.Size = new System.Drawing.Size(289, 183);
            this.pnl_base.TabIndex = 1;
            // 
            // Item_ComponentPop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 469);
            this.Controls.Add(this.pnl_scorll);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
            this.Name = "Item_ComponentPop";
            this.Text = "Item_ComponentPop";
            this.Load += new System.EventHandler(this.Item_ComponentPop_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.pnl_scorll.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_save_cp;
        private System.Windows.Forms.Panel pnl_scorll;
        private System.Windows.Forms.Panel pnl_base;
    }
}