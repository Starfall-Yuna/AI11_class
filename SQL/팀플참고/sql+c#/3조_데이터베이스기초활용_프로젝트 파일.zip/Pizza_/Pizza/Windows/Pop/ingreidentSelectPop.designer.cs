﻿namespace Pizza.Windows.Pop {
    partial class ingreidentSelectPop {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.DisplaySet = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataTable2 = new System.Data.DataTable();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.dataColumn7 = new System.Data.DataColumn();
            this.dataColumn8 = new System.Data.DataColumn();
            this.dataColumn9 = new System.Data.DataColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tbox_seed = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.labe = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_search = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.grid_ingredient = new System.Windows.Forms.DataGridView();
            this.grid_select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.idg_code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idgnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idgunitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idgstockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_ingredient)).BeginInit();
            this.SuspendLayout();
            // 
            // DisplaySet
            // 
            this.DisplaySet.DataSetName = "NewDataSet";
            this.DisplaySet.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1,
            this.dataTable2});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4});
            this.dataTable1.TableName = "item_Component";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "itc_code";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "it_code";
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "igd_code";
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "itc_consumption";
            // 
            // dataTable2
            // 
            this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn5,
            this.dataColumn6,
            this.dataColumn7,
            this.dataColumn8,
            this.dataColumn9});
            this.dataTable2.TableName = "ingredient";
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "idg_code";
            // 
            // dataColumn6
            // 
            this.dataColumn6.ColumnName = "idg_name";
            // 
            // dataColumn7
            // 
            this.dataColumn7.ColumnName = "idg_unit";
            // 
            // dataColumn8
            // 
            this.dataColumn8.ColumnName = "idg_stock";
            // 
            // dataColumn9
            // 
            this.dataColumn9.ColumnName = "grid_select";
            this.dataColumn9.DataType = typeof(bool);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 413);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(403, 37);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(236, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(167, 37);
            this.panel3.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(84, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "닫기";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "선택";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(403, 30);
            this.panel2.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.tbox_seed);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(101, 0);
            this.panel7.Name = "panel7";
            this.panel7.Padding = new System.Windows.Forms.Padding(5);
            this.panel7.Size = new System.Drawing.Size(219, 30);
            this.panel7.TabIndex = 5;
            // 
            // tbox_seed
            // 
            this.tbox_seed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_seed.Location = new System.Drawing.Point(5, 5);
            this.tbox_seed.Name = "tbox_seed";
            this.tbox_seed.Size = new System.Drawing.Size(209, 21);
            this.tbox_seed.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.labe);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(5);
            this.panel6.Size = new System.Drawing.Size(101, 30);
            this.panel6.TabIndex = 4;
            // 
            // labe
            // 
            this.labe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labe.Location = new System.Drawing.Point(5, 5);
            this.labe.Name = "labe";
            this.labe.Size = new System.Drawing.Size(91, 20);
            this.labe.TabIndex = 0;
            this.labe.Text = "재료이름";
            this.labe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btn_search);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(320, 0);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(5);
            this.panel5.Size = new System.Drawing.Size(83, 30);
            this.panel5.TabIndex = 3;
            // 
            // btn_search
            // 
            this.btn_search.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_search.Location = new System.Drawing.Point(5, 5);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(73, 20);
            this.btn_search.TabIndex = 0;
            this.btn_search.Text = "조회";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.grid_ingredient);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 30);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(8);
            this.panel4.Size = new System.Drawing.Size(403, 383);
            this.panel4.TabIndex = 3;
            // 
            // grid_ingredient
            // 
            this.grid_ingredient.AllowUserToAddRows = false;
            this.grid_ingredient.AllowUserToDeleteRows = false;
            this.grid_ingredient.AllowUserToResizeRows = false;
            this.grid_ingredient.AutoGenerateColumns = false;
            this.grid_ingredient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_ingredient.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.grid_select,
            this.idg_code,
            this.idgnameDataGridViewTextBoxColumn,
            this.idgunitDataGridViewTextBoxColumn,
            this.idgstockDataGridViewTextBoxColumn});
            this.grid_ingredient.DataMember = "ingredient";
            this.grid_ingredient.DataSource = this.DisplaySet;
            this.grid_ingredient.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_ingredient.Location = new System.Drawing.Point(8, 8);
            this.grid_ingredient.MultiSelect = false;
            this.grid_ingredient.Name = "grid_ingredient";
            this.grid_ingredient.RowHeadersVisible = false;
            this.grid_ingredient.RowTemplate.Height = 23;
            this.grid_ingredient.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_ingredient.Size = new System.Drawing.Size(387, 367);
            this.grid_ingredient.TabIndex = 1;
            // 
            // grid_select
            // 
            this.grid_select.DataPropertyName = "grid_select";
            this.grid_select.HeaderText = "선택";
            this.grid_select.Name = "grid_select";
            this.grid_select.Width = 45;
            // 
            // idg_code
            // 
            this.idg_code.DataPropertyName = "idg_code";
            this.idg_code.HeaderText = "idg_code";
            this.idg_code.Name = "idg_code";
            // 
            // idgnameDataGridViewTextBoxColumn
            // 
            this.idgnameDataGridViewTextBoxColumn.DataPropertyName = "idg_name";
            this.idgnameDataGridViewTextBoxColumn.HeaderText = "idg_name";
            this.idgnameDataGridViewTextBoxColumn.Name = "idgnameDataGridViewTextBoxColumn";
            // 
            // idgunitDataGridViewTextBoxColumn
            // 
            this.idgunitDataGridViewTextBoxColumn.DataPropertyName = "idg_unit";
            this.idgunitDataGridViewTextBoxColumn.HeaderText = "idg_unit";
            this.idgunitDataGridViewTextBoxColumn.Name = "idgunitDataGridViewTextBoxColumn";
            // 
            // idgstockDataGridViewTextBoxColumn
            // 
            this.idgstockDataGridViewTextBoxColumn.DataPropertyName = "idg_stock";
            this.idgstockDataGridViewTextBoxColumn.HeaderText = "idg_stock";
            this.idgstockDataGridViewTextBoxColumn.Name = "idgstockDataGridViewTextBoxColumn";
            // 
            // ingreidentSelectPop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 450);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "ingreidentSelectPop";
            this.Text = "ingreidentSelectPop";
            this.Load += new System.EventHandler(this.ingreidentSelectPop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_ingredient)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Data.DataSet DisplaySet;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataTable dataTable2;
        private System.Data.DataColumn dataColumn5;
        private System.Data.DataColumn dataColumn6;
        private System.Data.DataColumn dataColumn7;
        private System.Data.DataColumn dataColumn8;
        private System.Data.DataColumn dataColumn9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox tbox_seed;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView grid_ingredient;
        private System.Windows.Forms.DataGridViewCheckBoxColumn grid_select;
        private System.Windows.Forms.DataGridViewTextBoxColumn idg_code;
        private System.Windows.Forms.DataGridViewTextBoxColumn idgnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idgunitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idgstockDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label labe;
    }
}