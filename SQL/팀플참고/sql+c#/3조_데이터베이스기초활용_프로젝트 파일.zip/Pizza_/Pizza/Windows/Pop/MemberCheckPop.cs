﻿using Pizza.Manager;
using Pizza.Windows.Pop;
using Lib.Frame;
using Lib.Util;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza.Windows.Pop
{
    public partial class MemberCheckPop : MasterPop
    {
        private DataRow m_stf_row = null;
        public MemberCheckPop()
        {
            InitializeComponent();
        }

        public override void Initialize(ePopMode popMode, object aParam) {
            base.Initialize(popMode, aParam);
            SetLayout(aParam);
            //Display();

            DoSearchMember();
        }

        private void SetLayout(object aParam) {
            cbox_member_kind.SelectedIndex = 0;
            
        }

        private void Display() {
            DoSearchMember();
        }

        private void setupstrip_Click(object sender, EventArgs e)
        {
            
        }

        

        private void cbtn_search_member_Click(object sender, EventArgs e) {
            DoSearchMember();
        }
        private void DoSearchMember() {

            int _mbr_kind = cbox_member_kind.SelectedIndex;
            string _mbr_seed = tbox_member_seed.Text;
            DataTable _dt = null;
            if (_mbr_kind == 0) {
                _dt = App.Self().DBManager.ReadMemberByName(_mbr_seed);
            }               
            else if (_mbr_kind == 1) {
                _dt = App.Self().DBManager.ReadMemberByPhone(_mbr_seed);
            }
            if (_dt != null) {
                DataTable _dtmbr = DisplaySet.Tables["dp_mbr"];
                _dtmbr.Rows.Clear();
                foreach (DataRow row in _dt.Rows) {
                    DataRow dtrow = _dtmbr.NewRow();
                    dtrow["mbr_code"] = row["mbr_code"];
                    dtrow["mbr_name"] = row["mbr_name"];
                    dtrow["mbr_id"] = row["mbr_id"];
                    dtrow["mbr_phone"] = row["mbr_phone"];
                    dtrow["mbr_addr"] = row["mbr_addr"];
                    _dtmbr.Rows.Add(dtrow);
                }
            }
        }
            
        

        private void btn_add_staff_Click(object sender, EventArgs e) {
            MemberPop _mbrpop = new MemberPop();
            _mbrpop.ShowPop(ePopMode.Add);
        }

        private void grid_member_SelectionChanged(object sender, EventArgs e) {
            if (grid_member.CurrentRow != null) {

                DataRow _SelectedRow = GridAssist.SelectedRow(grid_member);
                String _mbr_id = _SelectedRow["mbr_id"].ToString();
                DataRow _mbr_row = App.Self().DBManager.ReadMember(_mbr_id);
                if (_mbr_row != null) {
                    m_stf_row = _mbr_row;
                    DisplayStaff();
                }
            }
        }
        private void DisplayStaff() {
            if (m_stf_row == null) {
                tbox_name.Text = "";
                tbox_id.Text = "";
                tbox_phone.Text = "";
                tbox_addr.Text = "";
             }
            else {
                tbox_id.Text = Convert.ToString(m_stf_row["mbr_name"]);
                tbox_name.Text = Convert.ToString(m_stf_row["mbr_id"]);
                tbox_phone.Text = Convert.ToString(m_stf_row["mbr_phone"]);
                tbox_addr.Text = Convert.ToString(m_stf_row["mbr_addr"]);
            }
            resetcontrol(false);
        }
        private  void resetcontrol(bool able) {
            btn_save.Enabled = able;
            btn_format.Enabled = able;
        }
        private void tbox_name_TextChanged(object sender, EventArgs e) {
            resetcontrol(true);
        }

        private void tbox_id_TextChanged(object sender, EventArgs e) {
            resetcontrol(true);
        }

        private void tbox_phone_TextChanged(object sender, EventArgs e) {
            resetcontrol(true);
        }

        private void tbox_addr_TextChanged(object sender, EventArgs e) {
            resetcontrol(true);
        }

        private void grid_member_CellContentClick(object sender, DataGridViewCellEventArgs e) {

        }

        private void btn_format_Click(object sender, EventArgs e) {
            DisplayStaff();
        }

        private void cbox_member_kind_SelectedIndexChanged(object sender, EventArgs e) {

        }

        private void btn_save_Click(object sender, EventArgs e) {
            int mbr_code = Convert.ToInt32(m_stf_row["mbr_code"]);
            string mbr_name  = tbox_id.Text ;
            string mbr_id =  tbox_name.Text ;
            string mbr_phone =  tbox_phone.Text;
            string mbr_addr =   tbox_addr.Text ;
            int _result = App.Self().DBManager.ModifyMember( mbr_code, mbr_name, mbr_id, mbr_phone, mbr_addr);
            if(_result > 0 ) {
                MessageBox.Show("수정성공");
                resetcontrol(false);
            } else {
                DialogResult _dresult =  MessageBox.Show("수정실패\n값을 초기화 할까요?","", MessageBoxButtons.YesNo);
                if(_dresult == DialogResult.Yes ) {

                    DisplayStaff();
                    resetcontrol(false);
                }
            }
        }
    }
}
