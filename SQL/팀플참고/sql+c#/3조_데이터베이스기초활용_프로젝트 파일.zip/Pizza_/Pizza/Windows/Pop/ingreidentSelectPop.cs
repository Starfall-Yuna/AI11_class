﻿using Lib.Frame;
using Pizza.Manager;
using Pizza.Windows.Pop;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza.Windows.Pop {
    public partial class ingreidentSelectPop : MasterPop {
        public ingreidentSelectPop() {
            InitializeComponent(); 
            ReadIngredient("");
        }

        private void ingreidentSelectPop_Load(object sender, EventArgs e) {

        }

        private void ReadIngredient(string aName) {
            DataTable _dt = App.Self().DBManager.ReadIngredientByName(aName);
            DataTable _dp_ingredient = DisplaySet.Tables["ingredient"];
            _dp_ingredient.Rows.Clear();
            foreach (DataRow dr in _dt.Rows) {
                DataRow _row = _dp_ingredient.NewRow();
                _row["idg_code"] = dr["idg_code"];
                _row["idg_name"] = dr["idg_name"];
                _row["idg_unit"] = dr["idg_unit"];
                _row["idg_stock"] = dr["idg_stock"];
                _dp_ingredient.Rows.Add(_row);
            }
        }

        private void btn_search_Click(object sender, EventArgs e) {
            ReadIngredient(tbox_seed.Text); 
        }

        private void button2_Click(object sender, EventArgs e) {
            DialogResult = DialogResult.Cancel;
        }

        private DataRow[] m_rows = null;
        public DataRow[] SelectedRow { get { return m_rows; } }

        private void button1_Click(object sender, EventArgs e) {

            DataTable dp_ingredien = DisplaySet.Tables["ingredient"];
            m_rows = dp_ingredien.Select("grid_select = true");
            DialogResult = DialogResult.OK;
        }
    }
}
