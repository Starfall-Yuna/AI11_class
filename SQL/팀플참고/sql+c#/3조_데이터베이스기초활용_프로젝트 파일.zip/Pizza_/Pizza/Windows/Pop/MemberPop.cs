﻿using Pizza.Manager;
using Lib.Frame;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza.Windows.Pop
{
    public partial class MemberPop : MasterPop
    {

        private DataRow m_mbr_row = null;
        public MemberPop()
        {
            InitializeComponent();
        }
        public override void Initialize(ePopMode popMode, object aParam) {
            base.Initialize(popMode, aParam);
            SetLayout(aParam);
            Display();

        }

        private void SetLayout(object aParam) {
            if (m_PopMode == ePopMode.Modify) {
                SetLayout4Modify(aParam); //41

            }
            else {
                this.Text = "회원관리 - 등록";
            }
        }
        //41
        private void SetLayout4Modify(object aParam) {
            this.Text = "회원관리 - 수정";
            int _mbr_code = (int)aParam;
            if (_mbr_code > 0) {
                m_mbr_row = App.Self().DBManager.ReadMemberByUcode(_mbr_code);
            }
        }

        private void Display() {
            if (m_PopMode == ePopMode.Add) {
                Display4Add();
            }
            else if (m_PopMode == ePopMode.Modify) {
                Display4Modify();//41
            }

        }
        private void Display4Add() {
            tbox_name.Text = "";
            tbox_id.Text = "";
            tbox_addr.Text = "";
            tbox_phone.Text = "";
        }
        
        private void Display4Modify() {
            if (m_mbr_row != null) {
                //41
                tbox_name.Text = Convert.ToString(m_mbr_row["mbr_name"]);
                tbox_id.Text = Convert.ToString(m_mbr_row["mbr_id"]);
                tbox_addr.Text = Convert.ToString(m_mbr_row["mbr_addr"]);
                tbox_phone.Text = Convert.ToString(m_mbr_row["mbr_phone"]);
            }
        }

        private void MemberPop_Load(object sender, EventArgs e) {

        }


        private void btn_init_Click_1(object sender, EventArgs e) {
            Display();
        }
        private bool ValidateTest() {
            //40
            bool _result = true;
            string _msg = "";

            //필수입력
            if (tbox_name.Text.Length <= 0) {
                if (_msg.Length == 0) { tbox_name.Focus(); }
                _msg += "이름은 필수입력사항입니다.";
            }
            if (tbox_id.Text.Length <= 0) {
                if (_msg.Length == 0) {
                    tbox_id.Focus();
                }
                else {
                    _msg += "\r\n";
                }
                _msg += "아이디은 필수입력사항입니다.";
            }
           
            //문자타입길이체크
            //문자열리터럴체크

            string pattern = @"^\d{3}-\d{4}-\d{4}$";
            //전화번호 형식체크 000-0000-0000
            if (Regex.IsMatch(tbox_phone.Text, pattern) == false) {
                if (_msg.Length == 0) {
                    tbox_phone.Focus(); tbox_phone.SelectAll();
                }
                else {
                    _msg += "\r\n";
                }
                _msg += "전화번호 형식이 올바르지 않습니다.";
            }
            //아이디중복체크
            if (_msg.Length == 0) {
                bool _check_id = true;
                if (m_mbr_row != null && m_mbr_row["mbr_id"].ToString() == tbox_id.Text) {
                    //수정모드이면서 아이디가 안바뀌면
                    _check_id = false;
                }
                if (_check_id) {
                    DataTable _dt = App.Self().DBManager.ReadMemberById(tbox_id.Text);
                    if (_dt != null && _dt.Rows != null && _dt.Rows.Count > 0) {
                        _msg = string.Format(" [{0}]는 사용중인 아이디 입니다.", tbox_id.Text);
                        tbox_id.Focus();
                        tbox_id.SelectAll();
                    }
                }
            }
            //
            if (_msg.Length > 0) {
                _result = false;
                MessageBox.Show(_msg);
            }
            return _result;
        }
        private void btn_member_add_Click(object sender, EventArgs e) {
           
            if (m_PopMode == ePopMode.Add) {
                save4add();
            }
            else if (m_PopMode == ePopMode.Modify) {
                save4modify();
            }
        }

        private void save4modify() {
            //42
            if (ValidateTest()) {
                int _mbr_code = Convert.ToInt32(m_mbr_row["mbr_code"]);
                string _mbr_name = tbox_name.Text;
                string _mbr_id = tbox_id.Text;
                string _mbr_addr = tbox_addr.Text;
                string _mbr_phone = tbox_phone.Text;
                int _result = App.Self().DBManager.ModifyMember(_mbr_code, _mbr_name, _mbr_id,  _mbr_phone, _mbr_addr);
                if (_result > 0) {
                    MessageBox.Show("회원수정성공");
                }
                else {
                    MessageBox.Show("회원수정실패");
                }
            }
        }

        private void save4add() {
            if (ValidateTest()) {
                string _mbr_name = tbox_name.Text;
                string _mbr_id = tbox_id.Text;
                string _mbr_phone = tbox_phone.Text;
                string _mbr_addr = tbox_addr.Text;
                int _result = App.Self().DBManager.AdMember(_mbr_name, _mbr_id,  _mbr_phone, _mbr_addr);
                if (_result > 0) {
                    MessageBox.Show("회원추가성공");
                }
                else {
                    MessageBox.Show("회원추가실패");

                }
            }
        }

        private void btn_close_Click_1(object sender, EventArgs e) {
            DialogResult = DialogResult.Cancel;
        }

        
    }
}
