﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pizza.Windows.Pop;
using Lib.Frame;
using Lib.Util;
using Pizza.Manager;

using Lib.Control;
using System.IO;

namespace Pizza.Windows.Pop
{
    public partial class AddMenuPop : MasterPop
    {
        private DataRow m_rows;
        public AddMenuPop()
        {
            InitializeComponent();
            InitializeIngredient(); 
            InitializeControl();
        }
        private void InitializeControl() {
            //장르 콤보박스초기화

            DataTable _dt = App.Self().DBManager.ReadCategory();
            cbox_category.Items.Clear();
            foreach (DataRow _dr in _dt.Rows) {
                int _idg_code = Convert.ToInt32(_dr["ctg_code"]);
                string _idg_name = Convert.ToString(_dr["ctg_name"]);
                cbox_category.Items.Add(new ComboItem(_idg_name, _idg_code));
            }
            if (_dt.Rows.Count > 0) {
                cbox_category.SelectedIndex = 0;
            }

            cbox_size.SelectedIndex = 1;
        }
        private void InitializeIngredient()
        {
            DataTable _dt = App.Self().DBManager.ReadIngredientAll();
            DataTable _dp_ingredient = DisplaySet.Tables["ingredient"];
            _dp_ingredient.Rows.Clear();
            foreach (DataRow dr in _dt.Rows)
            {
                DataRow _row = _dp_ingredient.NewRow();
                _row["idg_code"] = dr["idg_code"];
                _row["idg_name"] = dr["idg_name"];
                _row["idg_unit"] = dr["idg_unit"];
                _row["idg_stock"] = dr["idg_stock"];
                _dp_ingredient.Rows.Add(_row);
            }
        }
        
        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void btn_add_menu_Click(object sender, EventArgs e)
        {

        }

        private void btn_add_drink_Click(object sender, EventArgs e)
        {

        }

        private void btn_add_cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_left_Click(object sender, EventArgs e) {
            DataTable dp_ingredien = DisplaySet.Tables["ingredient"];
            DataRow[] _rows = dp_ingredien.Select("grid_select = true");
            if( _rows != null && _rows.Length>0 ) {
                Item_ComponentPop _pop = new Item_ComponentPop();
                _pop.ShowPop(ePopMode.Add, _rows);

            }
        }

        private void grid_add_CellContentClick(object sender, DataGridViewCellEventArgs e) {

        }

        private void btn_add_Click(object sender, EventArgs e) {
            ingreidentSelectPop _pop = new ingreidentSelectPop();
            if( _pop.ShowPop(ePopMode.Select, null) == DialogResult.OK) {
                DataRow [] _rows = _pop.SelectedRow;

                int _idx = 0;
                foreach (DataRow row in _rows) {
                    int _Code = Convert.ToInt32(row["idg_code"]);
                    if (ExistIngredientByCode(_Code) == false) {
                        ComponentControl _ctrl = new ComponentControl();
                        pnl_base.Controls.Add(_ctrl);
                        _ctrl.OnClickDelete += DeleteIngredient;
                        _ctrl.IngredientName = row["idg_name"].ToString();
                        _ctrl.IngredientCode = Convert.ToInt32(row["idg_code"]);
                        _ctrl.Consumption = 0;
                        _idx++;
                    }
                }
                pnl_base.Height = _idx * 30; 
                DesployIngredientCtrl();

            }
        }

        private bool ExistIngredientByCode(int aCode) {
            bool _result = false;

            foreach (object _obj in pnl_base.Controls) {
                ComponentControl _ctrl = _obj as ComponentControl;
                if (_ctrl != null) {
                    if(_ctrl.IngredientCode == aCode) { _result = true; break; }    
                }
            }
            return _result;
        }
        private void DesployIngredientCtrl() {
            pnl_base.Height = pnl_base.Controls.Count * 30;
            if(pnl_base.Height > pnl_scorll.Height) {
                pnl_base.Width = pnl_scorll.Width-22;
            } else {
                pnl_base.Width = pnl_scorll.Width;
            }

            int _idx = 0;
            foreach (object _obj in pnl_base.Controls) {
                ComponentControl _ctrl = _obj as ComponentControl;
                if (_ctrl != null) {
                    //MessageBox.Show(_ctrl.IngredientCode.ToString());
                    _ctrl.Width = pnl_base.Width;
                    _ctrl.Location = new Point(0, _idx * 30);
                    _idx++;
                }
            }
        }

        private int DeleteIngredient(object Sender, object aObject) {

            foreach(object _obj in pnl_base.Controls) {
                ComponentControl _ctrl = _obj as ComponentControl;
                if (_ctrl == Sender) {
                    pnl_base.Controls.Remove(_ctrl);
                    break;
                }
            }
            DesployIngredientCtrl();
            return 0;
        }

        private void pnl_scorll_Resize(object sender, EventArgs e) {

        }

        private void pnl_base_Resize(object sender, EventArgs e) {

        }

        private void cbox_kind_SelectedIndexChanged(object sender, EventArgs e) {

        }

        private void btn_add_Click_1(object sender, EventArgs e) {
           // SaveItem1();
            SaveItem2();
        }
        private void SaveItem2() {
            //int itc_code = Convert.ToInt32(m_rows["itc_code"]);
            int _ctg_code = 1;
            ComboItem _citem = cbox_category.SelectedItem as ComboItem;
            if (_citem != null) {
                _ctg_code = Convert.ToInt32(_citem.Value);
            }
            string _it_size = cbox_size.SelectedItem.ToString();

            string _it_name = tbox_name.Text;
            int _it_price = Convert.ToInt32(tbox_price.Text);
            int _it_maiking_time = Convert.ToInt32(tbox_making_time.Text);
            string _it_picture = "";
            if (pbox_picture.Tag != null) {
                _it_picture = pbox_picture.Tag.ToString();
            }
            //int _it_code = App.Self().DBManager.ReadSeq("SEQ_ITEM");
            // if (_it_code > 0) {
            List<int> _comp_ingredient_codes = new List<int>();
                //List<string> _comp_names = new List<string>();
                List<int> _comp_consumptions = new List<int>();
                foreach (object _obj in pnl_base.Controls) {
                    ComponentControl _cctrl = _obj as ComponentControl;
                    _comp_ingredient_codes.Add(_cctrl.IngredientCode);
                    //_comp_names.Add(_cctrl.Name);
                    _comp_consumptions.Add(_cctrl.Consumption);
                }

                int _result = App.Self().DBManager.AddItem3( _ctg_code, _it_name, _it_size, _it_price, _it_maiking_time,_it_picture
                    , _comp_ingredient_codes, _comp_consumptions);

            if (_result > 0) {
                DialogResult _dresult = MessageBox.Show("저장성공\n계속입력하시겠습니까?","",MessageBoxButtons.YesNo);
                if(_dresult == DialogResult.No) { DialogResult = DialogResult.OK; }
            } else {
                MessageBox.Show("저장실패");
            }

        }
        private void SaveItem1() { 
            //int itc_code = Convert.ToInt32(m_rows["itc_code"]);
            int _ctg_code = 1;
            ComboItem _citem = cbox_category.SelectedItem as ComboItem;
            if(_citem != null) {
                _ctg_code = Convert.ToInt32(_citem.Value);
            }
            string _it_size =cbox_size.SelectedItem.ToString();

            string _it_name = tbox_name.Text;
            int _it_price = Convert.ToInt32(tbox_price.Text);
            int _it_maiking_time = Convert.ToInt32(tbox_making_time.Text);
            int _it_code = App.Self().DBManager.ReadSeq("SEQ_ITEM");
            string _it_picture = "";
            if (pbox_picture.Tag != null) {
                _it_picture = pbox_picture.Tag.ToString();
            }
            if (_it_code > 0) {
                List<int> _comp_ingredient_codes = new List<int>();
                //List<string> _comp_names = new List<string>();
                List<int> _comp_consumptions = new List<int>();
                foreach ( object _obj in pnl_base.Controls) {
                    ComponentControl _cctrl = _obj as ComponentControl;
                    _comp_ingredient_codes.Add(_cctrl.IngredientCode);
                    //_comp_names.Add(_cctrl.Name);
                    _comp_consumptions.Add(_cctrl.Consumption);                       
                }

                int _result = App.Self().DBManager.AddItem2(_it_code, _ctg_code, _it_name, _it_size, _it_price, _it_maiking_time,_it_picture
                    , _comp_ingredient_codes,  _comp_consumptions);

            }

            //int _result = App.Self().DBManager.AddItem();
            
        }

        private void pnl_base_Paint(object sender, PaintEventArgs e) {

        }

        private void btn_file_Click(object sender, EventArgs e) {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "PNG|*.png|JPG|*.jpg|BMP|*.bmp|all files|*.*";
            ofd.InitialDirectory = Application.StartupPath;
            if (ofd.ShowDialog() == DialogResult.OK) {
                pbox_picture.Image = Bitmap.FromFile(ofd.FileName);

                FileStream fs = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read); ;
                byte[] bImage = new byte[fs.Length];
                fs.Read(bImage, 0, (int)fs.Length);

                StringBuilder hex = new StringBuilder(bImage.Length * 2);
                foreach (byte b in bImage) {
                    hex.AppendFormat("{0:X2}", b);
                }
                string _hex_image = hex.ToString();
                //MessageBox.Show(_hex_image);
                pbox_picture.Tag = _hex_image;
            }
        }
        private byte[] HexStringToByteArray(string hex) {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            if (NumberChars % 2 == 0) {
                for (int i = 0; i < NumberChars; i += 2) {
                    bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
                }
            }
            return bytes;
        }
    }
}
