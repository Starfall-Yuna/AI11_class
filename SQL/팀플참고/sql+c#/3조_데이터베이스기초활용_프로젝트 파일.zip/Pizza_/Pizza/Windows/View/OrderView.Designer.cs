﻿namespace Pizza.Windows.View
{
    partial class OrderView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.group_menu = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel_scroll = new System.Windows.Forms.Panel();
            this.panel_goods = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel_scrolll = new System.Windows.Forms.Panel();
            this.panel_Topping = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel_scroll4 = new System.Windows.Forms.Panel();
            this.panel_drink = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panel_scroll3 = new System.Windows.Forms.Panel();
            this.panel_menu = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_Sum = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_Pay = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.DisplaySet = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.메뉴 = new System.Data.DataColumn();
            this.개수 = new System.Data.DataColumn();
            this.가격 = new System.Data.DataColumn();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataTable2 = new System.Data.DataTable();
            this.합계 = new System.Data.DataColumn();
            this.할인 = new System.Data.DataColumn();
            this.마일리지 = new System.Data.DataColumn();
            this.받을돈 = new System.Data.DataColumn();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel12.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel13.SuspendLayout();
            this.group_menu.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel_scroll.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel_scrolll.SuspendLayout();
            this.panel7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel_scroll4.SuspendLayout();
            this.panel16.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel_scroll3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel2.Controls.Add(this.panel12, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel16, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 594F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1255, 622);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.tableLayoutPanel3);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(3, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(872, 616);
            this.panel12.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.panel13, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 616F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 616F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(872, 616);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.AutoScroll = true;
            this.panel13.Controls.Add(this.group_menu);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(3, 3);
            this.panel13.Name = "panel13";
            this.panel13.Padding = new System.Windows.Forms.Padding(5);
            this.panel13.Size = new System.Drawing.Size(866, 610);
            this.panel13.TabIndex = 0;
            // 
            // group_menu
            // 
            this.group_menu.Controls.Add(this.tableLayoutPanel1);
            this.group_menu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_menu.Location = new System.Drawing.Point(5, 5);
            this.group_menu.Name = "group_menu";
            this.group_menu.Size = new System.Drawing.Size(856, 600);
            this.group_menu.TabIndex = 0;
            this.group_menu.TabStop = false;
            this.group_menu.Text = "일반 메뉴";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel_scroll, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(850, 580);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel_scroll
            // 
            this.panel_scroll.AutoScroll = true;
            this.panel_scroll.Controls.Add(this.panel_goods);
            this.panel_scroll.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_scroll.Location = new System.Drawing.Point(3, 3);
            this.panel_scroll.Name = "panel_scroll";
            this.panel_scroll.Size = new System.Drawing.Size(844, 226);
            this.panel_scroll.TabIndex = 0;
            this.panel_scroll.Resize += new System.EventHandler(this.panel_goods_Resize);
            // 
            // panel_goods
            // 
            this.panel_goods.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_goods.Location = new System.Drawing.Point(0, 0);
            this.panel_goods.Name = "panel_goods";
            this.panel_goods.Size = new System.Drawing.Size(844, 168);
            this.panel_goods.TabIndex = 0;
            this.panel_goods.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_goods_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 235);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(3);
            this.panel1.Size = new System.Drawing.Size(844, 168);
            this.panel1.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel_scrolll);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(838, 162);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "토핑";
            // 
            // panel_scrolll
            // 
            this.panel_scrolll.AutoScroll = true;
            this.panel_scrolll.Controls.Add(this.panel_Topping);
            this.panel_scrolll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_scrolll.Location = new System.Drawing.Point(3, 17);
            this.panel_scrolll.Name = "panel_scrolll";
            this.panel_scrolll.Size = new System.Drawing.Size(832, 142);
            this.panel_scrolll.TabIndex = 0;
            this.panel_scrolll.Resize += new System.EventHandler(this.panel_goods_Resize2);
            // 
            // panel_Topping
            // 
            this.panel_Topping.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Topping.Location = new System.Drawing.Point(0, 0);
            this.panel_Topping.Name = "panel_Topping";
            this.panel_Topping.Size = new System.Drawing.Size(832, 124);
            this.panel_Topping.TabIndex = 0;
            this.panel_Topping.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Topping_Paint);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.groupBox2);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(3, 409);
            this.panel7.Name = "panel7";
            this.panel7.Padding = new System.Windows.Forms.Padding(3);
            this.panel7.Size = new System.Drawing.Size(844, 168);
            this.panel7.TabIndex = 2;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel_scroll4);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(838, 162);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "음료";
            // 
            // panel_scroll4
            // 
            this.panel_scroll4.AutoScroll = true;
            this.panel_scroll4.Controls.Add(this.panel_drink);
            this.panel_scroll4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_scroll4.Location = new System.Drawing.Point(3, 17);
            this.panel_scroll4.Name = "panel_scroll4";
            this.panel_scroll4.Size = new System.Drawing.Size(832, 142);
            this.panel_scroll4.TabIndex = 0;
            this.panel_scroll4.Resize += new System.EventHandler(this.panel_goods_REsize3);
            // 
            // panel_drink
            // 
            this.panel_drink.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_drink.Location = new System.Drawing.Point(0, 0);
            this.panel_drink.Name = "panel_drink";
            this.panel_drink.Size = new System.Drawing.Size(832, 129);
            this.panel_drink.TabIndex = 0;
            this.panel_drink.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_drink_Paint);
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.tableLayoutPanel4);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(881, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(371, 616);
            this.panel16.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Controls.Add(this.panel_scroll3, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(371, 616);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // panel_scroll3
            // 
            this.panel_scroll3.AutoScroll = true;
            this.panel_scroll3.BackColor = System.Drawing.Color.Gray;
            this.panel_scroll3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel_scroll3.Controls.Add(this.panel_menu);
            this.panel_scroll3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_scroll3.Location = new System.Drawing.Point(3, 3);
            this.panel_scroll3.Name = "panel_scroll3";
            this.panel_scroll3.Size = new System.Drawing.Size(365, 425);
            this.panel_scroll3.TabIndex = 0;
            this.panel_scroll3.Resize += new System.EventHandler(this.panel_goods_Resize);
            // 
            // panel_menu
            // 
            this.panel_menu.BackColor = System.Drawing.Color.Silver;
            this.panel_menu.Location = new System.Drawing.Point(0, 0);
            this.panel_menu.Name = "panel_menu";
            this.panel_menu.Size = new System.Drawing.Size(96, 115);
            this.panel_menu.TabIndex = 0;
            this.panel_menu.Resize += new System.EventHandler(this.panel_menu_Resize);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 434);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(365, 179);
            this.panel2.TabIndex = 1;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.panel4, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.panel5, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.panel6, 1, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(365, 179);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lbl_Sum);
            this.panel4.Location = new System.Drawing.Point(185, 3);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(3);
            this.panel4.Size = new System.Drawing.Size(176, 83);
            this.panel4.TabIndex = 1;
            // 
            // lbl_Sum
            // 
            this.lbl_Sum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_Sum.Font = new System.Drawing.Font("굴림", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_Sum.Location = new System.Drawing.Point(3, 3);
            this.lbl_Sum.Name = "lbl_Sum";
            this.lbl_Sum.Size = new System.Drawing.Size(170, 77);
            this.lbl_Sum.TabIndex = 0;
            this.lbl_Sum.Text = "0원";
            this.lbl_Sum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(3);
            this.panel3.Size = new System.Drawing.Size(176, 83);
            this.panel3.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("굴림", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 77);
            this.label1.TabIndex = 0;
            this.label1.Text = "합계";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btn_Pay);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 92);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(3);
            this.panel5.Size = new System.Drawing.Size(176, 84);
            this.panel5.TabIndex = 2;
            // 
            // btn_Pay
            // 
            this.btn_Pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Pay.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_Pay.Location = new System.Drawing.Point(3, 3);
            this.btn_Pay.Name = "btn_Pay";
            this.btn_Pay.Size = new System.Drawing.Size(170, 78);
            this.btn_Pay.TabIndex = 0;
            this.btn_Pay.Text = "결제";
            this.btn_Pay.UseVisualStyleBackColor = true;
            this.btn_Pay.Click += new System.EventHandler(this.btn_Pay_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btn_Cancel);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(185, 92);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(3);
            this.panel6.Size = new System.Drawing.Size(177, 84);
            this.panel6.TabIndex = 3;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Cancel.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_Cancel.Location = new System.Drawing.Point(3, 3);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(171, 78);
            this.btn_Cancel.TabIndex = 0;
            this.btn_Cancel.Text = "취소";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // DisplaySet
            // 
            this.DisplaySet.DataSetName = "NewDataSet";
            this.DisplaySet.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1,
            this.dataTable2});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.메뉴,
            this.개수,
            this.가격,
            this.dataColumn1});
            this.dataTable1.TableName = "dp_order";
            // 
            // 메뉴
            // 
            this.메뉴.ColumnName = "menu";
            // 
            // 개수
            // 
            this.개수.ColumnName = "count";
            // 
            // 가격
            // 
            this.가격.ColumnName = "price";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "SIze";
            // 
            // dataTable2
            // 
            this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
            this.합계,
            this.할인,
            this.마일리지,
            this.받을돈});
            this.dataTable2.TableName = "dp_sum";
            // 
            // 합계
            // 
            this.합계.ColumnName = "sum";
            // 
            // 할인
            // 
            this.할인.ColumnName = "discount";
            // 
            // 마일리지
            // 
            this.마일리지.ColumnName = "mile";
            // 
            // 받을돈
            // 
            this.받을돈.ColumnName = "final";
            // 
            // OrderView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1255, 622);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "OrderView";
            this.Text = "OrderView";
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.group_menu.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel_scroll.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panel_scrolll.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel_scroll4.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel_scroll3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.GroupBox group_menu;
        private System.Windows.Forms.Panel panel16;
        private System.Data.DataSet DisplaySet;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn 메뉴;
        private System.Data.DataColumn 개수;
        private System.Data.DataColumn 가격;
        private System.Data.DataTable dataTable2;
        private System.Data.DataColumn 합계;
        private System.Data.DataColumn 할인;
        private System.Data.DataColumn 마일리지;
        private System.Data.DataColumn 받을돈;
        private System.Data.DataColumn dataColumn1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel_scroll;
        private System.Windows.Forms.Panel panel_goods;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel_scrolll;
        private System.Windows.Forms.Panel panel_Topping;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panel_scroll3;
        private System.Windows.Forms.Panel panel_menu;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl_Sum;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_Pay;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel_scroll4;
        private System.Windows.Forms.Panel panel_drink;
    }
}