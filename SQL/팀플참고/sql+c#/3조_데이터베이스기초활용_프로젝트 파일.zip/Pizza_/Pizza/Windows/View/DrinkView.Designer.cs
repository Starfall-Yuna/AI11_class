﻿namespace Pizza.Windows.View
{
    partial class DrinkView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.group_menu = new System.Windows.Forms.GroupBox();
            this.panel_scroll = new System.Windows.Forms.Panel();
            this.panel_goods = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.btn_pay = new System.Windows.Forms.Button();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label_pay = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label_mil = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label_dis = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label_sum = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.grid_list = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel12.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel13.SuspendLayout();
            this.group_menu.SuspendLayout();
            this.panel_scroll.SuspendLayout();
            this.panel16.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel17.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_list)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel2.Controls.Add(this.panel12, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel16, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 594F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.tableLayoutPanel3);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(3, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(554, 444);
            this.panel12.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.panel13, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 444F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 444F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(554, 444);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.AutoScroll = true;
            this.panel13.Controls.Add(this.group_menu);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(3, 3);
            this.panel13.Name = "panel13";
            this.panel13.Padding = new System.Windows.Forms.Padding(5);
            this.panel13.Size = new System.Drawing.Size(548, 438);
            this.panel13.TabIndex = 0;
            // 
            // group_menu
            // 
            this.group_menu.Controls.Add(this.panel_scroll);
            this.group_menu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_menu.Location = new System.Drawing.Point(5, 5);
            this.group_menu.Name = "group_menu";
            this.group_menu.Size = new System.Drawing.Size(538, 428);
            this.group_menu.TabIndex = 0;
            this.group_menu.TabStop = false;
            this.group_menu.Text = "음료 메뉴";
            // 
            // panel_scroll
            // 
            this.panel_scroll.AutoScroll = true;
            this.panel_scroll.Controls.Add(this.panel_goods);
            this.panel_scroll.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_scroll.Location = new System.Drawing.Point(3, 17);
            this.panel_scroll.Name = "panel_scroll";
            this.panel_scroll.Size = new System.Drawing.Size(532, 162);
            this.panel_scroll.TabIndex = 0;
            // 
            // panel_goods
            // 
            this.panel_goods.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_goods.Location = new System.Drawing.Point(0, 0);
            this.panel_goods.Name = "panel_goods";
            this.panel_goods.Size = new System.Drawing.Size(532, 122);
            this.panel_goods.TabIndex = 0;
            this.panel_goods.Resize += new System.EventHandler(this.panel_goods_Resize);
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.tableLayoutPanel4);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(563, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(234, 444);
            this.panel16.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.panel17, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.panel18, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(234, 444);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.tableLayoutPanel6);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(3, 291);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(228, 150);
            this.panel17.TabIndex = 0;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.panel27, 1, 4);
            this.tableLayoutPanel6.Controls.Add(this.panel25, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.panel24, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.panel23, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.panel22, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.panel21, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.panel20, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.panel19, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.panel15, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.panel26, 0, 4);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 5;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.62745F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.62745F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.62745F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.62745F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.4902F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(228, 150);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.btn_pay);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(117, 111);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(108, 36);
            this.panel27.TabIndex = 9;
            // 
            // btn_pay
            // 
            this.btn_pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_pay.Location = new System.Drawing.Point(0, 0);
            this.btn_pay.Name = "btn_pay";
            this.btn_pay.Size = new System.Drawing.Size(108, 36);
            this.btn_pay.TabIndex = 0;
            this.btn_pay.Text = "결제";
            this.btn_pay.UseVisualStyleBackColor = true;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.label_pay);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(117, 84);
            this.panel25.Name = "panel25";
            this.panel25.Padding = new System.Windows.Forms.Padding(3);
            this.panel25.Size = new System.Drawing.Size(108, 21);
            this.panel25.TabIndex = 7;
            // 
            // label_pay
            // 
            this.label_pay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_pay.Location = new System.Drawing.Point(3, 3);
            this.label_pay.Name = "label_pay";
            this.label_pay.Size = new System.Drawing.Size(102, 15);
            this.label_pay.TabIndex = 0;
            this.label_pay.Text = "0원";
            this.label_pay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.label7);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(3, 84);
            this.panel24.Name = "panel24";
            this.panel24.Padding = new System.Windows.Forms.Padding(3);
            this.panel24.Size = new System.Drawing.Size(108, 21);
            this.panel24.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(3, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 15);
            this.label7.TabIndex = 0;
            this.label7.Text = "지불금액";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.label_mil);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(117, 57);
            this.panel23.Name = "panel23";
            this.panel23.Padding = new System.Windows.Forms.Padding(3);
            this.panel23.Size = new System.Drawing.Size(108, 21);
            this.panel23.TabIndex = 5;
            // 
            // label_mil
            // 
            this.label_mil.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_mil.Location = new System.Drawing.Point(3, 3);
            this.label_mil.Name = "label_mil";
            this.label_mil.Size = new System.Drawing.Size(102, 15);
            this.label_mil.TabIndex = 0;
            this.label_mil.Text = "0원";
            this.label_mil.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.label5);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(3, 57);
            this.panel22.Name = "panel22";
            this.panel22.Padding = new System.Windows.Forms.Padding(3);
            this.panel22.Size = new System.Drawing.Size(108, 21);
            this.panel22.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "마일리지";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.label_dis);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel21.Location = new System.Drawing.Point(117, 30);
            this.panel21.Name = "panel21";
            this.panel21.Padding = new System.Windows.Forms.Padding(3);
            this.panel21.Size = new System.Drawing.Size(108, 21);
            this.panel21.TabIndex = 3;
            // 
            // label_dis
            // 
            this.label_dis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_dis.Location = new System.Drawing.Point(3, 3);
            this.label_dis.Name = "label_dis";
            this.label_dis.Size = new System.Drawing.Size(102, 15);
            this.label_dis.TabIndex = 0;
            this.label_dis.Text = "0원";
            this.label_dis.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.label3);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(3, 30);
            this.panel20.Name = "panel20";
            this.panel20.Padding = new System.Windows.Forms.Padding(3);
            this.panel20.Size = new System.Drawing.Size(108, 21);
            this.panel20.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "할인";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.label_sum);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(117, 3);
            this.panel19.Name = "panel19";
            this.panel19.Padding = new System.Windows.Forms.Padding(3);
            this.panel19.Size = new System.Drawing.Size(108, 21);
            this.panel19.TabIndex = 1;
            // 
            // label_sum
            // 
            this.label_sum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_sum.Location = new System.Drawing.Point(3, 3);
            this.label_sum.Name = "label_sum";
            this.label_sum.Size = new System.Drawing.Size(102, 15);
            this.label_sum.TabIndex = 0;
            this.label_sum.Text = "0원";
            this.label_sum.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label1);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(3, 3);
            this.panel15.Name = "panel15";
            this.panel15.Padding = new System.Windows.Forms.Padding(3);
            this.panel15.Size = new System.Drawing.Size(108, 21);
            this.panel15.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "합계";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.btn_cancel);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(3, 111);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(108, 36);
            this.panel26.TabIndex = 8;
            // 
            // btn_cancel
            // 
            this.btn_cancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_cancel.Location = new System.Drawing.Point(0, 0);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(108, 36);
            this.btn_cancel.TabIndex = 0;
            this.btn_cancel.Text = "취소";
            this.btn_cancel.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.grid_list);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(3, 3);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(228, 282);
            this.panel18.TabIndex = 1;
            // 
            // grid_list
            // 
            this.grid_list.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_list.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.price,
            this.delete});
            this.grid_list.DataMember = "dp_order";
            this.grid_list.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_list.Location = new System.Drawing.Point(0, 0);
            this.grid_list.Name = "grid_list";
            this.grid_list.RowTemplate.Height = 23;
            this.grid_list.Size = new System.Drawing.Size(228, 282);
            this.grid_list.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "count";
            this.dataGridViewTextBoxColumn1.HeaderText = "개수";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // price
            // 
            this.price.DataPropertyName = "price";
            this.price.HeaderText = "가격";
            this.price.Name = "price";
            // 
            // delete
            // 
            this.delete.DataPropertyName = "delete";
            this.delete.HeaderText = "취소";
            this.delete.Name = "delete";
            this.delete.Text = "----";
            this.delete.UseColumnTextForButtonValue = true;
            // 
            // DrinkView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "DrinkView";
            this.Text = "DrinkView";
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.group_menu.ResumeLayout(false);
            this.panel_scroll.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_list)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.GroupBox group_menu;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Button btn_pay;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label_pay;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label_mil;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label_dis;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label_sum;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.DataGridView grid_list;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewButtonColumn delete;
        private System.Windows.Forms.Panel panel_scroll;
        private System.Windows.Forms.Panel panel_goods;
    }
}