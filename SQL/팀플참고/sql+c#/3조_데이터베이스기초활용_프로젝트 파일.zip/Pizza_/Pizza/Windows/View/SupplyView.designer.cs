﻿namespace Pizza.Windows.View
{
    partial class SupplyView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbox_seed = new System.Windows.Forms.TextBox();
            this.panel_tbox = new System.Windows.Forms.Panel();
            this.btn_search = new System.Windows.Forms.Button();
            this.panel_date = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.date_end = new System.Windows.Forms.DateTimePicker();
            this.date_begin = new System.Windows.Forms.DateTimePicker();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cbox_search_kind = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_open = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.grid_main = new System.Windows.Forms.DataGridView();
            this.idghcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idghdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idghkindDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idgcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.odrdcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idghweightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DisplaySet = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel_tbox.SuspendLayout();
            this.panel_date.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel_tbox);
            this.panel1.Controls.Add(this.panel_date);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(956, 38);
            this.panel1.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tbox_seed);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(410, 0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.panel2.Size = new System.Drawing.Size(187, 38);
            this.panel2.TabIndex = 6;
            // 
            // tbox_seed
            // 
            this.tbox_seed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_seed.Location = new System.Drawing.Point(3, 7);
            this.tbox_seed.Name = "tbox_seed";
            this.tbox_seed.Size = new System.Drawing.Size(181, 21);
            this.tbox_seed.TabIndex = 0;
            // 
            // panel_tbox
            // 
            this.panel_tbox.Controls.Add(this.btn_search);
            this.panel_tbox.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_tbox.Location = new System.Drawing.Point(597, 0);
            this.panel_tbox.Name = "panel_tbox";
            this.panel_tbox.Padding = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.panel_tbox.Size = new System.Drawing.Size(89, 38);
            this.panel_tbox.TabIndex = 5;
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(6, 7);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(75, 23);
            this.btn_search.TabIndex = 0;
            this.btn_search.Text = "조회";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // panel_date
            // 
            this.panel_date.Controls.Add(this.label1);
            this.panel_date.Controls.Add(this.date_end);
            this.panel_date.Controls.Add(this.date_begin);
            this.panel_date.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_date.Location = new System.Drawing.Point(150, 0);
            this.panel_date.Name = "panel_date";
            this.panel_date.Padding = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.panel_date.Size = new System.Drawing.Size(260, 38);
            this.panel_date.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(120, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "~";
            // 
            // date_end
            // 
            this.date_end.Location = new System.Drawing.Point(137, 7);
            this.date_end.Name = "date_end";
            this.date_end.Size = new System.Drawing.Size(115, 21);
            this.date_end.TabIndex = 1;
            // 
            // date_begin
            // 
            this.date_begin.Location = new System.Drawing.Point(3, 7);
            this.date_begin.Name = "date_begin";
            this.date_begin.Size = new System.Drawing.Size(114, 21);
            this.date_begin.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cbox_search_kind);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.panel4.Size = new System.Drawing.Size(150, 38);
            this.panel4.TabIndex = 1;
            // 
            // cbox_search_kind
            // 
            this.cbox_search_kind.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbox_search_kind.FormattingEnabled = true;
            this.cbox_search_kind.Items.AddRange(new object[] {
            "입고",
            "출고"});
            this.cbox_search_kind.Location = new System.Drawing.Point(3, 7);
            this.cbox_search_kind.Name = "cbox_search_kind";
            this.cbox_search_kind.Size = new System.Drawing.Size(144, 20);
            this.cbox_search_kind.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btn_open);
            this.panel3.Controls.Add(this.btn_add);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(686, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(270, 38);
            this.panel3.TabIndex = 0;
            // 
            // btn_open
            // 
            this.btn_open.Location = new System.Drawing.Point(177, 9);
            this.btn_open.Name = "btn_open";
            this.btn_open.Size = new System.Drawing.Size(75, 23);
            this.btn_open.TabIndex = 2;
            this.btn_open.Text = "현황";
            this.btn_open.UseVisualStyleBackColor = true;
            this.btn_open.Click += new System.EventHandler(this.btn_open_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(11, 8);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 0;
            this.btn_add.Text = "입고";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.groupBox2);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 38);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(5);
            this.panel5.Size = new System.Drawing.Size(956, 497);
            this.panel5.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.grid_main);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(5, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox2.Size = new System.Drawing.Size(946, 487);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "목록";
            // 
            // grid_main
            // 
            this.grid_main.AllowUserToAddRows = false;
            this.grid_main.AllowUserToDeleteRows = false;
            this.grid_main.AutoGenerateColumns = false;
            this.grid_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idghcodeDataGridViewTextBoxColumn,
            this.idghdateDataGridViewTextBoxColumn,
            this.idghkindDataGridViewTextBoxColumn,
            this.idgcodeDataGridViewTextBoxColumn,
            this.odrdcodeDataGridViewTextBoxColumn,
            this.idghweightDataGridViewTextBoxColumn});
            this.grid_main.DataMember = "dp_supply";
            this.grid_main.DataSource = this.DisplaySet;
            this.grid_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_main.Location = new System.Drawing.Point(10, 24);
            this.grid_main.MultiSelect = false;
            this.grid_main.Name = "grid_main";
            this.grid_main.ReadOnly = true;
            this.grid_main.RowHeadersWidth = 20;
            this.grid_main.RowTemplate.Height = 23;
            this.grid_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_main.Size = new System.Drawing.Size(926, 453);
            this.grid_main.TabIndex = 1;
            // 
            // idghcodeDataGridViewTextBoxColumn
            // 
            this.idghcodeDataGridViewTextBoxColumn.DataPropertyName = "idgh_code";
            this.idghcodeDataGridViewTextBoxColumn.HeaderText = "idgh_code";
            this.idghcodeDataGridViewTextBoxColumn.Name = "idghcodeDataGridViewTextBoxColumn";
            this.idghcodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.idghcodeDataGridViewTextBoxColumn.Visible = false;
            // 
            // idghdateDataGridViewTextBoxColumn
            // 
            this.idghdateDataGridViewTextBoxColumn.DataPropertyName = "idgh_date";
            this.idghdateDataGridViewTextBoxColumn.HeaderText = "입출고 날짜";
            this.idghdateDataGridViewTextBoxColumn.Name = "idghdateDataGridViewTextBoxColumn";
            this.idghdateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // idghkindDataGridViewTextBoxColumn
            // 
            this.idghkindDataGridViewTextBoxColumn.DataPropertyName = "idgh_kind";
            this.idghkindDataGridViewTextBoxColumn.HeaderText = "입/출고";
            this.idghkindDataGridViewTextBoxColumn.Name = "idghkindDataGridViewTextBoxColumn";
            this.idghkindDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // idgcodeDataGridViewTextBoxColumn
            // 
            this.idgcodeDataGridViewTextBoxColumn.DataPropertyName = "idg_code";
            this.idgcodeDataGridViewTextBoxColumn.HeaderText = "idg_code";
            this.idgcodeDataGridViewTextBoxColumn.Name = "idgcodeDataGridViewTextBoxColumn";
            this.idgcodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.idgcodeDataGridViewTextBoxColumn.Visible = false;
            // 
            // odrdcodeDataGridViewTextBoxColumn
            // 
            this.odrdcodeDataGridViewTextBoxColumn.DataPropertyName = "odrd_code";
            this.odrdcodeDataGridViewTextBoxColumn.HeaderText = "odrd_code";
            this.odrdcodeDataGridViewTextBoxColumn.Name = "odrdcodeDataGridViewTextBoxColumn";
            this.odrdcodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.odrdcodeDataGridViewTextBoxColumn.Visible = false;
            // 
            // idghweightDataGridViewTextBoxColumn
            // 
            this.idghweightDataGridViewTextBoxColumn.DataPropertyName = "idgh_weight";
            this.idghweightDataGridViewTextBoxColumn.HeaderText = "무게";
            this.idghweightDataGridViewTextBoxColumn.Name = "idghweightDataGridViewTextBoxColumn";
            this.idghweightDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // DisplaySet
            // 
            this.DisplaySet.DataSetName = "NewDataSet";
            this.DisplaySet.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4,
            this.dataColumn5,
            this.dataColumn6});
            this.dataTable1.TableName = "dp_supply";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "idgh_code";
            this.dataColumn1.DataType = typeof(int);
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "idgh_date";
            this.dataColumn2.DataType = typeof(System.DateTime);
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "idgh_kind";
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "idg_code";
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "odrd_code";
            this.dataColumn5.DataType = typeof(int);
            // 
            // dataColumn6
            // 
            this.dataColumn6.ColumnName = "idgh_weight";
            // 
            // SupplyView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 535);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Name = "SupplyView";
            this.Text = "SupplyView";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel_tbox.ResumeLayout(false);
            this.panel_date.ResumeLayout(false);
            this.panel_date.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_date;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker date_end;
        private System.Windows.Forms.DateTimePicker date_begin;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox cbox_search_kind;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView grid_main;
        private System.Windows.Forms.Panel panel_tbox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbox_seed;
        private System.Windows.Forms.Button btn_search;
        private System.Data.DataSet DisplaySet;
        private System.Data.DataTable dataTable1;
        private System.Windows.Forms.Button btn_open;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Data.DataColumn dataColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn idghcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idghdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idghkindDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idgcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn odrdcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idghweightDataGridViewTextBoxColumn;
    }
}