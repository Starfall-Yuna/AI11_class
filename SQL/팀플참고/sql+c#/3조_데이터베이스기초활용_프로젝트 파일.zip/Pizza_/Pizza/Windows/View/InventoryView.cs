﻿using Lib.Frame;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza.Windows.View
{
    public partial class InventoryView : MasterView
    {
        public InventoryView()
        {
            InitializeComponent();
        }
    }
}
