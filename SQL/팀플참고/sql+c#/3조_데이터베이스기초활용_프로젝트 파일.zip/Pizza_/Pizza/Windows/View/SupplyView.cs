﻿
using Pizza.Manager;
using Lib.Frame;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lib.Util;
using Pizza.Windows.Pop;


namespace Pizza.Windows.View
{
    public partial class SupplyView : MasterView
    {
        public SupplyView()
        {
            InitializeComponent();
            Initialize();
        }
        private void Initialize() {
            cbox_search_kind.SelectedIndex = 0;
            
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            /*DataRow _row = GridAssist.SelectedRow(this.grid_main);
            if (_row != null) {
                SupplyAddPop _spadd = new SupplyAddPop();
                _spadd.ShowPop(ePopMode.None, _row);
            }*/
            Ingreident_Add _spadd = new Ingreident_Add();
            _spadd.ShowPop(ePopMode.Add);
        }

 

        private void btn_search_Click(object sender, EventArgs e) {
            string _key = cbox_search_kind.SelectedItem.ToString();
            switch (_key) {
                case "입고":
                    SearchByIngredients();
                   
                    break;
                case "출고":
                    SearchBySupply();
                    break;
                default:
                    MessageBox.Show("검색조건을 선택하세요");
                    break;
            }
        }
        private void SearchByIngredients() {
            string _seed = cbox_search_kind.Text;
           
            DataTable _dt = App.Self().DBManager.ReadItemByGR(_seed);
         
            if (_dt != null) {
                
                DataTable _dp_supply = DisplaySet.Tables["dp_supply"];
                _dp_supply.Rows.Clear();
                foreach (DataRow row in _dt.Rows) {
                    DataRow _dp_row = _dp_supply.NewRow();
                    _dp_row["idgh_code"] = row["idgh_code"];
                    _dp_row["idgh_date"] = row["idgh_date"];
                    _dp_row["idgh_kind"] = row["idgh_kind"];
                    _dp_row["idg_code"] = row["idg_code"];
                    _dp_row["odrd_code"] = row["odrd_code"];
                    _dp_row["idgh_weight"] = row["idgh_weight"];
                    _dp_supply.Rows.Add(_dp_row);
                }

            }
        }

        private void SearchBySupply() {
            string _seed = cbox_search_kind.Text;
            DataTable _dt = App.Self().DBManager.ReadOrder(_seed);
            if (_dt != null) {

                DataTable _dp_supply = DisplaySet.Tables["dp_supply"];
                _dp_supply.Rows.Clear();
                foreach (DataRow row in _dt.Rows) {
                    DataRow _dp_row = _dp_supply.NewRow();
                    _dp_row["idgh_code"] = row["idgh_code"];
                    _dp_row["idgh_date"] = row["idgh_date"];
                    _dp_row["idgh_kind"] = row["idgh_kind"];
                    _dp_row["idg_code"] = row["idg_code"];
                    _dp_row["odrd_code"] = row["odrd_code"];
                    _dp_row["idgh_weight"] = row["idgh_weight"];
                    _dp_supply.Rows.Add(_dp_row);
                }

            }
        }

        private void btn_open_Click(object sender, EventArgs e) {
            Ingreident _idg = new Ingreident();
            _idg.ShowPop(ePopMode.None);
        }

        private void button1_Click(object sender, EventArgs e) {

        }
    }
}
