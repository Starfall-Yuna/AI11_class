﻿using Lib.Frame;
using Pizza.Manager;
using Pizza.UserController;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Pizza.Windows.View {
    public partial class OrderView : MasterView
    {
        private Dictionary<string, int> m_toppings = new Dictionary<string, int>();
        private int _iBuffer = 1;
        private int m_btn_width = 100;
        private int m_btn_height = 100;
        private DataTable m_dt_item_comp = null;
        public OrderView()
        {
            InitializeComponent();
            InitializeMenu();
            InitializeTopping();
            InitializeDrink();
        }
        public override void InitializeView(string aKey, object aObject) {
            base.InitializeView(aKey, aObject);
            InitializeMenu();
            InitializeTopping();
            InitializeDrink();
        }
        private void InitializeMenu()
        {
            m_dt_item_comp = App.Self().DBManager.ReadItemComp();
            DataTable _dt_item = App.Self().DBManager.ReadMenu();
            if (_dt_item != null)
            {
                panel_goods.Controls.Clear();
                foreach (DataRow _dr in _dt_item.Rows)
                {
                    int _price = 0;
                    if (_dr["it_unit_Price"] != DBNull.Value)
                    {
                        _price = Convert.ToInt32(_dr["it_unit_Price"]);
                    }
                    int _it_code = -1;
                    if (_dr["it_code"] != DBNull.Value) {
                        _it_code = Convert.ToInt32(_dr["it_code"]);
                    }
                    string _it_picture = "";
                    if (_dr["it_picture"] != DBNull.Value) {
                        _it_picture = Convert.ToString(_dr["it_picture"]);
                    }

                    AddPizzaButton(_it_code, _dr["it_Name"].ToString(), _dr["it_Size"].ToString(), _price,_it_picture);
                }

            }
        }

        public void InitializeTopping()
        {
            DataTable _dt2 = App.Self().DBManager.ReadTopping();
            if (_dt2 != null)
            {
                m_toppings.Clear();
                panel_Topping.Controls.Clear();
                foreach (DataRow _dr in _dt2.Rows)
                {
                    int _price = 0;
                    if (_dr["idg_Price"] != DBNull.Value)
                    {
                        _price = Convert.ToInt32(_dr["idg_Price"]);
                    }
                    string _idg_picture = "";
                    if (_dr["idg_picture"] != DBNull.Value) {
                        _idg_picture = Convert.ToString(_dr["idg_picture"]);
                    }

                    AddToppingButton(_dr["idg_Name"].ToString(), _price,_idg_picture);
                    m_toppings.Add(_dr["idg_Name"].ToString(), _price);
                }

            }
        }

        private void InitializeDrink()
        {
            DataTable _dt = App.Self().DBManager.ReadDrink();
            if (_dt != null)
            {
                panel_drink.Controls.Clear();
                foreach (DataRow _dr in _dt.Rows)
                {
                    int _price = 0;
                    if (_dr["idg_price"] != DBNull.Value)
                    {
                        _price = Convert.ToInt32(_dr["idg_price"]);
                    }

                    int _idg_code = -1;
                    if (_dr["idg_code"] != DBNull.Value) {
                        _idg_code = Convert.ToInt32(_dr["idg_code"]);
                    }
                    string _idg_picture = "";
                    if (_dr["idg_picture"] != DBNull.Value) {
                        _idg_picture = Convert.ToString(_dr["idg_picture"]);
                    }
                    AddDrinkButton(_idg_code, _dr["idg_Name"].ToString(), _dr["idg_unit"].ToString(), _price, _idg_picture);
                }

            }
        }
        private void AddPizzaButton(int aGoodsCode, string aGoodsName, string aGoodsSize, int aPrice,string aPicture)
        {
            Button _btn_ = new Button();
            _btn_.Size = new Size(m_btn_width, m_btn_height);
            //_btn_.BackColor = Color.Aqua;

            _btn_.Tag = new GoodsInfo(aGoodsCode, aGoodsName, aGoodsSize, aPrice);
            if (aPicture.Length > 0) {
                byte[] _byte = HexStringToByteArray(aPicture);
                _btn_.BackgroundImage = new Bitmap(new MemoryStream(_byte));
            }
            
            // _btn_.BackgroundImage = Properties.Resources.pizza_0;
            _btn_.BackgroundImageLayout = ImageLayout.Stretch;
            _iBuffer += 3;
            _btn_.Paint += _pizza__Paint;
            _btn_.Click += _btn_pizza_Click;
            
            panel_goods.Controls.Add(_btn_);

            int _goods_count = panel_goods.Controls.Count;
            int _goods_width = panel_goods.Width;
            int _current_goods_index = _goods_count - 1;
            int _column_count = _goods_width / m_btn_width;
            int _row_index = _current_goods_index / _column_count;
            panel_goods.Height = m_btn_height * (_row_index + 1);

            ReLayoutPizza();
        }
        private byte[] HexStringToByteArray(string hex) {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            if (NumberChars % 2 == 0) {
                for (int i = 0; i < NumberChars; i += 2) {
                    bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
                }
            }
            return bytes;
        }

        private void AddToppingButton(string aGoodsName, int aPrice,string aPicture)
        {
            Button _btn_ = new Button();
            _btn_.Size = new Size(m_btn_width, m_btn_height);
            //_btn_.BackColor = Color.Aqua;

            _btn_.Tag = new GoodsInfo2(aGoodsName, aPrice);
            if (aPicture.Length > 0) {
                byte[] _byte = HexStringToByteArray(aPicture);
                _btn_.BackgroundImage = new Bitmap(new MemoryStream(_byte));
            }
            //_btn_.BackgroundImage = Properties.Resources.pizza_0;
            _btn_.BackgroundImageLayout = ImageLayout.Stretch;
            _iBuffer += 3;
            _btn_.Paint += _topping__Paint;
            _btn_.Click += _btn_topping_Click;
            panel_Topping.Controls.Add(_btn_);

            int _goods_count = panel_Topping.Controls.Count;
            int _goods_width = panel_Topping.Width;
            int _current_goods_index = _goods_count - 1;
            int _column_count = _goods_width / m_btn_width;
            int _row_index = _current_goods_index / _column_count;
            panel_Topping.Height = m_btn_height * (_row_index + 1);

            ReLayoutTopping();
        }

        private void AddDrinkButton(int aGoodsCode, string aGoodsName, string aGoodsSize, int aPrice,string aPicture)
        {
            Button _btn_ = new Button();
            _btn_.Size = new Size(m_btn_width, m_btn_height);
            //_btn_.BackColor = Color.Aqua;

            _btn_.Tag = new GoodsInfo(aGoodsCode, aGoodsName, aGoodsSize, aPrice);
            if (aPicture.Length > 0) {
                byte[] _byte = HexStringToByteArray(aPicture);
                _btn_.BackgroundImage = new Bitmap(new MemoryStream(_byte));
            }

           // _btn_.BackgroundImage = Properties.Resources.pizza_0;
            _btn_.BackgroundImageLayout = ImageLayout.Stretch;
            _iBuffer += 3;
            _btn_.Paint += _drink__Paint;
            _btn_.Click += _btn_drink_Click;
            panel_drink.Controls.Add(_btn_);

            int _goods_count = panel_drink.Controls.Count;
            int _goods_width = panel_drink.Width;
            int _current_goods_index = _goods_count - 1;
            int _column_count = _goods_width / m_btn_width;
            int _row_index = _current_goods_index / _column_count;
            panel_drink.Height = m_btn_height * (_row_index + 1);

            ReLayoutDrink();
        }

        private void ReLayoutPizza()
        {
            int _goods_count = panel_goods.Controls.Count;
            int _goods_width = panel_goods.Width;
            int _current_goods_index = _goods_count - 1;
            int _column_count = _goods_width / m_btn_width;
            int _index = 0;
            foreach (object item in panel_goods.Controls)
            {
                Button _btn_ = item as Button;
                if (_btn_ != null)
                {
                    int _row_index = _index / _column_count;
                    int _col_index = _index % _column_count;
                    _btn_.Location = new Point(_col_index * m_btn_width, _row_index * m_btn_height);
                    _index++;
                }
            }
        }

        private void ReLayoutTopping()
        {
            int _goods_count = panel_Topping.Controls.Count;
            int _goods_width = panel_Topping.Width;
            int _current_goods_index = _goods_count - 1;
            int _column_count = _goods_width / m_btn_width;
            int _index = 0;
            foreach (object item in panel_Topping.Controls)
            {
                Button _btn_ = item as Button;
                if (_btn_ != null)
                {
                    int _row_index = _index / _column_count;
                    int _col_index = _index % _column_count;
                    _btn_.Location = new Point(_col_index * m_btn_width, _row_index * m_btn_height);
                    _index++;
                }
            }
        }

        private void ReLayoutDrink()
        {
            int _goods_count = panel_drink.Controls.Count;
            int _goods_width = panel_drink.Width;
            int _current_goods_index = _goods_count - 1;
            int _column_count = _goods_width / m_btn_width;
            int _index = 0;
            foreach (object item in panel_drink.Controls)
            {
                Button _btn_ = item as Button;
                if (_btn_ != null)
                {
                    int _row_index = _index / _column_count;
                    int _col_index = _index % _column_count;
                    _btn_.Location = new Point(_col_index * m_btn_width, _row_index * m_btn_height);
                    _index++;
                }
            }
        }
        private void panel_goods_Resize(object sender, EventArgs e)
        {
            if (panel_scroll3.Width > panel_menu.Height)
            {
                panel_menu.Width = panel_scroll3.Width;
            }
            else
            {
                panel_menu.Width = panel_scroll3.Width-21;

            }
            ReLayoutPizza();
        }

        private void panel_goods_Resize2(object sender, EventArgs e)
        {
            ReLayoutTopping();
        }

        private void panel_goods_REsize3(object sender, EventArgs e)
        {
            ReLayoutDrink();
        }

        /*private void btn_p1_Click(object sender, EventArgs e)
        {
            DataTable _dp_menu = DisplaySet1.Tables["dp_order"];

            string menu_name = "Cheese Pizza";
            int p1_count = 1;
            int menu_price = 10000;

            DataRow[] _rows = _dp_menu.Select($"menu = '{menu_name}'");
            if (_rows != null && _rows.Length > 0)
            {
                DataRow _curr_row = _rows[0];
                _curr_row["count"] = Convert.ToInt32(_curr_row["count"]) + 1;
            }
            else
            {

                DataRow _dp_row = _dp_menu.NewRow();
                _dp_row["menu"] = menu_name;
                _dp_row["count"] = p1_count;
                _dp_row["price"] = menu_price;
                _dp_menu.Rows.Add(_dp_row);

            }
        }*/

        private Size m_btn_size;
        /*private void button2_Click(object sender, EventArgs e)
        {
            DataTable _dt = App.Self().DBManager.ReadMenu();
            if (_dt != null)
            {
                panel_goods.Controls.Clear();
                foreach (DataRow _dr in _dt.Rows)
                {
                    int _price = 0;
                    if (_dr["it_Price"] != DBNull.Value)
                    {
                        _price = Convert.ToInt32(_dr["it_Price"]);
                    }

                    AddButton(_dr["it_Name"].ToString(), _price);
                }

            }
        }*/
        private void _pizza__Paint(object sender, PaintEventArgs e)
        {
            StringFormat _fmt = new StringFormat();
            _fmt.Alignment = StringAlignment.Center;
            _fmt.LineAlignment = StringAlignment.Center;
            Button _btn_ = sender as Button;
            Graphics _g = e.Graphics;
            GoodsInfo _info = _btn_.Tag as GoodsInfo;
            if (_info != null)
            {
                _g.DrawString(_info.GoodsName +"[" + _info.GoodsSize + "]", this.Font, Brushes.Blue, new Rectangle(0, 50, 100, 25), _fmt);

                using (Pen pen = new Pen(Color.White, 2))
                {
                    Rectangle _rc = new Rectangle(0, 75, 100, 25);
                    _rc.Offset(1, 1);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(-2, 0);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(0, -2);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(2, 0);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(-1, 1);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, pen.Brush, _rc, _fmt);
                }
                //_g.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Red, ,_fmt);
            }
        }

        private void _topping__Paint(object sender, PaintEventArgs e)
        {
            StringFormat _fmt = new StringFormat();
            _fmt.Alignment = StringAlignment.Center;
            _fmt.LineAlignment = StringAlignment.Center;
            Button _btn_ = sender as Button;
            Graphics _g = e.Graphics;
            GoodsInfo2 _info = _btn_.Tag as GoodsInfo2;
            if (_info != null)
            {
                _g.DrawString(_info.GoodsName2, this.Font, Brushes.Blue, new Rectangle(0, 50, 100, 25), _fmt);

                using (Pen pen = new Pen(Color.White, 2))
                {
                    Rectangle _rc = new Rectangle(0, 75, 100, 25);
                    _rc.Offset(1, 1);
                    e.Graphics.DrawString(_info.GoodsPrice2.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(-2, 0);
                    e.Graphics.DrawString(_info.GoodsPrice2.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(0, -2);
                    e.Graphics.DrawString(_info.GoodsPrice2.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(2, 0);
                    e.Graphics.DrawString(_info.GoodsPrice2.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(-1, 1);
                    e.Graphics.DrawString(_info.GoodsPrice2.ToString(), this.Font, pen.Brush, _rc, _fmt);
                }
                //_g.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Red, ,_fmt);
            }
        }

        private void _drink__Paint(object sender, PaintEventArgs e)
        {
            StringFormat _fmt = new StringFormat();
            _fmt.Alignment = StringAlignment.Center;
            _fmt.LineAlignment = StringAlignment.Center;
            Button _btn_ = sender as Button;
            Graphics _g = e.Graphics;
            GoodsInfo _info = _btn_.Tag as GoodsInfo;
            if (_info != null)
            {
                _g.DrawString(_info.GoodsName, this.Font, Brushes.Blue, new Rectangle(0, 50, 100, 25), _fmt);

                using (Pen pen = new Pen(Color.White, 2))
                {
                    Rectangle _rc = new Rectangle(0, 75, 100, 25);
                    _rc.Offset(1, 1);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(-2, 0);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(0, -2);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(2, 0);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Black, _rc, _fmt);
                    _rc.Offset(-1, 1);
                    e.Graphics.DrawString(_info.GoodsPrice.ToString(), this.Font, pen.Brush, _rc, _fmt);
                }
                //_g.DrawString(_info.GoodsPrice.ToString(), this.Font, Brushes.Red, ,_fmt);
            }
        }
        private void DeployOrder()
        {
            int _y = 0;
            foreach( object _item in panel_menu.Controls)
            {
                OrderButton _obtn = _item as OrderButton;
                if (_obtn != null && _obtn.ItemToppingable == true)
                {
                    _obtn.Location = new Point(0, _y);
                    if(_obtn.ItemToppings.Count > 0)
                    {
                        _obtn.Height = 99;
                    }
                    else
                    {
                        _obtn.Height = 66;
                    }
                    _y += _obtn.Height;
                    _obtn.Width = panel_menu.Width;

                }
            }

            foreach (object _item in panel_menu.Controls)
            {
                OrderButton _obtn = _item as OrderButton;
                if (_obtn != null && _obtn.ItemToppingable == false)
                {
                    _obtn.Location = new Point(0, _y); _obtn.Height = 66;
                    _y += _obtn.Height;
                    _obtn.Width = panel_menu.Width;

                }
            }

            panel_menu.Height = _y;

            if(panel_scroll3.Height > panel_menu.Height)
            {
                panel_menu.Width = panel_scroll3.Width;
            } 
            else
            {
                panel_menu.Width = panel_scroll3.Width-21;
            }
        }
        private void panel_goods_Paint(object sender, PaintEventArgs e)
        {

        }
        private int m_item_num = 1;
        private void _btn_pizza_Click(object sender, EventArgs e)
        {
            //DataTable _dp_menu = DisplaySet.Tables["dp_order"];
            Button _btn_ = sender as Button;
            if (_btn_ != null)
            {
                OrderButton _obtn_ = new OrderButton();
                panel_menu.Controls.Add(_obtn_);
                _obtn_.Location = new Point(0, 0);                
                _obtn_.ItemToppingable = true;
                _obtn_.OnClickSelected += ClickOrderButton;
                _obtn_.OnChangePrice += ChangePrice;
                _obtn_.OnClickCancel += ClickCancelOrder;
                _obtn_.ItemSelected = true;
                _obtn_.ItemNum = m_item_num++;
                _obtn_.Tag = _btn_.Tag;
                ClickOrderButton(null, _obtn_.ItemNum);
                DeployOrder();

                //string _msg;
                GoodsInfo _info = _btn_.Tag as GoodsInfo;
                if (_info != null)
                {

                    _obtn_.AddItem(_info.GoodsName + "[" + _info.GoodsSize + "]");
                    _obtn_.AddPrice(_info.GoodsPrice);
                    
                }
                
            }
        }

        private int ClickCancelOrder(object Sender, object aObject)
        {
            int itemNum = Convert.ToInt32(aObject);
            foreach(object _obj in panel_menu.Controls)
            {
                OrderButton _obtn = _obj as OrderButton;
                if (_obtn != null && _obtn.ItemNum == itemNum) 
                {
                    panel_menu.Controls.Remove(_obtn);
                    ChangePrice(null, null);
                    DeployOrder();
                    break;
                }
            }
            return 0;
        }

        private int ChangePrice(object Sender, object aObject)
        {
            int _sum = 0;
            foreach(object _ctr in panel_menu.Controls)
            {
                OrderButton _obtn = _ctr as OrderButton;
                if (_obtn != null)
                {
                    _sum += (_obtn.ItemPrice + _obtn.ToppingPrice) * _obtn.ItemAmount;
                }
            }
            lbl_Sum.Text = string.Format("{0:N0}",_sum) + "원";
            return _sum;
        }


        
        private int m_current_itemnum = -1;
        private int ClickOrderButton(object Sender, object aObject)
        {
            int _itemNum = Convert.ToInt32(aObject);
            foreach (object _item in panel_menu.Controls)
            {
                OrderButton _obtn = _item as OrderButton;
                if (_obtn != null && _obtn.ItemNum == _itemNum)
                {
                    _obtn.ItemSelected = true;
                    m_current_itemnum = _itemNum;
                } else
                {
                    _obtn.ItemSelected = false;

                }
            }
            return 0;
        }

        private void panel_Topping_Paint(object sender, PaintEventArgs e)
        {

        }
        private void _btn_topping_Click(object sender, EventArgs e)
        {
            Button _btn_ = sender as Button;
            if(_btn_ != null)
            {
                GoodsInfo2 _info = _btn_.Tag as GoodsInfo2;
                if(_info != null)
                {
                    //orderButton1.AddTopping(_info.GoodsName2);
                    //선택된 주문찾기
                    foreach(object _item in panel_menu.Controls)
                    {
                        OrderButton _obtn = _item as OrderButton;
                        if(_obtn != null && _obtn.ItemSelected == true && _obtn.ItemToppingable == true )
                        {
                            _obtn.AddTopping(_info.GoodsName2);
                            int _topping_price = 0;
                            ArrayList _toppings = _obtn.ItemToppings;
                            foreach(string _toppingName in _toppings)
                            {
                                if (m_toppings.ContainsKey(_toppingName))
                                {
                                    _topping_price += Convert.ToInt32(m_toppings[_toppingName]);
                                    
                                }
                            }
                            _obtn.AddToppingPrice(_topping_price);

                            DeployOrder();
                            break;
                        }

                    }

                }
            }
            
        }

        private void panel_drink_Paint(object sender, PaintEventArgs e)
        {

        }
        private void _btn_drink_Click(object sender, EventArgs e)
        {
            Button _btn_ = sender as Button;
            if (_btn_ != null)
            {
                //string _msg;
                GoodsInfo _info = _btn_.Tag as GoodsInfo;
                if (_info != null)
                {
                    bool _exist = false;
                    foreach(object _obj in panel_menu.Controls)
                    {
                        OrderButton _btn = _obj as OrderButton;
                        if (_btn != null)
                        {                            
                            if (_btn.ItemName == $"{_info.GoodsName}[{_info.GoodsSize}]") { 
                                _exist = true;
                                _btn.ItemAmount++; //789
                                break;
                            }
                        }
                    }

                    if (_exist == false) {
                    
                        OrderButton _obtn_ = new OrderButton();
                        panel_menu.Controls.Add(_obtn_);
                        _obtn_.Location = new Point(0, 0);
                        _obtn_.ItemToppingable = false;
                        _obtn_.OnClickSelected += ClickOrderButton;
                        _obtn_.OnChangePrice += ChangePrice;
                        _obtn_.OnClickCancel += ClickCancelOrder;
                        _obtn_.ItemSelected = true;
                        _obtn_.ItemNum = m_item_num++;
                        _obtn_.Tag = _btn_.Tag;
                        ClickOrderButton(null, _obtn_.ItemNum);
                        DeployOrder();


                        _obtn_.AddDrink(_info.GoodsName + "[" + _info.GoodsSize + "]");
                        _obtn_.AddDrinkPrice(_info.GoodsPrice);
                    }

                }

            }
        }
        private void grid_list_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_Pay_Click(object sender, EventArgs e)
        {
            ArrayList _sqlArray = new ArrayList();
            string _strQuery = ""; 
            int _odr_code = App.Self().DBManager.ReadSeq("ORDER_SEQ"); 
            int _odr_sum = 0;
            foreach (object _obj in panel_menu.Controls) { 
                OrderButton _obtn = _obj as OrderButton;
                if (_obtn != null) {
                    GoodsInfo _info = _obtn.Tag as GoodsInfo;
                    string _toppings = string.Join(",", _obtn.ItemToppings.ToArray());
                    _strQuery = "INSERT INTO order_detail (odrd_code,odrd_ea,odrd_toppings,odrd_item_price,odr_code,it_code,odrd_toppings_price) ";
                    _strQuery += $" VALUES ( SEQ_ODR_DETAIL.nextval, {_obtn.ItemAmount},'{_toppings}',{_obtn.ItemPrice}, {_odr_code},{_info.GoodsCode}, {_obtn.ToppingPrice}) ";
                    _sqlArray.Add(_strQuery);

                    DataRow [] _rows = m_dt_item_comp.Select($"it_code = {_info.GoodsCode}");
                    foreach (DataRow _row in _rows) {
                        int _weight = 0;
                        if (_row["itc_consumption"] != DBNull.Value) {
                            _weight = Convert.ToInt32(_row["itc_consumption"]);
                        }
                        int _idg_code = -1;
                        if (_row["idg_code"] != DBNull.Value) {
                            _idg_code = Convert.ToInt32(_row["idg_code"]);
                        }
                        if(_idg_code>=0) {
                            _strQuery = "INSERT INTO ingredient_history (idgh_code,idgh_date,idgh_kind,idg_code,odrd_code,idgh_weight) ";
                            _strQuery += $" VALUES (SEQ_IDGH.nextval, SYSDATE, '출고', '{_idg_code}',SEQ_ODR_DETAIL.currval,{_weight}) ";
                            _sqlArray.Add(_strQuery);

                            _strQuery = $"UPDATE ingredient SET idg_stock = idg_stock - {_weight} WHERE idg_code = {_idg_code} ";
                            _sqlArray.Add(_strQuery);
                        }
                    }
                    //총 결재금액
                    _odr_sum += (_obtn.ItemPrice+_obtn.ToppingPrice) * _obtn.ItemAmount;
                }
            }
            //주문만들기
            _strQuery = "INSERT INTO orders (odr_code,odr_date,odr_price,odr_state,mbr_code,stf_id) ";
            _strQuery += $"VALUES ({_odr_code},SYSDATE,{_odr_sum},1,null,null) ";
            _sqlArray.Insert(0, _strQuery); 


            int _result = App.Self().DBManager.SaveOrder(_sqlArray);

            if (_result > 0) {
                MessageBox.Show("결제되었습니다.\n감사합니다.");
                panel_menu.Controls.Clear();
            }
            else {
                MessageBox.Show("실패");
            }
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            panel_menu.Controls.Clear();
            lbl_Sum.Controls.Clear();
            lbl_Sum.Text = "0원";
        }

        private void panel_menu_Resize(object sender, EventArgs e)
        {
            DeployOrder();
        }

        private void label1_Click(object sender, EventArgs e) {

        }
    }
    public class GoodsInfo {
        public int GoodsCode { get; set; }
        public string GoodsName { get; set; }
        public int GoodsPrice { get; set; }

        public string GoodsSize { get; set; }
        public string GoodsPicture { get; set; }

        public GoodsInfo() { }
        public GoodsInfo(int aGoodsCode, string aGoodsName, string aGoodsSize, int aGoodsPrice)
        {
            GoodsCode = aGoodsCode;
            GoodsName = aGoodsName;
            GoodsSize = aGoodsSize;
            GoodsPrice = aGoodsPrice;
            
        }
    }

    public class GoodsInfo2
    {
        public string GoodsName2 { get; set; }
        public int GoodsPrice2 { get; set; }

        public GoodsInfo2() { }
        public GoodsInfo2(string aGoodsName2, int aGoodsPrice2)
        {
            GoodsName2 = aGoodsName2;
            
            GoodsPrice2 = aGoodsPrice2;

        }
    }
}
