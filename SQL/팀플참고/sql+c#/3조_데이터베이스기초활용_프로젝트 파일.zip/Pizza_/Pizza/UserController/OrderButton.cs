﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza.UserController
{
    public partial class OrderButton : UserControl
    {
        public delegate int evtButton(object Sender, object aObject);   // delegate 선언
        public event evtButton OnClickDelete;
        public event evtButton OnClickSelected;
        public event evtButton OnClickCancel;
        public event evtButton OnChangePrice;

        private int m_Item_num = 0;
        [Category("UserProperty"), Description("ItemNum")]

        public int ItemNum
        {
            get
            {
                return m_Item_num;// Convert.ToInt32(this.label_issue_num.Text);
            }
            set
            {
                m_Item_num = value;
            }
        }

        private int m_Item_price = 0;
        [Category("UserProperty"), Description("ItemPrice")]

        public int ItemPrice
        {
            get
            {
                return m_Item_price;// Convert.ToInt32(this.label_issue_num.Text);
            }
            set
            {
                m_Item_price = value;
            }
        }

        private int m_Topping_price = 0;
        [Category("UserProperty"), Description("ItemPrice")]

        public int ToppingPrice
        {
            get
            {
                return m_Topping_price;// Convert.ToInt32(this.label_issue_num.Text);
            }
            set
            {
                m_Topping_price = value;
            }
        }

        private int m_Drink_price = 0;
        [Category("UserProperty"), Description("ItemPrice")]

        public int DrinkPrice
        {
            get
            {
                return m_Drink_price;// Convert.ToInt32(this.label_issue_num.Text);
            }
            set
            {
                m_Drink_price = value;
            }
        }

        private bool m_Item_Toppingable = false;
        [Category("UserProperty"), Description("ItemToppingable")]

        public bool ItemToppingable
        {
            get
            {
                return m_Item_Toppingable;// Convert.ToInt32(this.label_issue_num.Text);
            }
            set
            {
                m_Item_Toppingable = value;
            }
        }


        private bool m_ItemSelected = false;
        [Category("UserProperty"), Description("ItemSelected")]
        public bool ItemSelected
        {
            get
            {
                return m_ItemSelected;// Convert.ToInt32(this.label_issue_num.Text);
            }
            set
            {
                m_ItemSelected = value;
                if (m_ItemSelected)
                {

                    this.BackColor = Color.Blue;
                }
                else
                {
                    this.BackColor = Color.White;
                }
            }
        }

        private int m_ItemAmount = 1;
        [Category("UserProperty"), Description("ItemAmount")]
        public int ItemAmount
        {
            get
            {
                return m_ItemAmount;// Convert.ToInt32(this.label_issue_num.Text);
            }
            set
            {
                m_ItemAmount = value;
                this.lbl_amount.Text = m_ItemAmount.ToString();
                this.lbl_price.Text = ((m_Item_price + m_Topping_price) * ItemAmount).ToString();
                ChangePrice();
            }
        }

        private string m_ItemName;
        [Category("UserProperty"), Description("ItemName")]
        public string ItemName
        {
            get
            {
                return m_ItemName;// Convert.ToInt32(this.label_issue_num.Text);
            }
            set
            {
                m_ItemName = value;
                this.lbl_title.Text = m_ItemName;
            }
        }
        private ArrayList m_toppings;
        [Category("UserProperty"), Description("ItemToppings")]
        public ArrayList ItemToppings
        {
            get
            {
                return m_toppings;// Convert.ToInt32(this.label_issue_num.Text);
            }
            set
            {
                m_toppings = value;
                // this.lbl_topping.Text = string.Join(",", m_toppings);
            }
        }
        
        public void AddItem(string aItem)
        {
            m_ItemName = aItem;
            this.lbl_title.Text = m_ItemName;
            this.Height = 66;
        }

        public void AddPrice(int aPrice)
        {
            m_Item_price = aPrice;
            this.lbl_price.Text = m_Item_price.ToString();
            //this.Height = 99;
            ChangePrice();
        }
        public void AddTopping(string aTopping)
        {
            
            if (m_toppings.Contains(aTopping))
            {
                m_toppings.Remove(aTopping);
            } 
            else
            { 
                m_toppings.Add(aTopping); 
            }
            this.lbl_topping.Text = string.Join(",", m_toppings.ToArray());
            if (m_toppings.Count > 0) 
            { 
                this.Height = 99;
            } 
            else 
            { 
                this.Height = 66;
            }
        }

        public void SubTopping(string aTopping)
        {
            if (m_toppings.Contains(aTopping))
            {
                m_toppings.Remove(aTopping);
            }
            this.lbl_topping.Text = string.Join(",", m_toppings.ToArray());
            if (m_toppings.Count > 0) { this.Height = 99; } else { this.Height = 66; }
        }

        public void AddToppingPrice(int aPrice)
        {
            m_Topping_price = aPrice;
            if (m_Item_price.ToString() != null)
            {
                //this.lbl_price.Text = (m_Item_price + m_Topping_price).ToString();
                this.lbl_price.Text = ((m_Item_price + m_Topping_price) * ItemAmount).ToString();
                //this.Height = 99; 
                ChangePrice();
            }            
        }

        public void AddDrink(string aDrink)
        {
            m_ItemName = aDrink;
            this.lbl_title.Text = m_ItemName;
            this.Height = 33;
        }

        public void AddDrinkPrice(int aDrinkPrice)
        {
            m_Item_price = aDrinkPrice;
            this.lbl_price.Text = m_Item_price.ToString();
            this.Height = 66;
            ChangePrice();
        }

        private void ChangePrice()
        {
            if(OnChangePrice != null)
            {
                OnChangePrice(this, Convert.ToInt32(this.lbl_price.Text));
            }
        }

        
        public OrderButton()
        {
            InitializeComponent();
            m_toppings = new ArrayList();
            this.Height = 66;
            
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            ItemAmount++;
            this.lbl_price.Text = ((m_Item_price + m_Topping_price)*ItemAmount).ToString();
            if (ItemAmount != 0)
            {
                btn_sub.Enabled = true;
            }
        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            ItemAmount--;
            this.lbl_price.Text = ((m_Item_price + m_Topping_price) * ItemAmount).ToString();
            if (ItemAmount == 0)
            {
                btn_sub.Enabled = false;
            }
        }

        private void lbl_title_Click(object sender, EventArgs e)
        {
            ItemSelected = true;
            if (OnClickSelected != null)
            {
                OnClickSelected(this, m_Item_num);
            }
        }

        private void lbl_topping_Click(object sender, EventArgs e)
        {
            ItemSelected = true;
            if (OnClickSelected != null)
            {
                OnClickSelected(this, m_Item_num);
            }
        }

        private void lbl_price_Click(object sender, EventArgs e)
        {
            ItemSelected = true;
            if (OnClickSelected != null)
            {
                OnClickSelected(this, m_Item_num);
            }
        }

        private void pnl_buttons_Click(object sender, EventArgs e)
        {
            ItemSelected = true;
            if (OnClickSelected != null)
            {
                OnClickSelected(this, m_Item_num);
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {

            if (OnClickCancel != null)
            {
                OnClickCancel(this, m_Item_num);
            }
        }
    }

}
