﻿namespace Pizza.UserController
{
    partial class OrderButton
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_base = new System.Windows.Forms.Panel();
            this.pnl_itemtopping = new System.Windows.Forms.Panel();
            this.lbl_topping = new System.Windows.Forms.Label();
            this.pnl_itemmenu = new System.Windows.Forms.Panel();
            this.lbl_title = new System.Windows.Forms.Label();
            this.pnl_buttons = new System.Windows.Forms.Panel();
            this.pnl_price = new System.Windows.Forms.Panel();
            this.lbl_price = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.lbl_amount = new System.Windows.Forms.Label();
            this.btn_sub = new System.Windows.Forms.Button();
            this.pnl_base.SuspendLayout();
            this.pnl_itemtopping.SuspendLayout();
            this.pnl_itemmenu.SuspendLayout();
            this.pnl_buttons.SuspendLayout();
            this.pnl_price.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_base
            // 
            this.pnl_base.BackColor = System.Drawing.SystemColors.Control;
            this.pnl_base.Controls.Add(this.pnl_itemtopping);
            this.pnl_base.Controls.Add(this.pnl_itemmenu);
            this.pnl_base.Controls.Add(this.pnl_buttons);
            this.pnl_base.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_base.Location = new System.Drawing.Point(3, 3);
            this.pnl_base.Name = "pnl_base";
            this.pnl_base.Size = new System.Drawing.Size(301, 62);
            this.pnl_base.TabIndex = 0;
            // 
            // pnl_itemtopping
            // 
            this.pnl_itemtopping.Controls.Add(this.lbl_topping);
            this.pnl_itemtopping.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_itemtopping.Location = new System.Drawing.Point(0, 31);
            this.pnl_itemtopping.Name = "pnl_itemtopping";
            this.pnl_itemtopping.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.pnl_itemtopping.Size = new System.Drawing.Size(301, 0);
            this.pnl_itemtopping.TabIndex = 2;
            // 
            // lbl_topping
            // 
            this.lbl_topping.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_topping.Location = new System.Drawing.Point(3, 0);
            this.lbl_topping.Name = "lbl_topping";
            this.lbl_topping.Size = new System.Drawing.Size(295, 0);
            this.lbl_topping.TabIndex = 1;
            this.lbl_topping.Text = "label2";
            this.lbl_topping.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_topping.Click += new System.EventHandler(this.lbl_topping_Click);
            // 
            // pnl_itemmenu
            // 
            this.pnl_itemmenu.Controls.Add(this.lbl_title);
            this.pnl_itemmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_itemmenu.Location = new System.Drawing.Point(0, 0);
            this.pnl_itemmenu.Name = "pnl_itemmenu";
            this.pnl_itemmenu.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.pnl_itemmenu.Size = new System.Drawing.Size(301, 31);
            this.pnl_itemmenu.TabIndex = 1;
            // 
            // lbl_title
            // 
            this.lbl_title.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_title.Location = new System.Drawing.Point(3, 0);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(295, 31);
            this.lbl_title.TabIndex = 0;
            this.lbl_title.Text = "label1";
            this.lbl_title.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_title.Click += new System.EventHandler(this.lbl_title_Click);
            // 
            // pnl_buttons
            // 
            this.pnl_buttons.Controls.Add(this.pnl_price);
            this.pnl_buttons.Controls.Add(this.panel1);
            this.pnl_buttons.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_buttons.Location = new System.Drawing.Point(0, 29);
            this.pnl_buttons.Name = "pnl_buttons";
            this.pnl_buttons.Size = new System.Drawing.Size(301, 33);
            this.pnl_buttons.TabIndex = 0;
            this.pnl_buttons.Click += new System.EventHandler(this.pnl_buttons_Click);
            // 
            // pnl_price
            // 
            this.pnl_price.Controls.Add(this.lbl_price);
            this.pnl_price.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_price.Location = new System.Drawing.Point(0, 0);
            this.pnl_price.Name = "pnl_price";
            this.pnl_price.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.pnl_price.Size = new System.Drawing.Size(118, 33);
            this.pnl_price.TabIndex = 6;
            // 
            // lbl_price
            // 
            this.lbl_price.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_price.Location = new System.Drawing.Point(3, 0);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(112, 33);
            this.lbl_price.TabIndex = 0;
            this.lbl_price.Text = "label1";
            this.lbl_price.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_price.Click += new System.EventHandler(this.lbl_price_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_cancel);
            this.panel1.Controls.Add(this.btn_add);
            this.panel1.Controls.Add(this.lbl_amount);
            this.panel1.Controls.Add(this.btn_sub);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(118, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(183, 33);
            this.panel1.TabIndex = 5;
            // 
            // btn_cancel
            // 
            this.btn_cancel.Location = new System.Drawing.Point(118, 6);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(62, 23);
            this.btn_cancel.TabIndex = 3;
            this.btn_cancel.Text = "취소";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(5, 6);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(24, 23);
            this.btn_add.TabIndex = 1;
            this.btn_add.Text = "+";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // lbl_amount
            // 
            this.lbl_amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_amount.Location = new System.Drawing.Point(33, 6);
            this.lbl_amount.Name = "lbl_amount";
            this.lbl_amount.Size = new System.Drawing.Size(41, 23);
            this.lbl_amount.TabIndex = 4;
            this.lbl_amount.Text = "1";
            this.lbl_amount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_sub
            // 
            this.btn_sub.Location = new System.Drawing.Point(79, 6);
            this.btn_sub.Name = "btn_sub";
            this.btn_sub.Size = new System.Drawing.Size(24, 23);
            this.btn_sub.TabIndex = 2;
            this.btn_sub.Text = "-";
            this.btn_sub.UseVisualStyleBackColor = true;
            this.btn_sub.Click += new System.EventHandler(this.btn_sub_Click);
            // 
            // OrderButton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.pnl_base);
            this.Name = "OrderButton";
            this.Padding = new System.Windows.Forms.Padding(3);
            this.Size = new System.Drawing.Size(307, 68);
            this.pnl_base.ResumeLayout(false);
            this.pnl_itemtopping.ResumeLayout(false);
            this.pnl_itemmenu.ResumeLayout(false);
            this.pnl_buttons.ResumeLayout(false);
            this.pnl_price.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_base;
        private System.Windows.Forms.Panel pnl_itemtopping;
        private System.Windows.Forms.Label lbl_topping;
        private System.Windows.Forms.Panel pnl_itemmenu;
        private System.Windows.Forms.Label lbl_title;
        private System.Windows.Forms.Panel pnl_buttons;
        private System.Windows.Forms.Label lbl_amount;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_sub;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.Panel pnl_price;
        private System.Windows.Forms.Panel panel1;
    }
}
