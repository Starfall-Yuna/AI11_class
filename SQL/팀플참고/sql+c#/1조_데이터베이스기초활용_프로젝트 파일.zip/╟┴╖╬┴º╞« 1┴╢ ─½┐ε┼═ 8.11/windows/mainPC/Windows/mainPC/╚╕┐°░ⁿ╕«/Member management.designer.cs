﻿namespace PC.Windows.mainPC.회원관리 {
    partial class Member_Management {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tbox_MBM_search = new System.Windows.Forms.RichTextBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btn_MBM_search = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_MBM_delete = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_MBM_add = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label_main_title = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.btn_MBM_close = new System.Windows.Forms.Button();
            this.grid_member_view = new System.Windows.Forms.DataGridView();
            this.gridselectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.mbnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mbidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mbphDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DisplaySet = new System.Data.DataSet();
            this.회원 = new System.Data.DataTable();
            this.이름 = new System.Data.DataColumn();
            this.ID = new System.Data.DataColumn();
            this.PH = new System.Data.DataColumn();
            this.check = new System.Data.DataColumn();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.tbox_MBM_member_memo = new System.Windows.Forms.RichTextBox();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label_MBM_member_memo = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.date_MBM_member_newdate = new System.Windows.Forms.DateTimePicker();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label_MBM_member_newdate = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.date_MBM_member_birthdate = new System.Windows.Forms.DateTimePicker();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label_MBM_member_birthdate = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.tbox_MBM_member_ph = new System.Windows.Forms.TextBox();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label_MBM_member_ph = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.tbox_MBM_member_pw = new System.Windows.Forms.TextBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label_MBM_member_pw = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.tbox_MBM_member_id = new System.Windows.Forms.TextBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label_MBM_member_id = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.tbox_MBM_member_name = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label_MBM_member_name = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.tbox_MBM_member_num = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label_MBM_member_code = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label_title2 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.btn_MBM_member_cancle = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btn_MBM_member_save = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btn_MBM_member_modify = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_member_view)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.회원)).BeginInit();
            this.panel7.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel12);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(3);
            this.panel1.Size = new System.Drawing.Size(720, 44);
            this.panel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.tbox_MBM_search);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(482, 3);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(3);
            this.panel6.Size = new System.Drawing.Size(153, 36);
            this.panel6.TabIndex = 5;
            // 
            // tbox_MBM_search
            // 
            this.tbox_MBM_search.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_MBM_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbox_MBM_search.Location = new System.Drawing.Point(3, 3);
            this.tbox_MBM_search.MaxLength = 20;
            this.tbox_MBM_search.Multiline = false;
            this.tbox_MBM_search.Name = "tbox_MBM_search";
            this.tbox_MBM_search.Size = new System.Drawing.Size(147, 30);
            this.tbox_MBM_search.TabIndex = 0;
            this.tbox_MBM_search.Text = "";
            this.tbox_MBM_search.WordWrap = false;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.btn_MBM_search);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel12.Location = new System.Drawing.Point(635, 3);
            this.panel12.Name = "panel12";
            this.panel12.Padding = new System.Windows.Forms.Padding(3);
            this.panel12.Size = new System.Drawing.Size(80, 36);
            this.panel12.TabIndex = 4;
            // 
            // btn_MBM_search
            // 
            this.btn_MBM_search.BackColor = System.Drawing.Color.Black;
            this.btn_MBM_search.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_MBM_search.ForeColor = System.Drawing.Color.Gold;
            this.btn_MBM_search.Location = new System.Drawing.Point(3, 3);
            this.btn_MBM_search.Name = "btn_MBM_search";
            this.btn_MBM_search.Size = new System.Drawing.Size(74, 30);
            this.btn_MBM_search.TabIndex = 2;
            this.btn_MBM_search.Text = "조회";
            this.btn_MBM_search.UseVisualStyleBackColor = false;
            this.btn_MBM_search.Click += new System.EventHandler(this.MBM_search_btn_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btn_MBM_delete);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(365, 3);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(3);
            this.panel5.Size = new System.Drawing.Size(117, 36);
            this.panel5.TabIndex = 2;
            // 
            // btn_MBM_delete
            // 
            this.btn_MBM_delete.BackColor = System.Drawing.Color.Black;
            this.btn_MBM_delete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_MBM_delete.ForeColor = System.Drawing.Color.Gold;
            this.btn_MBM_delete.Location = new System.Drawing.Point(3, 3);
            this.btn_MBM_delete.Name = "btn_MBM_delete";
            this.btn_MBM_delete.Size = new System.Drawing.Size(111, 30);
            this.btn_MBM_delete.TabIndex = 1;
            this.btn_MBM_delete.Text = "회원삭제";
            this.btn_MBM_delete.UseVisualStyleBackColor = false;
            this.btn_MBM_delete.Click += new System.EventHandler(this.btn_MBM_delete_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btn_MBM_add);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(248, 3);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(3);
            this.panel4.Size = new System.Drawing.Size(117, 36);
            this.panel4.TabIndex = 1;
            // 
            // btn_MBM_add
            // 
            this.btn_MBM_add.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_MBM_add.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_MBM_add.ForeColor = System.Drawing.Color.Gold;
            this.btn_MBM_add.Location = new System.Drawing.Point(3, 3);
            this.btn_MBM_add.Name = "btn_MBM_add";
            this.btn_MBM_add.Size = new System.Drawing.Size(111, 30);
            this.btn_MBM_add.TabIndex = 1;
            this.btn_MBM_add.Text = "회원추가";
            this.btn_MBM_add.UseVisualStyleBackColor = false;
            this.btn_MBM_add.Click += new System.EventHandler(this.MBM_add_btn_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label_main_title);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(5);
            this.panel3.Size = new System.Drawing.Size(245, 36);
            this.panel3.TabIndex = 0;
            // 
            // label_main_title
            // 
            this.label_main_title.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_main_title.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_main_title.Location = new System.Drawing.Point(5, 5);
            this.label_main_title.Name = "label_main_title";
            this.label_main_title.Size = new System.Drawing.Size(233, 24);
            this.label_main_title.TabIndex = 0;
            this.label_main_title.Text = "회원관리";
            this.label_main_title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.panel30);
            this.panel2.Controls.Add(this.grid_member_view);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 44);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(720, 405);
            this.panel2.TabIndex = 1;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.panel31);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel30.Location = new System.Drawing.Point(248, 369);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(470, 34);
            this.panel30.TabIndex = 5;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.btn_MBM_close);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel31.Location = new System.Drawing.Point(390, 0);
            this.panel31.Name = "panel31";
            this.panel31.Padding = new System.Windows.Forms.Padding(3);
            this.panel31.Size = new System.Drawing.Size(80, 34);
            this.panel31.TabIndex = 5;
            // 
            // btn_MBM_close
            // 
            this.btn_MBM_close.BackColor = System.Drawing.Color.Black;
            this.btn_MBM_close.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_MBM_close.ForeColor = System.Drawing.Color.Gold;
            this.btn_MBM_close.Location = new System.Drawing.Point(3, 3);
            this.btn_MBM_close.Name = "btn_MBM_close";
            this.btn_MBM_close.Size = new System.Drawing.Size(74, 28);
            this.btn_MBM_close.TabIndex = 2;
            this.btn_MBM_close.Text = "닫기";
            this.btn_MBM_close.UseVisualStyleBackColor = false;
            this.btn_MBM_close.Click += new System.EventHandler(this.btn_MBM_close_Click);
            // 
            // grid_member_view
            // 
            this.grid_member_view.AllowUserToAddRows = false;
            this.grid_member_view.AllowUserToResizeColumns = false;
            this.grid_member_view.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.DarkGray;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Yellow;
            this.grid_member_view.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.grid_member_view.AutoGenerateColumns = false;
            this.grid_member_view.BackgroundColor = System.Drawing.Color.Gray;
            this.grid_member_view.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.grid_member_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenVertical;
            this.grid_member_view.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("새굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_member_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.grid_member_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_member_view.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gridselectDataGridViewTextBoxColumn,
            this.mbnameDataGridViewTextBoxColumn,
            this.mbidDataGridViewTextBoxColumn,
            this.mbphDataGridViewTextBoxColumn});
            this.grid_member_view.DataMember = "table_member";
            this.grid_member_view.DataSource = this.DisplaySet;
            this.grid_member_view.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_member_view.GridColor = System.Drawing.Color.Black;
            this.grid_member_view.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.grid_member_view.Location = new System.Drawing.Point(248, 0);
            this.grid_member_view.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.grid_member_view.MultiSelect = false;
            this.grid_member_view.Name = "grid_member_view";
            this.grid_member_view.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_member_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.grid_member_view.RowHeadersVisible = false;
            this.grid_member_view.RowHeadersWidth = 20;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Yellow;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_member_view.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.grid_member_view.RowTemplate.Height = 23;
            this.grid_member_view.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.grid_member_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_member_view.Size = new System.Drawing.Size(470, 403);
            this.grid_member_view.TabIndex = 1;
            this.grid_member_view.SelectionChanged += new System.EventHandler(this.grid_main_SelectionChanged_1);
            // 
            // gridselectDataGridViewTextBoxColumn
            // 
            this.gridselectDataGridViewTextBoxColumn.DataPropertyName = "grid_select";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.NullValue = false;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Yellow;
            this.gridselectDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.gridselectDataGridViewTextBoxColumn.HeaderText = "check";
            this.gridselectDataGridViewTextBoxColumn.Name = "gridselectDataGridViewTextBoxColumn";
            this.gridselectDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gridselectDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.gridselectDataGridViewTextBoxColumn.Width = 50;
            // 
            // mbnameDataGridViewTextBoxColumn
            // 
            this.mbnameDataGridViewTextBoxColumn.DataPropertyName = "mb_name";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Yellow;
            this.mbnameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.mbnameDataGridViewTextBoxColumn.HeaderText = "이름";
            this.mbnameDataGridViewTextBoxColumn.Name = "mbnameDataGridViewTextBoxColumn";
            this.mbnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.mbnameDataGridViewTextBoxColumn.Width = 120;
            // 
            // mbidDataGridViewTextBoxColumn
            // 
            this.mbidDataGridViewTextBoxColumn.DataPropertyName = "mb_id";
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Yellow;
            this.mbidDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.mbidDataGridViewTextBoxColumn.HeaderText = "ID";
            this.mbidDataGridViewTextBoxColumn.Name = "mbidDataGridViewTextBoxColumn";
            this.mbidDataGridViewTextBoxColumn.ReadOnly = true;
            this.mbidDataGridViewTextBoxColumn.Width = 120;
            // 
            // mbphDataGridViewTextBoxColumn
            // 
            this.mbphDataGridViewTextBoxColumn.DataPropertyName = "mb_ph";
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Yellow;
            this.mbphDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.mbphDataGridViewTextBoxColumn.HeaderText = "phone";
            this.mbphDataGridViewTextBoxColumn.Name = "mbphDataGridViewTextBoxColumn";
            this.mbphDataGridViewTextBoxColumn.ReadOnly = true;
            this.mbphDataGridViewTextBoxColumn.Width = 120;
            // 
            // DisplaySet
            // 
            this.DisplaySet.DataSetName = "NewDataSet";
            this.DisplaySet.Tables.AddRange(new System.Data.DataTable[] {
            this.회원});
            // 
            // 회원
            // 
            this.회원.Columns.AddRange(new System.Data.DataColumn[] {
            this.이름,
            this.ID,
            this.PH,
            this.check});
            this.회원.TableName = "table_member";
            // 
            // 이름
            // 
            this.이름.ColumnName = "mb_name";
            // 
            // ID
            // 
            this.ID.ColumnName = "mb_id";
            // 
            // PH
            // 
            this.PH.ColumnName = "mb_ph";
            // 
            // check
            // 
            this.check.ColumnName = "grid_select";
            // 
            // panel7
            // 
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.tableLayoutPanel1);
            this.panel7.Controls.Add(this.panel11);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(248, 403);
            this.panel7.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel1.Controls.Add(this.panel28, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.panel27, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.panel26, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel25, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel24, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel23, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel22, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel21, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel20, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel19, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel18, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel17, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel16, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel15, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel14, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel13, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 26);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(246, 342);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.DarkGray;
            this.panel28.Controls.Add(this.tbox_MBM_member_memo);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel28.Location = new System.Drawing.Point(79, 229);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(162, 108);
            this.panel28.TabIndex = 15;
            // 
            // tbox_MBM_member_memo
            // 
            this.tbox_MBM_member_memo.BackColor = System.Drawing.Color.DarkGray;
            this.tbox_MBM_member_memo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_MBM_member_memo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_MBM_member_memo.Location = new System.Drawing.Point(0, 0);
            this.tbox_MBM_member_memo.MaxLength = 200;
            this.tbox_MBM_member_memo.Name = "tbox_MBM_member_memo";
            this.tbox_MBM_member_memo.ReadOnly = true;
            this.tbox_MBM_member_memo.Size = new System.Drawing.Size(162, 108);
            this.tbox_MBM_member_memo.TabIndex = 0;
            this.tbox_MBM_member_memo.Text = "";
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.label_MBM_member_memo);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(5, 229);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(66, 108);
            this.panel27.TabIndex = 14;
            // 
            // label_MBM_member_memo
            // 
            this.label_MBM_member_memo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_MBM_member_memo.ForeColor = System.Drawing.Color.White;
            this.label_MBM_member_memo.Location = new System.Drawing.Point(0, 0);
            this.label_MBM_member_memo.Name = "label_MBM_member_memo";
            this.label_MBM_member_memo.Size = new System.Drawing.Size(66, 108);
            this.label_MBM_member_memo.TabIndex = 1;
            this.label_MBM_member_memo.Text = "메모";
            this.label_MBM_member_memo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.DarkGray;
            this.panel26.Controls.Add(this.date_MBM_member_newdate);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(79, 197);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(162, 24);
            this.panel26.TabIndex = 13;
            // 
            // date_MBM_member_newdate
            // 
            this.date_MBM_member_newdate.CalendarMonthBackground = System.Drawing.Color.Gray;
            this.date_MBM_member_newdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.date_MBM_member_newdate.Enabled = false;
            this.date_MBM_member_newdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date_MBM_member_newdate.ImeMode = System.Windows.Forms.ImeMode.On;
            this.date_MBM_member_newdate.Location = new System.Drawing.Point(0, 0);
            this.date_MBM_member_newdate.Name = "date_MBM_member_newdate";
            this.date_MBM_member_newdate.Size = new System.Drawing.Size(162, 21);
            this.date_MBM_member_newdate.TabIndex = 1;
            this.date_MBM_member_newdate.Value = new System.DateTime(2023, 7, 31, 11, 6, 7, 0);
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.label_MBM_member_newdate);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(5, 197);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(66, 24);
            this.panel25.TabIndex = 12;
            // 
            // label_MBM_member_newdate
            // 
            this.label_MBM_member_newdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_MBM_member_newdate.ForeColor = System.Drawing.Color.White;
            this.label_MBM_member_newdate.Location = new System.Drawing.Point(0, 0);
            this.label_MBM_member_newdate.Name = "label_MBM_member_newdate";
            this.label_MBM_member_newdate.Size = new System.Drawing.Size(66, 24);
            this.label_MBM_member_newdate.TabIndex = 1;
            this.label_MBM_member_newdate.Text = "가입일";
            this.label_MBM_member_newdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.DarkGray;
            this.panel24.Controls.Add(this.date_MBM_member_birthdate);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(79, 165);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(162, 24);
            this.panel24.TabIndex = 11;
            // 
            // date_MBM_member_birthdate
            // 
            this.date_MBM_member_birthdate.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.date_MBM_member_birthdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.date_MBM_member_birthdate.Enabled = false;
            this.date_MBM_member_birthdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date_MBM_member_birthdate.ImeMode = System.Windows.Forms.ImeMode.On;
            this.date_MBM_member_birthdate.Location = new System.Drawing.Point(0, 0);
            this.date_MBM_member_birthdate.Name = "date_MBM_member_birthdate";
            this.date_MBM_member_birthdate.Size = new System.Drawing.Size(162, 21);
            this.date_MBM_member_birthdate.TabIndex = 0;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.label_MBM_member_birthdate);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(5, 165);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(66, 24);
            this.panel23.TabIndex = 10;
            // 
            // label_MBM_member_birthdate
            // 
            this.label_MBM_member_birthdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_MBM_member_birthdate.ForeColor = System.Drawing.Color.White;
            this.label_MBM_member_birthdate.Location = new System.Drawing.Point(0, 0);
            this.label_MBM_member_birthdate.Name = "label_MBM_member_birthdate";
            this.label_MBM_member_birthdate.Size = new System.Drawing.Size(66, 24);
            this.label_MBM_member_birthdate.TabIndex = 1;
            this.label_MBM_member_birthdate.Text = "생년월일";
            this.label_MBM_member_birthdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.DarkGray;
            this.panel22.Controls.Add(this.tbox_MBM_member_ph);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(79, 133);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(162, 24);
            this.panel22.TabIndex = 9;
            // 
            // tbox_MBM_member_ph
            // 
            this.tbox_MBM_member_ph.BackColor = System.Drawing.Color.DarkGray;
            this.tbox_MBM_member_ph.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_MBM_member_ph.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_MBM_member_ph.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tbox_MBM_member_ph.Location = new System.Drawing.Point(0, 0);
            this.tbox_MBM_member_ph.MaxLength = 14;
            this.tbox_MBM_member_ph.Name = "tbox_MBM_member_ph";
            this.tbox_MBM_member_ph.ReadOnly = true;
            this.tbox_MBM_member_ph.Size = new System.Drawing.Size(162, 14);
            this.tbox_MBM_member_ph.TabIndex = 1;
            this.tbox_MBM_member_ph.WordWrap = false;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.label_MBM_member_ph);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel21.Location = new System.Drawing.Point(5, 133);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(66, 24);
            this.panel21.TabIndex = 8;
            // 
            // label_MBM_member_ph
            // 
            this.label_MBM_member_ph.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_MBM_member_ph.ForeColor = System.Drawing.Color.White;
            this.label_MBM_member_ph.Location = new System.Drawing.Point(0, 0);
            this.label_MBM_member_ph.Name = "label_MBM_member_ph";
            this.label_MBM_member_ph.Size = new System.Drawing.Size(66, 24);
            this.label_MBM_member_ph.TabIndex = 1;
            this.label_MBM_member_ph.Text = "PH";
            this.label_MBM_member_ph.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.DarkGray;
            this.panel20.Controls.Add(this.tbox_MBM_member_pw);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(79, 101);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(162, 24);
            this.panel20.TabIndex = 7;
            // 
            // tbox_MBM_member_pw
            // 
            this.tbox_MBM_member_pw.BackColor = System.Drawing.Color.DarkGray;
            this.tbox_MBM_member_pw.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_MBM_member_pw.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_MBM_member_pw.Location = new System.Drawing.Point(0, 0);
            this.tbox_MBM_member_pw.MaxLength = 12;
            this.tbox_MBM_member_pw.Name = "tbox_MBM_member_pw";
            this.tbox_MBM_member_pw.PasswordChar = '*';
            this.tbox_MBM_member_pw.ReadOnly = true;
            this.tbox_MBM_member_pw.Size = new System.Drawing.Size(162, 14);
            this.tbox_MBM_member_pw.TabIndex = 1;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.label_MBM_member_pw);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(5, 101);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(66, 24);
            this.panel19.TabIndex = 6;
            // 
            // label_MBM_member_pw
            // 
            this.label_MBM_member_pw.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_MBM_member_pw.ForeColor = System.Drawing.Color.White;
            this.label_MBM_member_pw.Location = new System.Drawing.Point(0, 0);
            this.label_MBM_member_pw.Name = "label_MBM_member_pw";
            this.label_MBM_member_pw.Size = new System.Drawing.Size(66, 24);
            this.label_MBM_member_pw.TabIndex = 1;
            this.label_MBM_member_pw.Text = "PW";
            this.label_MBM_member_pw.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.DarkGray;
            this.panel18.Controls.Add(this.tbox_MBM_member_id);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(79, 69);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(162, 24);
            this.panel18.TabIndex = 5;
            // 
            // tbox_MBM_member_id
            // 
            this.tbox_MBM_member_id.BackColor = System.Drawing.Color.DarkGray;
            this.tbox_MBM_member_id.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_MBM_member_id.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_MBM_member_id.Location = new System.Drawing.Point(0, 0);
            this.tbox_MBM_member_id.MaxLength = 20;
            this.tbox_MBM_member_id.Name = "tbox_MBM_member_id";
            this.tbox_MBM_member_id.ReadOnly = true;
            this.tbox_MBM_member_id.Size = new System.Drawing.Size(162, 14);
            this.tbox_MBM_member_id.TabIndex = 2;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.label_MBM_member_id);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(5, 69);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(66, 24);
            this.panel17.TabIndex = 4;
            // 
            // label_MBM_member_id
            // 
            this.label_MBM_member_id.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_MBM_member_id.ForeColor = System.Drawing.Color.White;
            this.label_MBM_member_id.Location = new System.Drawing.Point(0, 0);
            this.label_MBM_member_id.Name = "label_MBM_member_id";
            this.label_MBM_member_id.Size = new System.Drawing.Size(66, 24);
            this.label_MBM_member_id.TabIndex = 1;
            this.label_MBM_member_id.Text = "ID";
            this.label_MBM_member_id.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.DarkGray;
            this.panel16.Controls.Add(this.tbox_MBM_member_name);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(79, 37);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(162, 24);
            this.panel16.TabIndex = 3;
            // 
            // tbox_MBM_member_name
            // 
            this.tbox_MBM_member_name.BackColor = System.Drawing.Color.DarkGray;
            this.tbox_MBM_member_name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_MBM_member_name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_MBM_member_name.Location = new System.Drawing.Point(0, 0);
            this.tbox_MBM_member_name.MaxLength = 5;
            this.tbox_MBM_member_name.Name = "tbox_MBM_member_name";
            this.tbox_MBM_member_name.ReadOnly = true;
            this.tbox_MBM_member_name.Size = new System.Drawing.Size(162, 14);
            this.tbox_MBM_member_name.TabIndex = 1;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label_MBM_member_name);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(5, 37);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(66, 24);
            this.panel15.TabIndex = 2;
            // 
            // label_MBM_member_name
            // 
            this.label_MBM_member_name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_MBM_member_name.ForeColor = System.Drawing.Color.White;
            this.label_MBM_member_name.Location = new System.Drawing.Point(0, 0);
            this.label_MBM_member_name.Name = "label_MBM_member_name";
            this.label_MBM_member_name.Size = new System.Drawing.Size(66, 24);
            this.label_MBM_member_name.TabIndex = 1;
            this.label_MBM_member_name.Text = "이름";
            this.label_MBM_member_name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.DarkGray;
            this.panel14.Controls.Add(this.tbox_MBM_member_num);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel14.Location = new System.Drawing.Point(79, 5);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(162, 21);
            this.panel14.TabIndex = 1;
            // 
            // tbox_MBM_member_num
            // 
            this.tbox_MBM_member_num.BackColor = System.Drawing.Color.DarkGray;
            this.tbox_MBM_member_num.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbox_MBM_member_num.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_MBM_member_num.Location = new System.Drawing.Point(0, 0);
            this.tbox_MBM_member_num.Name = "tbox_MBM_member_num";
            this.tbox_MBM_member_num.ReadOnly = true;
            this.tbox_MBM_member_num.Size = new System.Drawing.Size(162, 14);
            this.tbox_MBM_member_num.TabIndex = 2;
            this.tbox_MBM_member_num.Text = "  ";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.label_MBM_member_code);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(5, 5);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(66, 24);
            this.panel13.TabIndex = 0;
            // 
            // label_MBM_member_code
            // 
            this.label_MBM_member_code.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_MBM_member_code.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_MBM_member_code.ForeColor = System.Drawing.Color.White;
            this.label_MBM_member_code.Location = new System.Drawing.Point(0, 0);
            this.label_MBM_member_code.Name = "label_MBM_member_code";
            this.label_MBM_member_code.Size = new System.Drawing.Size(66, 24);
            this.label_MBM_member_code.TabIndex = 0;
            this.label_MBM_member_code.Text = "회원번호";
            this.label_MBM_member_code.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.label_title2);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Padding = new System.Windows.Forms.Padding(3);
            this.panel11.Size = new System.Drawing.Size(246, 26);
            this.panel11.TabIndex = 1;
            // 
            // label_title2
            // 
            this.label_title2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_title2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_title2.Location = new System.Drawing.Point(3, 3);
            this.label_title2.Name = "label_title2";
            this.label_title2.Size = new System.Drawing.Size(240, 20);
            this.label_title2.TabIndex = 0;
            this.label_title2.Text = "회원정보";
            this.label_title2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.panel29);
            this.panel8.Controls.Add(this.panel10);
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 368);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(246, 33);
            this.panel8.TabIndex = 0;
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.btn_MBM_member_cancle);
            this.panel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel29.Location = new System.Drawing.Point(81, 0);
            this.panel29.Name = "panel29";
            this.panel29.Padding = new System.Windows.Forms.Padding(3);
            this.panel29.Size = new System.Drawing.Size(80, 31);
            this.panel29.TabIndex = 2;
            // 
            // btn_MBM_member_cancle
            // 
            this.btn_MBM_member_cancle.BackColor = System.Drawing.Color.Black;
            this.btn_MBM_member_cancle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_MBM_member_cancle.Enabled = false;
            this.btn_MBM_member_cancle.ForeColor = System.Drawing.Color.Gold;
            this.btn_MBM_member_cancle.Location = new System.Drawing.Point(3, 3);
            this.btn_MBM_member_cancle.Name = "btn_MBM_member_cancle";
            this.btn_MBM_member_cancle.Size = new System.Drawing.Size(74, 25);
            this.btn_MBM_member_cancle.TabIndex = 0;
            this.btn_MBM_member_cancle.Text = "취소";
            this.btn_MBM_member_cancle.UseVisualStyleBackColor = false;
            this.btn_MBM_member_cancle.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.btn_MBM_member_save);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel10.Location = new System.Drawing.Point(161, 0);
            this.panel10.Name = "panel10";
            this.panel10.Padding = new System.Windows.Forms.Padding(3);
            this.panel10.Size = new System.Drawing.Size(83, 31);
            this.panel10.TabIndex = 1;
            // 
            // btn_MBM_member_save
            // 
            this.btn_MBM_member_save.BackColor = System.Drawing.Color.Black;
            this.btn_MBM_member_save.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_MBM_member_save.Enabled = false;
            this.btn_MBM_member_save.ForeColor = System.Drawing.Color.Gold;
            this.btn_MBM_member_save.Location = new System.Drawing.Point(3, 3);
            this.btn_MBM_member_save.Name = "btn_MBM_member_save";
            this.btn_MBM_member_save.Size = new System.Drawing.Size(77, 25);
            this.btn_MBM_member_save.TabIndex = 0;
            this.btn_MBM_member_save.Text = "저장";
            this.btn_MBM_member_save.UseVisualStyleBackColor = false;
            this.btn_MBM_member_save.Click += new System.EventHandler(this.btn_MBM_member_save_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btn_MBM_member_modify);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Padding = new System.Windows.Forms.Padding(3);
            this.panel9.Size = new System.Drawing.Size(81, 31);
            this.panel9.TabIndex = 0;
            // 
            // btn_MBM_member_modify
            // 
            this.btn_MBM_member_modify.BackColor = System.Drawing.Color.Black;
            this.btn_MBM_member_modify.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_MBM_member_modify.ForeColor = System.Drawing.Color.Gold;
            this.btn_MBM_member_modify.Location = new System.Drawing.Point(3, 3);
            this.btn_MBM_member_modify.Name = "btn_MBM_member_modify";
            this.btn_MBM_member_modify.Size = new System.Drawing.Size(75, 25);
            this.btn_MBM_member_modify.TabIndex = 0;
            this.btn_MBM_member_modify.Text = "수정";
            this.btn_MBM_member_modify.UseVisualStyleBackColor = false;
            this.btn_MBM_member_modify.Click += new System.EventHandler(this.btn_MBM_member_modify_Click);
            // 
            // Member_Management
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(720, 449);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(700, 470);
            this.Name = "Member_Management";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "회원관리";
            this.Load += new System.EventHandler(this.Member_Management_Load);
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_member_view)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.회원)).EndInit();
            this.panel7.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_MBM_delete;
        private System.Windows.Forms.Button btn_MBM_add;
        private System.Windows.Forms.Label label_main_title;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button btn_MBM_search;
        private System.Windows.Forms.DataGridView grid_member_view;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RichTextBox tbox_MBM_search;
        private System.Data.DataSet DisplaySet;
        private System.Data.DataTable 회원;
        private System.Data.DataColumn 이름;
        private System.Data.DataColumn ID;
        private System.Data.DataColumn PH;
        private System.Data.DataColumn check;
        private System.Windows.Forms.DataGridViewCheckBoxColumn gridselectDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mbnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mbidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mbphDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.RichTextBox tbox_MBM_member_memo;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label_MBM_member_memo;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.DateTimePicker date_MBM_member_newdate;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label_MBM_member_newdate;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.DateTimePicker date_MBM_member_birthdate;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label_MBM_member_birthdate;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.TextBox tbox_MBM_member_ph;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label_MBM_member_ph;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox tbox_MBM_member_pw;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label_MBM_member_pw;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox tbox_MBM_member_id;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label_MBM_member_id;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox tbox_MBM_member_name;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label_MBM_member_name;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox tbox_MBM_member_num;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label_MBM_member_code;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label_title2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Button btn_MBM_member_cancle;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btn_MBM_member_save;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btn_MBM_member_modify;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Button btn_MBM_close;
    }
}