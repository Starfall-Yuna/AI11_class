﻿namespace mainPC {
    partial class counter_main {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.btn_CM_settings = new System.Windows.Forms.Button();
            this.panel39 = new System.Windows.Forms.Panel();
            this.btn_CM_close = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_CM_screen_lock = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_CM_product_mg = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_CM_member_mg = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.CM_seat_15 = new System.Windows.Forms.Panel();
            this.panel95 = new System.Windows.Forms.Panel();
            this.CM_time_remaining15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel96 = new System.Windows.Forms.Panel();
            this.CM_time_using15 = new System.Windows.Forms.Label();
            this.panel97 = new System.Windows.Forms.Panel();
            this.panel98 = new System.Windows.Forms.Panel();
            this.CM_mb_info15 = new System.Windows.Forms.Label();
            this.panel99 = new System.Windows.Forms.Panel();
            this.CM_seat_num15 = new System.Windows.Forms.Label();
            this.CM_seat_14 = new System.Windows.Forms.Panel();
            this.panel89 = new System.Windows.Forms.Panel();
            this.CM_time_remaining14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.panel90 = new System.Windows.Forms.Panel();
            this.CM_time_using14 = new System.Windows.Forms.Label();
            this.panel91 = new System.Windows.Forms.Panel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.CM_mb_info14 = new System.Windows.Forms.Label();
            this.panel93 = new System.Windows.Forms.Panel();
            this.CM_seat_num14 = new System.Windows.Forms.Label();
            this.CM_seat_13 = new System.Windows.Forms.Panel();
            this.panel83 = new System.Windows.Forms.Panel();
            this.CM_time_remaining13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel84 = new System.Windows.Forms.Panel();
            this.CM_time_using13 = new System.Windows.Forms.Label();
            this.panel85 = new System.Windows.Forms.Panel();
            this.panel86 = new System.Windows.Forms.Panel();
            this.CM_mb_info13 = new System.Windows.Forms.Label();
            this.panel87 = new System.Windows.Forms.Panel();
            this.CM_seat_num13 = new System.Windows.Forms.Label();
            this.CM_seat_12 = new System.Windows.Forms.Panel();
            this.panel77 = new System.Windows.Forms.Panel();
            this.CM_time_remaining12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel78 = new System.Windows.Forms.Panel();
            this.CM_time_using12 = new System.Windows.Forms.Label();
            this.panel79 = new System.Windows.Forms.Panel();
            this.panel80 = new System.Windows.Forms.Panel();
            this.CM_mb_info12 = new System.Windows.Forms.Label();
            this.panel81 = new System.Windows.Forms.Panel();
            this.CM_seat_num12 = new System.Windows.Forms.Label();
            this.CM_seat_11 = new System.Windows.Forms.Panel();
            this.panel71 = new System.Windows.Forms.Panel();
            this.CM_time_remaining11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel72 = new System.Windows.Forms.Panel();
            this.CM_time_using11 = new System.Windows.Forms.Label();
            this.panel73 = new System.Windows.Forms.Panel();
            this.panel74 = new System.Windows.Forms.Panel();
            this.CM_mb_info11 = new System.Windows.Forms.Label();
            this.panel75 = new System.Windows.Forms.Panel();
            this.CM_seat_num11 = new System.Windows.Forms.Label();
            this.CM_seat_10 = new System.Windows.Forms.Panel();
            this.panel65 = new System.Windows.Forms.Panel();
            this.CM_time_remaining10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel66 = new System.Windows.Forms.Panel();
            this.CM_time_using10 = new System.Windows.Forms.Label();
            this.panel67 = new System.Windows.Forms.Panel();
            this.panel68 = new System.Windows.Forms.Panel();
            this.CM_mb_info10 = new System.Windows.Forms.Label();
            this.panel69 = new System.Windows.Forms.Panel();
            this.CM_seat_num10 = new System.Windows.Forms.Label();
            this.CM_seat_9 = new System.Windows.Forms.Panel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.CM_time_remaining9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel60 = new System.Windows.Forms.Panel();
            this.CM_time_using9 = new System.Windows.Forms.Label();
            this.panel61 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.CM_mb_info9 = new System.Windows.Forms.Label();
            this.panel63 = new System.Windows.Forms.Panel();
            this.CM_seat_num9 = new System.Windows.Forms.Label();
            this.CM_seat_8 = new System.Windows.Forms.Panel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.CM_time_remaining8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel54 = new System.Windows.Forms.Panel();
            this.CM_time_using8 = new System.Windows.Forms.Label();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.CM_mb_info8 = new System.Windows.Forms.Label();
            this.panel57 = new System.Windows.Forms.Panel();
            this.CM_seat_num8 = new System.Windows.Forms.Label();
            this.CM_seat_7 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.CM_time_remaining7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel48 = new System.Windows.Forms.Panel();
            this.CM_time_using7 = new System.Windows.Forms.Label();
            this.panel49 = new System.Windows.Forms.Panel();
            this.panel50 = new System.Windows.Forms.Panel();
            this.CM_mb_info7 = new System.Windows.Forms.Label();
            this.panel51 = new System.Windows.Forms.Panel();
            this.CM_seat_num7 = new System.Windows.Forms.Label();
            this.CM_seat_6 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.CM_time_remaining6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel42 = new System.Windows.Forms.Panel();
            this.CM_time_using6 = new System.Windows.Forms.Label();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.CM_mb_info6 = new System.Windows.Forms.Label();
            this.panel45 = new System.Windows.Forms.Panel();
            this.CM_seat_num6 = new System.Windows.Forms.Label();
            this.CM_seat_5 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.CM_time_remaining5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel36 = new System.Windows.Forms.Panel();
            this.CM_time_using5 = new System.Windows.Forms.Label();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.CM_mb_info5 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.CM_seat_num5 = new System.Windows.Forms.Label();
            this.CM_seat_4 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.CM_time_remaining4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.CM_time_using4 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.CM_mb_info4 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.CM_seat_num4 = new System.Windows.Forms.Label();
            this.CM_seat_3 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.CM_time_remaining3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.CM_time_using3 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.CM_mb_info3 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.CM_seat_num3 = new System.Windows.Forms.Label();
            this.CM_seat_2 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.CM_time_remaining2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.CM_time_using2 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.CM_mb_info2 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.CM_seat_num2 = new System.Windows.Forms.Label();
            this.CM_seat_1 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.CM_time_remaining1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.CM_time_using1 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.CM_mb_info1 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.CM_seat_num1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.grid_order_view = new System.Windows.Forms.DataGridView();
            this.snumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.odrpamountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.odrptimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productdata = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.좌석번 = new System.Data.DataColumn();
            this.상품명 = new System.Data.DataColumn();
            this.주문수 = new System.Data.DataColumn();
            this.전달여부 = new System.Data.DataColumn();
            this.dataTable2 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.panel10 = new System.Windows.Forms.Panel();
            this.main_stitle = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.label_CM_availableseat = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.label_CM_usingseat = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.CM_seat_15.SuspendLayout();
            this.panel95.SuspendLayout();
            this.panel96.SuspendLayout();
            this.panel97.SuspendLayout();
            this.panel98.SuspendLayout();
            this.panel99.SuspendLayout();
            this.CM_seat_14.SuspendLayout();
            this.panel89.SuspendLayout();
            this.panel90.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel92.SuspendLayout();
            this.panel93.SuspendLayout();
            this.CM_seat_13.SuspendLayout();
            this.panel83.SuspendLayout();
            this.panel84.SuspendLayout();
            this.panel85.SuspendLayout();
            this.panel86.SuspendLayout();
            this.panel87.SuspendLayout();
            this.CM_seat_12.SuspendLayout();
            this.panel77.SuspendLayout();
            this.panel78.SuspendLayout();
            this.panel79.SuspendLayout();
            this.panel80.SuspendLayout();
            this.panel81.SuspendLayout();
            this.CM_seat_11.SuspendLayout();
            this.panel71.SuspendLayout();
            this.panel72.SuspendLayout();
            this.panel73.SuspendLayout();
            this.panel74.SuspendLayout();
            this.panel75.SuspendLayout();
            this.CM_seat_10.SuspendLayout();
            this.panel65.SuspendLayout();
            this.panel66.SuspendLayout();
            this.panel67.SuspendLayout();
            this.panel68.SuspendLayout();
            this.panel69.SuspendLayout();
            this.CM_seat_9.SuspendLayout();
            this.panel59.SuspendLayout();
            this.panel60.SuspendLayout();
            this.panel61.SuspendLayout();
            this.panel62.SuspendLayout();
            this.panel63.SuspendLayout();
            this.CM_seat_8.SuspendLayout();
            this.panel53.SuspendLayout();
            this.panel54.SuspendLayout();
            this.panel55.SuspendLayout();
            this.panel56.SuspendLayout();
            this.panel57.SuspendLayout();
            this.CM_seat_7.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel50.SuspendLayout();
            this.panel51.SuspendLayout();
            this.CM_seat_6.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel45.SuspendLayout();
            this.CM_seat_5.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel22.SuspendLayout();
            this.CM_seat_4.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.CM_seat_3.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.CM_seat_2.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.CM_seat_1.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_order_view)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productdata)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel34.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel16);
            this.panel1.Controls.Add(this.panel39);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1020, 60);
            this.panel1.TabIndex = 3;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel16.Controls.Add(this.btn_CM_settings);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel16.Location = new System.Drawing.Point(778, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(118, 60);
            this.panel16.TabIndex = 5;
            // 
            // btn_CM_settings
            // 
            this.btn_CM_settings.BackColor = System.Drawing.Color.Black;
            this.btn_CM_settings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_CM_settings.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_CM_settings.ForeColor = System.Drawing.Color.Yellow;
            this.btn_CM_settings.Location = new System.Drawing.Point(0, 0);
            this.btn_CM_settings.Name = "btn_CM_settings";
            this.btn_CM_settings.Size = new System.Drawing.Size(118, 60);
            this.btn_CM_settings.TabIndex = 1;
            this.btn_CM_settings.Text = "환경설정";
            this.btn_CM_settings.UseVisualStyleBackColor = false;
            this.btn_CM_settings.Click += new System.EventHandler(this.btn_CM_settings_Click);
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel39.Controls.Add(this.btn_CM_close);
            this.panel39.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel39.Location = new System.Drawing.Point(896, 0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(124, 60);
            this.panel39.TabIndex = 4;
            // 
            // btn_CM_close
            // 
            this.btn_CM_close.BackColor = System.Drawing.Color.Black;
            this.btn_CM_close.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_CM_close.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_CM_close.ForeColor = System.Drawing.Color.Yellow;
            this.btn_CM_close.Location = new System.Drawing.Point(0, 0);
            this.btn_CM_close.Name = "btn_CM_close";
            this.btn_CM_close.Size = new System.Drawing.Size(124, 60);
            this.btn_CM_close.TabIndex = 1;
            this.btn_CM_close.Text = "프로그램종료";
            this.btn_CM_close.UseVisualStyleBackColor = false;
            this.btn_CM_close.Click += new System.EventHandler(this.btn_CM_close_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btn_CM_screen_lock);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(280, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(140, 60);
            this.panel5.TabIndex = 2;
            // 
            // btn_CM_screen_lock
            // 
            this.btn_CM_screen_lock.BackColor = System.Drawing.Color.Black;
            this.btn_CM_screen_lock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_CM_screen_lock.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_CM_screen_lock.ForeColor = System.Drawing.Color.Yellow;
            this.btn_CM_screen_lock.Location = new System.Drawing.Point(0, 0);
            this.btn_CM_screen_lock.Name = "btn_CM_screen_lock";
            this.btn_CM_screen_lock.Size = new System.Drawing.Size(140, 60);
            this.btn_CM_screen_lock.TabIndex = 1;
            this.btn_CM_screen_lock.Text = "화면잠금";
            this.btn_CM_screen_lock.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btn_CM_product_mg);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(140, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(140, 60);
            this.panel4.TabIndex = 1;
            // 
            // btn_CM_product_mg
            // 
            this.btn_CM_product_mg.BackColor = System.Drawing.Color.Black;
            this.btn_CM_product_mg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_CM_product_mg.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_CM_product_mg.ForeColor = System.Drawing.Color.Yellow;
            this.btn_CM_product_mg.Location = new System.Drawing.Point(0, 0);
            this.btn_CM_product_mg.Name = "btn_CM_product_mg";
            this.btn_CM_product_mg.Size = new System.Drawing.Size(140, 60);
            this.btn_CM_product_mg.TabIndex = 1;
            this.btn_CM_product_mg.Text = "상품관리";
            this.btn_CM_product_mg.UseVisualStyleBackColor = false;
            this.btn_CM_product_mg.Click += new System.EventHandler(this.CM_product_mg_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btn_CM_member_mg);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(140, 60);
            this.panel3.TabIndex = 0;
            // 
            // btn_CM_member_mg
            // 
            this.btn_CM_member_mg.BackColor = System.Drawing.Color.Black;
            this.btn_CM_member_mg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_CM_member_mg.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_CM_member_mg.ForeColor = System.Drawing.Color.Yellow;
            this.btn_CM_member_mg.Location = new System.Drawing.Point(0, 0);
            this.btn_CM_member_mg.Name = "btn_CM_member_mg";
            this.btn_CM_member_mg.Size = new System.Drawing.Size(140, 60);
            this.btn_CM_member_mg.TabIndex = 0;
            this.btn_CM_member_mg.Text = "회원관리";
            this.btn_CM_member_mg.UseVisualStyleBackColor = false;
            this.btn_CM_member_mg.Click += new System.EventHandler(this.btn_CM_member_mg_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 60);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1020, 404);
            this.panel2.TabIndex = 4;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.tableLayoutPanel1);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(420, 0);
            this.panel9.Name = "panel9";
            this.panel9.Padding = new System.Windows.Forms.Padding(3);
            this.panel9.Size = new System.Drawing.Size(600, 404);
            this.panel9.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_15, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_14, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_13, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_12, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_11, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_10, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_9, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_8, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_7, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_6, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.CM_seat_1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(594, 398);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // CM_seat_15
            // 
            this.CM_seat_15.Controls.Add(this.panel95);
            this.CM_seat_15.Controls.Add(this.panel96);
            this.CM_seat_15.Controls.Add(this.panel97);
            this.CM_seat_15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_15.Location = new System.Drawing.Point(478, 268);
            this.CM_seat_15.Name = "CM_seat_15";
            this.CM_seat_15.Size = new System.Drawing.Size(110, 124);
            this.CM_seat_15.TabIndex = 14;
            // 
            // panel95
            // 
            this.panel95.Controls.Add(this.CM_time_remaining15);
            this.panel95.Controls.Add(this.label17);
            this.panel95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel95.Location = new System.Drawing.Point(0, 27);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(110, 70);
            this.panel95.TabIndex = 2;
            // 
            // CM_time_remaining15
            // 
            this.CM_time_remaining15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining15.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining15.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining15.Name = "CM_time_remaining15";
            this.CM_time_remaining15.Size = new System.Drawing.Size(110, 50);
            this.CM_time_remaining15.TabIndex = 1;
            this.CM_time_remaining15.Text = "CM_time_remaining15";
            this.CM_time_remaining15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.Dock = System.Windows.Forms.DockStyle.Top;
            this.label17.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label17.Location = new System.Drawing.Point(0, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(110, 20);
            this.label17.TabIndex = 3;
            this.label17.Text = "남은시간";
            this.label17.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel96
            // 
            this.panel96.Controls.Add(this.CM_time_using15);
            this.panel96.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel96.Location = new System.Drawing.Point(0, 97);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(110, 27);
            this.panel96.TabIndex = 1;
            // 
            // CM_time_using15
            // 
            this.CM_time_using15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using15.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using15.Name = "CM_time_using15";
            this.CM_time_using15.Size = new System.Drawing.Size(110, 27);
            this.CM_time_using15.TabIndex = 1;
            this.CM_time_using15.Text = "CM_time_using15";
            this.CM_time_using15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel97
            // 
            this.panel97.Controls.Add(this.panel98);
            this.panel97.Controls.Add(this.panel99);
            this.panel97.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel97.Location = new System.Drawing.Point(0, 0);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(110, 27);
            this.panel97.TabIndex = 0;
            // 
            // panel98
            // 
            this.panel98.Controls.Add(this.CM_mb_info15);
            this.panel98.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel98.Location = new System.Drawing.Point(27, 0);
            this.panel98.Name = "panel98";
            this.panel98.Size = new System.Drawing.Size(83, 27);
            this.panel98.TabIndex = 1;
            // 
            // CM_mb_info15
            // 
            this.CM_mb_info15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info15.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info15.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info15.Name = "CM_mb_info15";
            this.CM_mb_info15.Size = new System.Drawing.Size(83, 27);
            this.CM_mb_info15.TabIndex = 1;
            this.CM_mb_info15.Text = "CM_mb_info15";
            this.CM_mb_info15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel99
            // 
            this.panel99.Controls.Add(this.CM_seat_num15);
            this.panel99.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel99.Location = new System.Drawing.Point(0, 0);
            this.panel99.Name = "panel99";
            this.panel99.Padding = new System.Windows.Forms.Padding(2);
            this.panel99.Size = new System.Drawing.Size(27, 27);
            this.panel99.TabIndex = 0;
            // 
            // CM_seat_num15
            // 
            this.CM_seat_num15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num15.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num15.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num15.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num15.Name = "CM_seat_num15";
            this.CM_seat_num15.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num15.TabIndex = 0;
            this.CM_seat_num15.Text = "15";
            this.CM_seat_num15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_14
            // 
            this.CM_seat_14.Controls.Add(this.panel89);
            this.CM_seat_14.Controls.Add(this.panel90);
            this.CM_seat_14.Controls.Add(this.panel91);
            this.CM_seat_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_14.Location = new System.Drawing.Point(360, 268);
            this.CM_seat_14.Name = "CM_seat_14";
            this.CM_seat_14.Size = new System.Drawing.Size(109, 124);
            this.CM_seat_14.TabIndex = 13;
            // 
            // panel89
            // 
            this.panel89.Controls.Add(this.CM_time_remaining14);
            this.panel89.Controls.Add(this.label16);
            this.panel89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel89.Location = new System.Drawing.Point(0, 27);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(109, 70);
            this.panel89.TabIndex = 2;
            // 
            // CM_time_remaining14
            // 
            this.CM_time_remaining14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining14.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining14.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining14.Name = "CM_time_remaining14";
            this.CM_time_remaining14.Size = new System.Drawing.Size(109, 50);
            this.CM_time_remaining14.TabIndex = 1;
            this.CM_time_remaining14.Text = "CM_time_remaining14";
            this.CM_time_remaining14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Top;
            this.label16.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(109, 20);
            this.label16.TabIndex = 3;
            this.label16.Text = "남은시간";
            this.label16.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel90
            // 
            this.panel90.Controls.Add(this.CM_time_using14);
            this.panel90.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel90.Location = new System.Drawing.Point(0, 97);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(109, 27);
            this.panel90.TabIndex = 1;
            // 
            // CM_time_using14
            // 
            this.CM_time_using14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using14.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using14.Name = "CM_time_using14";
            this.CM_time_using14.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using14.TabIndex = 1;
            this.CM_time_using14.Text = "CM_time_using14";
            this.CM_time_using14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel91
            // 
            this.panel91.Controls.Add(this.panel92);
            this.panel91.Controls.Add(this.panel93);
            this.panel91.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel91.Location = new System.Drawing.Point(0, 0);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(109, 27);
            this.panel91.TabIndex = 0;
            // 
            // panel92
            // 
            this.panel92.Controls.Add(this.CM_mb_info14);
            this.panel92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel92.Location = new System.Drawing.Point(27, 0);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(82, 27);
            this.panel92.TabIndex = 1;
            // 
            // CM_mb_info14
            // 
            this.CM_mb_info14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info14.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info14.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info14.Name = "CM_mb_info14";
            this.CM_mb_info14.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info14.TabIndex = 1;
            this.CM_mb_info14.Text = "CM_mb_info14";
            this.CM_mb_info14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel93
            // 
            this.panel93.Controls.Add(this.CM_seat_num14);
            this.panel93.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel93.Location = new System.Drawing.Point(0, 0);
            this.panel93.Name = "panel93";
            this.panel93.Padding = new System.Windows.Forms.Padding(2);
            this.panel93.Size = new System.Drawing.Size(27, 27);
            this.panel93.TabIndex = 0;
            // 
            // CM_seat_num14
            // 
            this.CM_seat_num14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num14.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num14.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num14.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num14.Name = "CM_seat_num14";
            this.CM_seat_num14.Size = new System.Drawing.Size(27, 23);
            this.CM_seat_num14.TabIndex = 0;
            this.CM_seat_num14.Text = "14";
            this.CM_seat_num14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_13
            // 
            this.CM_seat_13.Controls.Add(this.panel83);
            this.CM_seat_13.Controls.Add(this.panel84);
            this.CM_seat_13.Controls.Add(this.panel85);
            this.CM_seat_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_13.Location = new System.Drawing.Point(242, 268);
            this.CM_seat_13.Name = "CM_seat_13";
            this.CM_seat_13.Size = new System.Drawing.Size(109, 124);
            this.CM_seat_13.TabIndex = 12;
            // 
            // panel83
            // 
            this.panel83.Controls.Add(this.CM_time_remaining13);
            this.panel83.Controls.Add(this.label15);
            this.panel83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel83.Location = new System.Drawing.Point(0, 27);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(109, 70);
            this.panel83.TabIndex = 2;
            // 
            // CM_time_remaining13
            // 
            this.CM_time_remaining13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining13.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining13.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining13.Name = "CM_time_remaining13";
            this.CM_time_remaining13.Size = new System.Drawing.Size(109, 50);
            this.CM_time_remaining13.TabIndex = 1;
            this.CM_time_remaining13.Text = "CM_time_remaining13";
            this.CM_time_remaining13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.Dock = System.Windows.Forms.DockStyle.Top;
            this.label15.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.Location = new System.Drawing.Point(0, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(109, 20);
            this.label15.TabIndex = 3;
            this.label15.Text = "남은시간";
            this.label15.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel84
            // 
            this.panel84.Controls.Add(this.CM_time_using13);
            this.panel84.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel84.Location = new System.Drawing.Point(0, 97);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(109, 27);
            this.panel84.TabIndex = 1;
            // 
            // CM_time_using13
            // 
            this.CM_time_using13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using13.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using13.Name = "CM_time_using13";
            this.CM_time_using13.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using13.TabIndex = 1;
            this.CM_time_using13.Text = "CM_time_using13";
            this.CM_time_using13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel85
            // 
            this.panel85.Controls.Add(this.panel86);
            this.panel85.Controls.Add(this.panel87);
            this.panel85.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel85.Location = new System.Drawing.Point(0, 0);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(109, 27);
            this.panel85.TabIndex = 0;
            // 
            // panel86
            // 
            this.panel86.Controls.Add(this.CM_mb_info13);
            this.panel86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel86.Location = new System.Drawing.Point(27, 0);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(82, 27);
            this.panel86.TabIndex = 1;
            // 
            // CM_mb_info13
            // 
            this.CM_mb_info13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info13.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info13.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info13.Name = "CM_mb_info13";
            this.CM_mb_info13.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info13.TabIndex = 1;
            this.CM_mb_info13.Text = "CM_mb_info13";
            this.CM_mb_info13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel87
            // 
            this.panel87.Controls.Add(this.CM_seat_num13);
            this.panel87.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel87.Location = new System.Drawing.Point(0, 0);
            this.panel87.Name = "panel87";
            this.panel87.Padding = new System.Windows.Forms.Padding(2);
            this.panel87.Size = new System.Drawing.Size(27, 27);
            this.panel87.TabIndex = 0;
            // 
            // CM_seat_num13
            // 
            this.CM_seat_num13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num13.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num13.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num13.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num13.Name = "CM_seat_num13";
            this.CM_seat_num13.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num13.TabIndex = 0;
            this.CM_seat_num13.Text = "13";
            this.CM_seat_num13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_12
            // 
            this.CM_seat_12.Controls.Add(this.panel77);
            this.CM_seat_12.Controls.Add(this.panel78);
            this.CM_seat_12.Controls.Add(this.panel79);
            this.CM_seat_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_12.Location = new System.Drawing.Point(124, 268);
            this.CM_seat_12.Name = "CM_seat_12";
            this.CM_seat_12.Size = new System.Drawing.Size(109, 124);
            this.CM_seat_12.TabIndex = 11;
            // 
            // panel77
            // 
            this.panel77.Controls.Add(this.CM_time_remaining12);
            this.panel77.Controls.Add(this.label14);
            this.panel77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel77.Location = new System.Drawing.Point(0, 27);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(109, 70);
            this.panel77.TabIndex = 2;
            // 
            // CM_time_remaining12
            // 
            this.CM_time_remaining12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining12.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining12.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining12.Name = "CM_time_remaining12";
            this.CM_time_remaining12.Size = new System.Drawing.Size(109, 50);
            this.CM_time_remaining12.TabIndex = 1;
            this.CM_time_remaining12.Text = "CM_time_remaining12";
            this.CM_time_remaining12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Top;
            this.label14.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.Location = new System.Drawing.Point(0, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 20);
            this.label14.TabIndex = 3;
            this.label14.Text = "남은시간";
            this.label14.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel78
            // 
            this.panel78.Controls.Add(this.CM_time_using12);
            this.panel78.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel78.Location = new System.Drawing.Point(0, 97);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(109, 27);
            this.panel78.TabIndex = 1;
            // 
            // CM_time_using12
            // 
            this.CM_time_using12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using12.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using12.Name = "CM_time_using12";
            this.CM_time_using12.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using12.TabIndex = 1;
            this.CM_time_using12.Text = "CM_time_using12";
            this.CM_time_using12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel79
            // 
            this.panel79.Controls.Add(this.panel80);
            this.panel79.Controls.Add(this.panel81);
            this.panel79.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel79.Location = new System.Drawing.Point(0, 0);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(109, 27);
            this.panel79.TabIndex = 0;
            // 
            // panel80
            // 
            this.panel80.Controls.Add(this.CM_mb_info12);
            this.panel80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel80.Location = new System.Drawing.Point(27, 0);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(82, 27);
            this.panel80.TabIndex = 1;
            // 
            // CM_mb_info12
            // 
            this.CM_mb_info12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info12.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info12.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info12.Name = "CM_mb_info12";
            this.CM_mb_info12.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info12.TabIndex = 1;
            this.CM_mb_info12.Text = "CM_mb_info12";
            this.CM_mb_info12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel81
            // 
            this.panel81.Controls.Add(this.CM_seat_num12);
            this.panel81.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel81.Location = new System.Drawing.Point(0, 0);
            this.panel81.Name = "panel81";
            this.panel81.Padding = new System.Windows.Forms.Padding(2);
            this.panel81.Size = new System.Drawing.Size(27, 27);
            this.panel81.TabIndex = 0;
            // 
            // CM_seat_num12
            // 
            this.CM_seat_num12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num12.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num12.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num12.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num12.Name = "CM_seat_num12";
            this.CM_seat_num12.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num12.TabIndex = 0;
            this.CM_seat_num12.Text = "12";
            this.CM_seat_num12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_11
            // 
            this.CM_seat_11.Controls.Add(this.panel71);
            this.CM_seat_11.Controls.Add(this.panel72);
            this.CM_seat_11.Controls.Add(this.panel73);
            this.CM_seat_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_11.Location = new System.Drawing.Point(6, 268);
            this.CM_seat_11.Name = "CM_seat_11";
            this.CM_seat_11.Size = new System.Drawing.Size(109, 124);
            this.CM_seat_11.TabIndex = 10;
            // 
            // panel71
            // 
            this.panel71.Controls.Add(this.CM_time_remaining11);
            this.panel71.Controls.Add(this.label13);
            this.panel71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel71.Location = new System.Drawing.Point(0, 27);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(109, 70);
            this.panel71.TabIndex = 2;
            // 
            // CM_time_remaining11
            // 
            this.CM_time_remaining11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining11.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining11.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining11.Name = "CM_time_remaining11";
            this.CM_time_remaining11.Size = new System.Drawing.Size(109, 50);
            this.CM_time_remaining11.TabIndex = 1;
            this.CM_time_remaining11.Text = "CM_time_remaining11";
            this.CM_time_remaining11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Dock = System.Windows.Forms.DockStyle.Top;
            this.label13.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(0, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(109, 20);
            this.label13.TabIndex = 3;
            this.label13.Text = "남은시간";
            this.label13.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel72
            // 
            this.panel72.Controls.Add(this.CM_time_using11);
            this.panel72.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel72.Location = new System.Drawing.Point(0, 97);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(109, 27);
            this.panel72.TabIndex = 1;
            // 
            // CM_time_using11
            // 
            this.CM_time_using11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using11.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using11.Name = "CM_time_using11";
            this.CM_time_using11.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using11.TabIndex = 1;
            this.CM_time_using11.Text = "CM_time_using11";
            this.CM_time_using11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel73
            // 
            this.panel73.Controls.Add(this.panel74);
            this.panel73.Controls.Add(this.panel75);
            this.panel73.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel73.Location = new System.Drawing.Point(0, 0);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(109, 27);
            this.panel73.TabIndex = 0;
            // 
            // panel74
            // 
            this.panel74.Controls.Add(this.CM_mb_info11);
            this.panel74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel74.Location = new System.Drawing.Point(27, 0);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(82, 27);
            this.panel74.TabIndex = 1;
            // 
            // CM_mb_info11
            // 
            this.CM_mb_info11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info11.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info11.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info11.Name = "CM_mb_info11";
            this.CM_mb_info11.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info11.TabIndex = 1;
            this.CM_mb_info11.Text = "CM_mb_info11";
            this.CM_mb_info11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel75
            // 
            this.panel75.Controls.Add(this.CM_seat_num11);
            this.panel75.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel75.Location = new System.Drawing.Point(0, 0);
            this.panel75.Name = "panel75";
            this.panel75.Padding = new System.Windows.Forms.Padding(2);
            this.panel75.Size = new System.Drawing.Size(27, 27);
            this.panel75.TabIndex = 0;
            // 
            // CM_seat_num11
            // 
            this.CM_seat_num11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num11.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num11.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num11.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num11.Name = "CM_seat_num11";
            this.CM_seat_num11.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num11.TabIndex = 0;
            this.CM_seat_num11.Text = "11";
            this.CM_seat_num11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_10
            // 
            this.CM_seat_10.Controls.Add(this.panel65);
            this.CM_seat_10.Controls.Add(this.panel66);
            this.CM_seat_10.Controls.Add(this.panel67);
            this.CM_seat_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_10.Location = new System.Drawing.Point(478, 137);
            this.CM_seat_10.Name = "CM_seat_10";
            this.CM_seat_10.Size = new System.Drawing.Size(110, 122);
            this.CM_seat_10.TabIndex = 9;
            // 
            // panel65
            // 
            this.panel65.Controls.Add(this.CM_time_remaining10);
            this.panel65.Controls.Add(this.label12);
            this.panel65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel65.Location = new System.Drawing.Point(0, 27);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(110, 68);
            this.panel65.TabIndex = 2;
            // 
            // CM_time_remaining10
            // 
            this.CM_time_remaining10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining10.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining10.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining10.Name = "CM_time_remaining10";
            this.CM_time_remaining10.Size = new System.Drawing.Size(110, 48);
            this.CM_time_remaining10.TabIndex = 1;
            this.CM_time_remaining10.Text = "CM_time_remaining10";
            this.CM_time_remaining10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Top;
            this.label12.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.Location = new System.Drawing.Point(0, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(110, 20);
            this.label12.TabIndex = 3;
            this.label12.Text = "남은시간";
            this.label12.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel66
            // 
            this.panel66.Controls.Add(this.CM_time_using10);
            this.panel66.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel66.Location = new System.Drawing.Point(0, 95);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(110, 27);
            this.panel66.TabIndex = 1;
            // 
            // CM_time_using10
            // 
            this.CM_time_using10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using10.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using10.Name = "CM_time_using10";
            this.CM_time_using10.Size = new System.Drawing.Size(110, 27);
            this.CM_time_using10.TabIndex = 1;
            this.CM_time_using10.Text = "CM_time_using10";
            this.CM_time_using10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel67
            // 
            this.panel67.Controls.Add(this.panel68);
            this.panel67.Controls.Add(this.panel69);
            this.panel67.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel67.Location = new System.Drawing.Point(0, 0);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(110, 27);
            this.panel67.TabIndex = 0;
            // 
            // panel68
            // 
            this.panel68.Controls.Add(this.CM_mb_info10);
            this.panel68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel68.Location = new System.Drawing.Point(27, 0);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(83, 27);
            this.panel68.TabIndex = 1;
            // 
            // CM_mb_info10
            // 
            this.CM_mb_info10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info10.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info10.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info10.Name = "CM_mb_info10";
            this.CM_mb_info10.Size = new System.Drawing.Size(83, 27);
            this.CM_mb_info10.TabIndex = 1;
            this.CM_mb_info10.Text = "CM_mb_info10";
            this.CM_mb_info10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel69
            // 
            this.panel69.Controls.Add(this.CM_seat_num10);
            this.panel69.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel69.Location = new System.Drawing.Point(0, 0);
            this.panel69.Name = "panel69";
            this.panel69.Padding = new System.Windows.Forms.Padding(2);
            this.panel69.Size = new System.Drawing.Size(27, 27);
            this.panel69.TabIndex = 0;
            // 
            // CM_seat_num10
            // 
            this.CM_seat_num10.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num10.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num10.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num10.Name = "CM_seat_num10";
            this.CM_seat_num10.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num10.TabIndex = 0;
            this.CM_seat_num10.Text = "10";
            this.CM_seat_num10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_9
            // 
            this.CM_seat_9.Controls.Add(this.panel59);
            this.CM_seat_9.Controls.Add(this.panel60);
            this.CM_seat_9.Controls.Add(this.panel61);
            this.CM_seat_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_9.Location = new System.Drawing.Point(360, 137);
            this.CM_seat_9.Name = "CM_seat_9";
            this.CM_seat_9.Size = new System.Drawing.Size(109, 122);
            this.CM_seat_9.TabIndex = 8;
            // 
            // panel59
            // 
            this.panel59.Controls.Add(this.CM_time_remaining9);
            this.panel59.Controls.Add(this.label11);
            this.panel59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel59.Location = new System.Drawing.Point(0, 27);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(109, 68);
            this.panel59.TabIndex = 2;
            // 
            // CM_time_remaining9
            // 
            this.CM_time_remaining9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining9.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining9.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining9.Name = "CM_time_remaining9";
            this.CM_time_remaining9.Size = new System.Drawing.Size(109, 48);
            this.CM_time_remaining9.TabIndex = 1;
            this.CM_time_remaining9.Text = "CM_time_remaining9";
            this.CM_time_remaining9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Dock = System.Windows.Forms.DockStyle.Top;
            this.label11.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.Location = new System.Drawing.Point(0, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(109, 20);
            this.label11.TabIndex = 3;
            this.label11.Text = "남은시간";
            this.label11.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel60
            // 
            this.panel60.Controls.Add(this.CM_time_using9);
            this.panel60.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel60.Location = new System.Drawing.Point(0, 95);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(109, 27);
            this.panel60.TabIndex = 1;
            // 
            // CM_time_using9
            // 
            this.CM_time_using9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using9.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using9.Name = "CM_time_using9";
            this.CM_time_using9.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using9.TabIndex = 1;
            this.CM_time_using9.Text = "CM_time_using9";
            this.CM_time_using9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel61
            // 
            this.panel61.Controls.Add(this.panel62);
            this.panel61.Controls.Add(this.panel63);
            this.panel61.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel61.Location = new System.Drawing.Point(0, 0);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(109, 27);
            this.panel61.TabIndex = 0;
            // 
            // panel62
            // 
            this.panel62.Controls.Add(this.CM_mb_info9);
            this.panel62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel62.Location = new System.Drawing.Point(27, 0);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(82, 27);
            this.panel62.TabIndex = 1;
            // 
            // CM_mb_info9
            // 
            this.CM_mb_info9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info9.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info9.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info9.Name = "CM_mb_info9";
            this.CM_mb_info9.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info9.TabIndex = 1;
            this.CM_mb_info9.Text = "CM_mb_info9";
            this.CM_mb_info9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel63
            // 
            this.panel63.Controls.Add(this.CM_seat_num9);
            this.panel63.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel63.Location = new System.Drawing.Point(0, 0);
            this.panel63.Name = "panel63";
            this.panel63.Padding = new System.Windows.Forms.Padding(2);
            this.panel63.Size = new System.Drawing.Size(27, 27);
            this.panel63.TabIndex = 0;
            // 
            // CM_seat_num9
            // 
            this.CM_seat_num9.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num9.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num9.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num9.Name = "CM_seat_num9";
            this.CM_seat_num9.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num9.TabIndex = 0;
            this.CM_seat_num9.Text = "9";
            this.CM_seat_num9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_8
            // 
            this.CM_seat_8.Controls.Add(this.panel53);
            this.CM_seat_8.Controls.Add(this.panel54);
            this.CM_seat_8.Controls.Add(this.panel55);
            this.CM_seat_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_8.Location = new System.Drawing.Point(242, 137);
            this.CM_seat_8.Name = "CM_seat_8";
            this.CM_seat_8.Size = new System.Drawing.Size(109, 122);
            this.CM_seat_8.TabIndex = 7;
            // 
            // panel53
            // 
            this.panel53.Controls.Add(this.CM_time_remaining8);
            this.panel53.Controls.Add(this.label10);
            this.panel53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel53.Location = new System.Drawing.Point(0, 27);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(109, 68);
            this.panel53.TabIndex = 2;
            // 
            // CM_time_remaining8
            // 
            this.CM_time_remaining8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining8.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining8.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining8.Name = "CM_time_remaining8";
            this.CM_time_remaining8.Size = new System.Drawing.Size(109, 48);
            this.CM_time_remaining8.TabIndex = 1;
            this.CM_time_remaining8.Text = "CM_time_remaining8";
            this.CM_time_remaining8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Top;
            this.label10.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(0, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(109, 20);
            this.label10.TabIndex = 3;
            this.label10.Text = "남은시간";
            this.label10.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel54
            // 
            this.panel54.Controls.Add(this.CM_time_using8);
            this.panel54.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel54.Location = new System.Drawing.Point(0, 95);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(109, 27);
            this.panel54.TabIndex = 1;
            // 
            // CM_time_using8
            // 
            this.CM_time_using8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using8.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using8.Name = "CM_time_using8";
            this.CM_time_using8.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using8.TabIndex = 1;
            this.CM_time_using8.Text = "CM_time_using8";
            this.CM_time_using8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel55
            // 
            this.panel55.Controls.Add(this.panel56);
            this.panel55.Controls.Add(this.panel57);
            this.panel55.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel55.Location = new System.Drawing.Point(0, 0);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(109, 27);
            this.panel55.TabIndex = 0;
            // 
            // panel56
            // 
            this.panel56.Controls.Add(this.CM_mb_info8);
            this.panel56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel56.Location = new System.Drawing.Point(27, 0);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(82, 27);
            this.panel56.TabIndex = 1;
            // 
            // CM_mb_info8
            // 
            this.CM_mb_info8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info8.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info8.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info8.Name = "CM_mb_info8";
            this.CM_mb_info8.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info8.TabIndex = 1;
            this.CM_mb_info8.Text = "CM_mb_info8";
            this.CM_mb_info8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel57
            // 
            this.panel57.Controls.Add(this.CM_seat_num8);
            this.panel57.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel57.Location = new System.Drawing.Point(0, 0);
            this.panel57.Name = "panel57";
            this.panel57.Padding = new System.Windows.Forms.Padding(2);
            this.panel57.Size = new System.Drawing.Size(27, 27);
            this.panel57.TabIndex = 0;
            // 
            // CM_seat_num8
            // 
            this.CM_seat_num8.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num8.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num8.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num8.Name = "CM_seat_num8";
            this.CM_seat_num8.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num8.TabIndex = 0;
            this.CM_seat_num8.Text = "8";
            this.CM_seat_num8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_7
            // 
            this.CM_seat_7.Controls.Add(this.panel47);
            this.CM_seat_7.Controls.Add(this.panel48);
            this.CM_seat_7.Controls.Add(this.panel49);
            this.CM_seat_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_7.Location = new System.Drawing.Point(124, 137);
            this.CM_seat_7.Name = "CM_seat_7";
            this.CM_seat_7.Size = new System.Drawing.Size(109, 122);
            this.CM_seat_7.TabIndex = 6;
            // 
            // panel47
            // 
            this.panel47.Controls.Add(this.CM_time_remaining7);
            this.panel47.Controls.Add(this.label9);
            this.panel47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel47.Location = new System.Drawing.Point(0, 27);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(109, 68);
            this.panel47.TabIndex = 2;
            // 
            // CM_time_remaining7
            // 
            this.CM_time_remaining7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining7.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining7.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining7.Name = "CM_time_remaining7";
            this.CM_time_remaining7.Size = new System.Drawing.Size(109, 48);
            this.CM_time_remaining7.TabIndex = 1;
            this.CM_time_remaining7.Text = "CM_time_remaining7";
            this.CM_time_remaining7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(0, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 20);
            this.label9.TabIndex = 2;
            this.label9.Text = "남은시간";
            this.label9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel48
            // 
            this.panel48.Controls.Add(this.CM_time_using7);
            this.panel48.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel48.Location = new System.Drawing.Point(0, 95);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(109, 27);
            this.panel48.TabIndex = 1;
            // 
            // CM_time_using7
            // 
            this.CM_time_using7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using7.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using7.Name = "CM_time_using7";
            this.CM_time_using7.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using7.TabIndex = 1;
            this.CM_time_using7.Text = "CM_time_using7";
            this.CM_time_using7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel49
            // 
            this.panel49.Controls.Add(this.panel50);
            this.panel49.Controls.Add(this.panel51);
            this.panel49.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel49.Location = new System.Drawing.Point(0, 0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(109, 27);
            this.panel49.TabIndex = 0;
            // 
            // panel50
            // 
            this.panel50.Controls.Add(this.CM_mb_info7);
            this.panel50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel50.Location = new System.Drawing.Point(27, 0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(82, 27);
            this.panel50.TabIndex = 1;
            // 
            // CM_mb_info7
            // 
            this.CM_mb_info7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info7.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info7.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info7.Name = "CM_mb_info7";
            this.CM_mb_info7.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info7.TabIndex = 1;
            this.CM_mb_info7.Text = "CM_mb_info7";
            this.CM_mb_info7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel51
            // 
            this.panel51.Controls.Add(this.CM_seat_num7);
            this.panel51.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel51.Location = new System.Drawing.Point(0, 0);
            this.panel51.Name = "panel51";
            this.panel51.Padding = new System.Windows.Forms.Padding(2);
            this.panel51.Size = new System.Drawing.Size(27, 27);
            this.panel51.TabIndex = 0;
            // 
            // CM_seat_num7
            // 
            this.CM_seat_num7.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num7.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num7.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num7.Name = "CM_seat_num7";
            this.CM_seat_num7.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num7.TabIndex = 0;
            this.CM_seat_num7.Text = "7";
            this.CM_seat_num7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_6
            // 
            this.CM_seat_6.Controls.Add(this.panel41);
            this.CM_seat_6.Controls.Add(this.panel42);
            this.CM_seat_6.Controls.Add(this.panel43);
            this.CM_seat_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_6.Location = new System.Drawing.Point(6, 137);
            this.CM_seat_6.Name = "CM_seat_6";
            this.CM_seat_6.Size = new System.Drawing.Size(109, 122);
            this.CM_seat_6.TabIndex = 5;
            // 
            // panel41
            // 
            this.panel41.Controls.Add(this.CM_time_remaining6);
            this.panel41.Controls.Add(this.label8);
            this.panel41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel41.Location = new System.Drawing.Point(0, 27);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(109, 68);
            this.panel41.TabIndex = 2;
            // 
            // CM_time_remaining6
            // 
            this.CM_time_remaining6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining6.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining6.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining6.Name = "CM_time_remaining6";
            this.CM_time_remaining6.Size = new System.Drawing.Size(109, 48);
            this.CM_time_remaining6.TabIndex = 1;
            this.CM_time_remaining6.Text = "CM_time_remaining6";
            this.CM_time_remaining6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 20);
            this.label8.TabIndex = 2;
            this.label8.Text = "남은시간";
            this.label8.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel42
            // 
            this.panel42.Controls.Add(this.CM_time_using6);
            this.panel42.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel42.Location = new System.Drawing.Point(0, 95);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(109, 27);
            this.panel42.TabIndex = 1;
            // 
            // CM_time_using6
            // 
            this.CM_time_using6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using6.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using6.Name = "CM_time_using6";
            this.CM_time_using6.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using6.TabIndex = 1;
            this.CM_time_using6.Text = "CM_time_using6";
            this.CM_time_using6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel43
            // 
            this.panel43.Controls.Add(this.panel44);
            this.panel43.Controls.Add(this.panel45);
            this.panel43.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel43.Location = new System.Drawing.Point(0, 0);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(109, 27);
            this.panel43.TabIndex = 0;
            // 
            // panel44
            // 
            this.panel44.Controls.Add(this.CM_mb_info6);
            this.panel44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel44.Location = new System.Drawing.Point(27, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(82, 27);
            this.panel44.TabIndex = 1;
            // 
            // CM_mb_info6
            // 
            this.CM_mb_info6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info6.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info6.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info6.Name = "CM_mb_info6";
            this.CM_mb_info6.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info6.TabIndex = 1;
            this.CM_mb_info6.Text = "CM_mb_info6";
            this.CM_mb_info6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel45
            // 
            this.panel45.Controls.Add(this.CM_seat_num6);
            this.panel45.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel45.Location = new System.Drawing.Point(0, 0);
            this.panel45.Name = "panel45";
            this.panel45.Padding = new System.Windows.Forms.Padding(2);
            this.panel45.Size = new System.Drawing.Size(27, 27);
            this.panel45.TabIndex = 0;
            // 
            // CM_seat_num6
            // 
            this.CM_seat_num6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num6.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num6.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num6.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num6.Name = "CM_seat_num6";
            this.CM_seat_num6.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.CM_seat_num6.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num6.TabIndex = 0;
            this.CM_seat_num6.Text = "6";
            this.CM_seat_num6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_5
            // 
            this.CM_seat_5.Controls.Add(this.panel35);
            this.CM_seat_5.Controls.Add(this.panel36);
            this.CM_seat_5.Controls.Add(this.panel37);
            this.CM_seat_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_5.Location = new System.Drawing.Point(478, 6);
            this.CM_seat_5.Name = "CM_seat_5";
            this.CM_seat_5.Size = new System.Drawing.Size(110, 122);
            this.CM_seat_5.TabIndex = 4;
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.CM_time_remaining5);
            this.panel35.Controls.Add(this.label7);
            this.panel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel35.Location = new System.Drawing.Point(0, 27);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(110, 68);
            this.panel35.TabIndex = 2;
            // 
            // CM_time_remaining5
            // 
            this.CM_time_remaining5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining5.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining5.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining5.Name = "CM_time_remaining5";
            this.CM_time_remaining5.Size = new System.Drawing.Size(110, 48);
            this.CM_time_remaining5.TabIndex = 1;
            this.CM_time_remaining5.Text = "CM_time_remaining5";
            this.CM_time_remaining5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 20);
            this.label7.TabIndex = 2;
            this.label7.Text = "남은시간";
            this.label7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel36
            // 
            this.panel36.Controls.Add(this.CM_time_using5);
            this.panel36.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel36.Location = new System.Drawing.Point(0, 95);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(110, 27);
            this.panel36.TabIndex = 1;
            // 
            // CM_time_using5
            // 
            this.CM_time_using5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using5.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using5.Name = "CM_time_using5";
            this.CM_time_using5.Size = new System.Drawing.Size(110, 27);
            this.CM_time_using5.TabIndex = 1;
            this.CM_time_using5.Text = "CM_time_using5";
            this.CM_time_using5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.panel28);
            this.panel37.Controls.Add(this.panel22);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel37.Location = new System.Drawing.Point(0, 0);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(110, 27);
            this.panel37.TabIndex = 0;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.CM_mb_info5);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel28.Location = new System.Drawing.Point(27, 0);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(83, 27);
            this.panel28.TabIndex = 2;
            // 
            // CM_mb_info5
            // 
            this.CM_mb_info5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info5.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info5.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info5.Name = "CM_mb_info5";
            this.CM_mb_info5.Size = new System.Drawing.Size(83, 27);
            this.CM_mb_info5.TabIndex = 1;
            this.CM_mb_info5.Text = "CM_mb_info5";
            this.CM_mb_info5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.DarkGray;
            this.panel22.Controls.Add(this.CM_seat_num5);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel22.Location = new System.Drawing.Point(0, 0);
            this.panel22.Name = "panel22";
            this.panel22.Padding = new System.Windows.Forms.Padding(2);
            this.panel22.Size = new System.Drawing.Size(27, 27);
            this.panel22.TabIndex = 1;
            // 
            // CM_seat_num5
            // 
            this.CM_seat_num5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num5.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CM_seat_num5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num5.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num5.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num5.Name = "CM_seat_num5";
            this.CM_seat_num5.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num5.TabIndex = 0;
            this.CM_seat_num5.Text = "5";
            this.CM_seat_num5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_4
            // 
            this.CM_seat_4.Controls.Add(this.panel29);
            this.CM_seat_4.Controls.Add(this.panel30);
            this.CM_seat_4.Controls.Add(this.panel31);
            this.CM_seat_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_4.Location = new System.Drawing.Point(360, 6);
            this.CM_seat_4.Name = "CM_seat_4";
            this.CM_seat_4.Size = new System.Drawing.Size(109, 122);
            this.CM_seat_4.TabIndex = 3;
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.CM_time_remaining4);
            this.panel29.Controls.Add(this.label6);
            this.panel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel29.Location = new System.Drawing.Point(0, 27);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(109, 68);
            this.panel29.TabIndex = 2;
            // 
            // CM_time_remaining4
            // 
            this.CM_time_remaining4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining4.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining4.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining4.Name = "CM_time_remaining4";
            this.CM_time_remaining4.Size = new System.Drawing.Size(109, 48);
            this.CM_time_remaining4.TabIndex = 1;
            this.CM_time_remaining4.Text = "CM_time_remaining4";
            this.CM_time_remaining4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "남은시간";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.CM_time_using4);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel30.Location = new System.Drawing.Point(0, 95);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(109, 27);
            this.panel30.TabIndex = 1;
            // 
            // CM_time_using4
            // 
            this.CM_time_using4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using4.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using4.Name = "CM_time_using4";
            this.CM_time_using4.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using4.TabIndex = 1;
            this.CM_time_using4.Text = "CM_time_using4";
            this.CM_time_using4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.panel32);
            this.panel31.Controls.Add(this.panel33);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel31.Location = new System.Drawing.Point(0, 0);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(109, 27);
            this.panel31.TabIndex = 0;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.CM_mb_info4);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Location = new System.Drawing.Point(27, 0);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(82, 27);
            this.panel32.TabIndex = 1;
            // 
            // CM_mb_info4
            // 
            this.CM_mb_info4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info4.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info4.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info4.Name = "CM_mb_info4";
            this.CM_mb_info4.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info4.TabIndex = 1;
            this.CM_mb_info4.Text = "CM_mb_info4";
            this.CM_mb_info4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.CM_seat_num4);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Padding = new System.Windows.Forms.Padding(2);
            this.panel33.Size = new System.Drawing.Size(27, 27);
            this.panel33.TabIndex = 0;
            // 
            // CM_seat_num4
            // 
            this.CM_seat_num4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num4.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num4.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num4.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num4.Name = "CM_seat_num4";
            this.CM_seat_num4.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num4.TabIndex = 0;
            this.CM_seat_num4.Text = "4";
            this.CM_seat_num4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_3
            // 
            this.CM_seat_3.Controls.Add(this.panel23);
            this.CM_seat_3.Controls.Add(this.panel24);
            this.CM_seat_3.Controls.Add(this.panel25);
            this.CM_seat_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_3.Location = new System.Drawing.Point(242, 6);
            this.CM_seat_3.Name = "CM_seat_3";
            this.CM_seat_3.Size = new System.Drawing.Size(109, 122);
            this.CM_seat_3.TabIndex = 2;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.CM_time_remaining3);
            this.panel23.Controls.Add(this.label5);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(0, 27);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(109, 68);
            this.panel23.TabIndex = 2;
            // 
            // CM_time_remaining3
            // 
            this.CM_time_remaining3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining3.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining3.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining3.Name = "CM_time_remaining3";
            this.CM_time_remaining3.Size = new System.Drawing.Size(109, 48);
            this.CM_time_remaining3.TabIndex = 1;
            this.CM_time_remaining3.Text = "CM_time_remaining3";
            this.CM_time_remaining3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 20);
            this.label5.TabIndex = 2;
            this.label5.Text = "남은시간";
            this.label5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.CM_time_using3);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel24.Location = new System.Drawing.Point(0, 95);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(109, 27);
            this.panel24.TabIndex = 1;
            // 
            // CM_time_using3
            // 
            this.CM_time_using3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using3.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using3.Name = "CM_time_using3";
            this.CM_time_using3.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using3.TabIndex = 1;
            this.CM_time_using3.Text = "CM_time_using3";
            this.CM_time_using3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.panel26);
            this.panel25.Controls.Add(this.panel27);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel25.Location = new System.Drawing.Point(0, 0);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(109, 27);
            this.panel25.TabIndex = 0;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.CM_mb_info3);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(27, 0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(82, 27);
            this.panel26.TabIndex = 1;
            // 
            // CM_mb_info3
            // 
            this.CM_mb_info3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info3.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info3.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info3.Name = "CM_mb_info3";
            this.CM_mb_info3.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info3.TabIndex = 1;
            this.CM_mb_info3.Text = "CM_mb_info3";
            this.CM_mb_info3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.CM_seat_num3);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel27.Location = new System.Drawing.Point(0, 0);
            this.panel27.Name = "panel27";
            this.panel27.Padding = new System.Windows.Forms.Padding(2);
            this.panel27.Size = new System.Drawing.Size(27, 27);
            this.panel27.TabIndex = 0;
            // 
            // CM_seat_num3
            // 
            this.CM_seat_num3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num3.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num3.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num3.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num3.Name = "CM_seat_num3";
            this.CM_seat_num3.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num3.TabIndex = 0;
            this.CM_seat_num3.Text = "3";
            this.CM_seat_num3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_2
            // 
            this.CM_seat_2.BackColor = System.Drawing.Color.Gray;
            this.CM_seat_2.Controls.Add(this.panel17);
            this.CM_seat_2.Controls.Add(this.panel18);
            this.CM_seat_2.Controls.Add(this.panel19);
            this.CM_seat_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_2.Location = new System.Drawing.Point(124, 6);
            this.CM_seat_2.Name = "CM_seat_2";
            this.CM_seat_2.Size = new System.Drawing.Size(109, 122);
            this.CM_seat_2.TabIndex = 1;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.CM_time_remaining2);
            this.panel17.Controls.Add(this.label4);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(0, 27);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(109, 68);
            this.panel17.TabIndex = 2;
            // 
            // CM_time_remaining2
            // 
            this.CM_time_remaining2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining2.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining2.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining2.Name = "CM_time_remaining2";
            this.CM_time_remaining2.Size = new System.Drawing.Size(109, 48);
            this.CM_time_remaining2.TabIndex = 1;
            this.CM_time_remaining2.Text = "CM_time_remaining2";
            this.CM_time_remaining2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "남은시간";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.CM_time_using2);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel18.Location = new System.Drawing.Point(0, 95);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(109, 27);
            this.panel18.TabIndex = 1;
            // 
            // CM_time_using2
            // 
            this.CM_time_using2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using2.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using2.Name = "CM_time_using2";
            this.CM_time_using2.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using2.TabIndex = 1;
            this.CM_time_using2.Text = "CM_time_using2";
            this.CM_time_using2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Controls.Add(this.panel21);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(109, 27);
            this.panel19.TabIndex = 0;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.CM_mb_info2);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(27, 0);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(82, 27);
            this.panel20.TabIndex = 1;
            // 
            // CM_mb_info2
            // 
            this.CM_mb_info2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info2.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info2.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info2.Name = "CM_mb_info2";
            this.CM_mb_info2.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info2.TabIndex = 1;
            this.CM_mb_info2.Text = "CM_mb_info2";
            this.CM_mb_info2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.CM_seat_num2);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Padding = new System.Windows.Forms.Padding(2);
            this.panel21.Size = new System.Drawing.Size(27, 27);
            this.panel21.TabIndex = 0;
            // 
            // CM_seat_num2
            // 
            this.CM_seat_num2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num2.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num2.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num2.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num2.Name = "CM_seat_num2";
            this.CM_seat_num2.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num2.TabIndex = 0;
            this.CM_seat_num2.Text = "2";
            this.CM_seat_num2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CM_seat_1
            // 
            this.CM_seat_1.Controls.Add(this.panel15);
            this.CM_seat_1.Controls.Add(this.panel14);
            this.CM_seat_1.Controls.Add(this.panel11);
            this.CM_seat_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_seat_1.Location = new System.Drawing.Point(6, 6);
            this.CM_seat_1.Name = "CM_seat_1";
            this.CM_seat_1.Size = new System.Drawing.Size(109, 122);
            this.CM_seat_1.TabIndex = 0;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.CM_time_remaining1);
            this.panel15.Controls.Add(this.label3);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(0, 27);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(109, 68);
            this.panel15.TabIndex = 2;
            // 
            // CM_time_remaining1
            // 
            this.CM_time_remaining1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_remaining1.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_time_remaining1.Location = new System.Drawing.Point(0, 20);
            this.CM_time_remaining1.Name = "CM_time_remaining1";
            this.CM_time_remaining1.Size = new System.Drawing.Size(109, 48);
            this.CM_time_remaining1.TabIndex = 0;
            this.CM_time_remaining1.Text = "CM_time_remaining1";
            this.CM_time_remaining1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "남은시간";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.CM_time_using1);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel14.Location = new System.Drawing.Point(0, 95);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(109, 27);
            this.panel14.TabIndex = 1;
            // 
            // CM_time_using1
            // 
            this.CM_time_using1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_time_using1.Location = new System.Drawing.Point(0, 0);
            this.CM_time_using1.Name = "CM_time_using1";
            this.CM_time_using1.Size = new System.Drawing.Size(109, 27);
            this.CM_time_using1.TabIndex = 0;
            this.CM_time_using1.Text = "CM_time_using1";
            this.CM_time_using1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.panel13);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(109, 27);
            this.panel11.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.CM_mb_info1);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(27, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(82, 27);
            this.panel13.TabIndex = 2;
            // 
            // CM_mb_info1
            // 
            this.CM_mb_info1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CM_mb_info1.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_mb_info1.Location = new System.Drawing.Point(0, 0);
            this.CM_mb_info1.Name = "CM_mb_info1";
            this.CM_mb_info1.Size = new System.Drawing.Size(82, 27);
            this.CM_mb_info1.TabIndex = 0;
            this.CM_mb_info1.Text = "CM_mb_info1";
            this.CM_mb_info1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.DarkGray;
            this.panel12.Controls.Add(this.CM_seat_num1);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Padding = new System.Windows.Forms.Padding(2);
            this.panel12.Size = new System.Drawing.Size(27, 27);
            this.panel12.TabIndex = 0;
            // 
            // CM_seat_num1
            // 
            this.CM_seat_num1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CM_seat_num1.BackColor = System.Drawing.Color.Black;
            this.CM_seat_num1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CM_seat_num1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CM_seat_num1.ForeColor = System.Drawing.Color.White;
            this.CM_seat_num1.Location = new System.Drawing.Point(2, 2);
            this.CM_seat_num1.Name = "CM_seat_num1";
            this.CM_seat_num1.Size = new System.Drawing.Size(29, 23);
            this.CM_seat_num1.TabIndex = 0;
            this.CM_seat_num1.Text = "1";
            this.CM_seat_num1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel10);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(2);
            this.panel6.Size = new System.Drawing.Size(420, 404);
            this.panel6.TabIndex = 0;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.grid_order_view);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(2, 108);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(414, 292);
            this.panel8.TabIndex = 2;
            // 
            // grid_order_view
            // 
            this.grid_order_view.AllowUserToAddRows = false;
            this.grid_order_view.AllowUserToDeleteRows = false;
            this.grid_order_view.AllowUserToResizeColumns = false;
            this.grid_order_view.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.DarkOliveGreen;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.grid_order_view.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.grid_order_view.AutoGenerateColumns = false;
            this.grid_order_view.BackgroundColor = System.Drawing.Color.Gray;
            this.grid_order_view.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenVertical;
            this.grid_order_view.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Yellow;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_order_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.grid_order_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_order_view.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.snumDataGridViewTextBoxColumn,
            this.pnameDataGridViewTextBoxColumn,
            this.odrpamountDataGridViewTextBoxColumn,
            this.odrptimeDataGridViewTextBoxColumn});
            this.grid_order_view.DataMember = "Dp_order";
            this.grid_order_view.DataSource = this.productdata;
            this.grid_order_view.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_order_view.GridColor = System.Drawing.Color.Black;
            this.grid_order_view.Location = new System.Drawing.Point(0, 0);
            this.grid_order_view.Name = "grid_order_view";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Yellow;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_order_view.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grid_order_view.RowHeadersWidth = 10;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.DarkSeaGreen;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DarkOliveGreen;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.grid_order_view.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.grid_order_view.RowTemplate.Height = 23;
            this.grid_order_view.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_order_view.Size = new System.Drawing.Size(414, 292);
            this.grid_order_view.TabIndex = 0;
            this.grid_order_view.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_order_view_CellDoubleClick);
            // 
            // snumDataGridViewTextBoxColumn
            // 
            this.snumDataGridViewTextBoxColumn.DataPropertyName = "S_num";
            this.snumDataGridViewTextBoxColumn.HeaderText = "좌석";
            this.snumDataGridViewTextBoxColumn.Name = "snumDataGridViewTextBoxColumn";
            this.snumDataGridViewTextBoxColumn.ReadOnly = true;
            this.snumDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.snumDataGridViewTextBoxColumn.Width = 60;
            // 
            // pnameDataGridViewTextBoxColumn
            // 
            this.pnameDataGridViewTextBoxColumn.DataPropertyName = "P_name";
            this.pnameDataGridViewTextBoxColumn.HeaderText = "상품명";
            this.pnameDataGridViewTextBoxColumn.Name = "pnameDataGridViewTextBoxColumn";
            this.pnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.pnameDataGridViewTextBoxColumn.Width = 180;
            // 
            // odrpamountDataGridViewTextBoxColumn
            // 
            this.odrpamountDataGridViewTextBoxColumn.DataPropertyName = "odrp_amount";
            this.odrpamountDataGridViewTextBoxColumn.HeaderText = "수량";
            this.odrpamountDataGridViewTextBoxColumn.Name = "odrpamountDataGridViewTextBoxColumn";
            this.odrpamountDataGridViewTextBoxColumn.ReadOnly = true;
            this.odrpamountDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.odrpamountDataGridViewTextBoxColumn.Width = 60;
            // 
            // odrptimeDataGridViewTextBoxColumn
            // 
            this.odrptimeDataGridViewTextBoxColumn.DataPropertyName = "odrp_time";
            this.odrptimeDataGridViewTextBoxColumn.HeaderText = "주문시간";
            this.odrptimeDataGridViewTextBoxColumn.Name = "odrptimeDataGridViewTextBoxColumn";
            this.odrptimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.odrptimeDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // productdata
            // 
            this.productdata.DataSetName = "NewDataSet";
            this.productdata.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1,
            this.dataTable2});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.좌석번,
            this.상품명,
            this.주문수,
            this.전달여부});
            this.dataTable1.TableName = "productinfo";
            // 
            // 좌석번
            // 
            this.좌석번.ColumnName = "CM_saet_num";
            this.좌석번.ReadOnly = true;
            // 
            // 상품명
            // 
            this.상품명.ColumnName = "CM_pd_name";
            this.상품명.ReadOnly = true;
            // 
            // 주문수
            // 
            this.주문수.ColumnName = "CM_older";
            // 
            // 전달여부
            // 
            this.전달여부.ColumnName = "CM_deliver";
            // 
            // dataTable2
            // 
            this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4,
            this.dataColumn5,
            this.dataColumn6});
            this.dataTable2.TableName = "Dp_order";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "odrp_num";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "S_num";
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "P_name";
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "odrp_memo";
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "odrp_amount";
            // 
            // dataColumn6
            // 
            this.dataColumn6.Caption = "odrp_time";
            this.dataColumn6.ColumnName = "odrp_time";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Gray;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.main_stitle);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(2, 76);
            this.panel10.Name = "panel10";
            this.panel10.Padding = new System.Windows.Forms.Padding(7);
            this.panel10.Size = new System.Drawing.Size(414, 32);
            this.panel10.TabIndex = 1;
            // 
            // main_stitle
            // 
            this.main_stitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main_stitle.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.main_stitle.Location = new System.Drawing.Point(7, 7);
            this.main_stitle.Name = "main_stitle";
            this.main_stitle.Size = new System.Drawing.Size(398, 16);
            this.main_stitle.TabIndex = 0;
            this.main_stitle.Text = "<상품 주문 관리>";
            this.main_stitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel38);
            this.panel7.Controls.Add(this.panel34);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(2, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(414, 74);
            this.panel7.TabIndex = 0;
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel38.Controls.Add(this.label_CM_availableseat);
            this.panel38.Controls.Add(this.label2);
            this.panel38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel38.Location = new System.Drawing.Point(212, 0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(202, 74);
            this.panel38.TabIndex = 1;
            // 
            // label_CM_availableseat
            // 
            this.label_CM_availableseat.BackColor = System.Drawing.Color.Gray;
            this.label_CM_availableseat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_CM_availableseat.Font = new System.Drawing.Font("굴림", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_CM_availableseat.Location = new System.Drawing.Point(0, 24);
            this.label_CM_availableseat.Name = "label_CM_availableseat";
            this.label_CM_availableseat.Size = new System.Drawing.Size(200, 48);
            this.label_CM_availableseat.TabIndex = 2;
            this.label_CM_availableseat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Gray;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "사용가능 좌석";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.Gray;
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.Controls.Add(this.label_CM_usingseat);
            this.panel34.Controls.Add(this.label1);
            this.panel34.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel34.Location = new System.Drawing.Point(0, 0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(212, 74);
            this.panel34.TabIndex = 0;
            // 
            // label_CM_usingseat
            // 
            this.label_CM_usingseat.BackColor = System.Drawing.Color.Gray;
            this.label_CM_usingseat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_CM_usingseat.Font = new System.Drawing.Font("굴림", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_CM_usingseat.Location = new System.Drawing.Point(0, 24);
            this.label_CM_usingseat.Name = "label_CM_usingseat";
            this.label_CM_usingseat.Size = new System.Drawing.Size(210, 48);
            this.label_CM_usingseat.TabIndex = 1;
            this.label_CM_usingseat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "사용중인 좌석";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 5000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // counter_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1020, 464);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(860, 491);
            this.Name = "counter_main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PC_main";
            this.Load += new System.EventHandler(this.counter_main_Load);
            this.panel1.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.CM_seat_15.ResumeLayout(false);
            this.panel95.ResumeLayout(false);
            this.panel96.ResumeLayout(false);
            this.panel97.ResumeLayout(false);
            this.panel98.ResumeLayout(false);
            this.panel99.ResumeLayout(false);
            this.CM_seat_14.ResumeLayout(false);
            this.panel89.ResumeLayout(false);
            this.panel90.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel92.ResumeLayout(false);
            this.panel93.ResumeLayout(false);
            this.CM_seat_13.ResumeLayout(false);
            this.panel83.ResumeLayout(false);
            this.panel84.ResumeLayout(false);
            this.panel85.ResumeLayout(false);
            this.panel86.ResumeLayout(false);
            this.panel87.ResumeLayout(false);
            this.CM_seat_12.ResumeLayout(false);
            this.panel77.ResumeLayout(false);
            this.panel78.ResumeLayout(false);
            this.panel79.ResumeLayout(false);
            this.panel80.ResumeLayout(false);
            this.panel81.ResumeLayout(false);
            this.CM_seat_11.ResumeLayout(false);
            this.panel71.ResumeLayout(false);
            this.panel72.ResumeLayout(false);
            this.panel73.ResumeLayout(false);
            this.panel74.ResumeLayout(false);
            this.panel75.ResumeLayout(false);
            this.CM_seat_10.ResumeLayout(false);
            this.panel65.ResumeLayout(false);
            this.panel66.ResumeLayout(false);
            this.panel67.ResumeLayout(false);
            this.panel68.ResumeLayout(false);
            this.panel69.ResumeLayout(false);
            this.CM_seat_9.ResumeLayout(false);
            this.panel59.ResumeLayout(false);
            this.panel60.ResumeLayout(false);
            this.panel61.ResumeLayout(false);
            this.panel62.ResumeLayout(false);
            this.panel63.ResumeLayout(false);
            this.CM_seat_8.ResumeLayout(false);
            this.panel53.ResumeLayout(false);
            this.panel54.ResumeLayout(false);
            this.panel55.ResumeLayout(false);
            this.panel56.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.CM_seat_7.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel50.ResumeLayout(false);
            this.panel51.ResumeLayout(false);
            this.CM_seat_6.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.CM_seat_5.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.CM_seat_4.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.CM_seat_3.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.CM_seat_2.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.CM_seat_1.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_order_view)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productdata)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_CM_screen_lock;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btn_CM_product_mg;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_CM_member_mg;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label main_stitle;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridView grid_order_view;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel CM_seat_15;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Panel panel98;
        private System.Windows.Forms.Panel panel99;
        private System.Windows.Forms.Label CM_seat_num15;
        private System.Windows.Forms.Panel CM_seat_14;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Label CM_seat_num14;
        private System.Windows.Forms.Panel CM_seat_13;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Label CM_seat_num13;
        private System.Windows.Forms.Panel CM_seat_12;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Label CM_seat_num12;
        private System.Windows.Forms.Panel CM_seat_11;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Label CM_seat_num11;
        private System.Windows.Forms.Panel CM_seat_10;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Label CM_seat_num10;
        private System.Windows.Forms.Panel CM_seat_9;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Label CM_seat_num9;
        private System.Windows.Forms.Panel CM_seat_8;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Label CM_seat_num8;
        private System.Windows.Forms.Panel CM_seat_7;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Label CM_seat_num7;
        private System.Windows.Forms.Panel CM_seat_6;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Label CM_seat_num6;
        private System.Windows.Forms.Panel CM_seat_4;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label CM_seat_num4;
        private System.Windows.Forms.Panel CM_seat_3;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel CM_seat_2;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel CM_seat_1;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label CM_seat_num1;
        private System.Windows.Forms.Panel CM_seat_5;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label CM_seat_num5;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label CM_seat_num3;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label CM_seat_num2;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label CM_mb_info1;
        private System.Windows.Forms.Label CM_mb_info15;
        private System.Windows.Forms.Label CM_mb_info14;
        private System.Windows.Forms.Label CM_mb_info13;
        private System.Windows.Forms.Label CM_mb_info12;
        private System.Windows.Forms.Label CM_mb_info11;
        private System.Windows.Forms.Label CM_mb_info10;
        private System.Windows.Forms.Label CM_mb_info9;
        private System.Windows.Forms.Label CM_mb_info8;
        private System.Windows.Forms.Label CM_mb_info7;
        private System.Windows.Forms.Label CM_mb_info6;
        private System.Windows.Forms.Label CM_mb_info5;
        private System.Windows.Forms.Label CM_mb_info4;
        private System.Windows.Forms.Label CM_mb_info3;
        private System.Windows.Forms.Label CM_mb_info2;
        private System.Windows.Forms.Label CM_time_remaining1;
        private System.Windows.Forms.Label CM_time_remaining15;
        private System.Windows.Forms.Label CM_time_remaining14;
        private System.Windows.Forms.Label CM_time_remaining13;
        private System.Windows.Forms.Label CM_time_remaining12;
        private System.Windows.Forms.Label CM_time_remaining11;
        private System.Windows.Forms.Label CM_time_remaining10;
        private System.Windows.Forms.Label CM_time_remaining9;
        private System.Windows.Forms.Label CM_time_remaining8;
        private System.Windows.Forms.Label CM_time_remaining7;
        private System.Windows.Forms.Label CM_time_remaining6;
        private System.Windows.Forms.Label CM_time_remaining5;
        private System.Windows.Forms.Label CM_time_remaining4;
        private System.Windows.Forms.Label CM_time_remaining3;
        private System.Windows.Forms.Label CM_time_remaining2;
        private System.Windows.Forms.Label CM_time_using15;
        private System.Windows.Forms.Label CM_time_using14;
        private System.Windows.Forms.Label CM_time_using13;
        private System.Windows.Forms.Label CM_time_using12;
        private System.Windows.Forms.Label CM_time_using11;
        private System.Windows.Forms.Label CM_time_using10;
        private System.Windows.Forms.Label CM_time_using9;
        private System.Windows.Forms.Label CM_time_using8;
        private System.Windows.Forms.Label CM_time_using7;
        private System.Windows.Forms.Label CM_time_using6;
        private System.Windows.Forms.Label CM_time_using5;
        private System.Windows.Forms.Label CM_time_using4;
        private System.Windows.Forms.Label CM_time_using3;
        private System.Windows.Forms.Label CM_time_using2;
        private System.Windows.Forms.Label CM_time_using1;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_CM_usingseat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_CM_availableseat;
        private System.Data.DataSet productdata;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn 좌석번;
        private System.Data.DataColumn 상품명;
        private System.Data.DataColumn 주문수;
        private System.Data.DataColumn 전달여부;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Data.DataTable dataTable2;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Windows.Forms.Timer timer2;
        private System.Data.DataColumn dataColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn snumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn odrpamountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn odrptimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Button btn_CM_settings;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Button btn_CM_close;
    }
}

