﻿namespace mainPC.Windows.mainPC.회원관리 {
    partial class MBM_add_member {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
        if (disposing && (components != null)) {
        components.Dispose();
        }
        base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panel7 = new System.Windows.Forms.Panel();
            this.btn_addmb_save = new System.Windows.Forms.Button();
            this.label_addmb_ph_mess = new System.Windows.Forms.Label();
            this.label_addmb_name_mess = new System.Windows.Forms.Label();
            this.label_addmb_pw_mess = new System.Windows.Forms.Label();
            this.btn_addmb_id_doubleck = new System.Windows.Forms.Button();
            this.table_addmb = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.date_addmb_birthdate = new System.Windows.Forms.DateTimePicker();
            this.panel26 = new System.Windows.Forms.Panel();
            this.date_addmb_newdate = new System.Windows.Forms.DateTimePicker();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label_addmb_newdate = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.tbox_addmb_ph = new System.Windows.Forms.TextBox();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label_addmb_ph = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.tbox_addmb_pw = new System.Windows.Forms.TextBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label_addmb_pw = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.tbox_addmb_id = new System.Windows.Forms.TextBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label_addmb_id = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.tbox_addmb_name = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label_addmb_name = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_addmb_birthdate = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label_addmb_title = new System.Windows.Forms.Label();
            this.panel7.SuspendLayout();
            this.table_addmb.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.btn_addmb_save);
            this.panel7.Controls.Add(this.label_addmb_ph_mess);
            this.panel7.Controls.Add(this.label_addmb_name_mess);
            this.panel7.Controls.Add(this.label_addmb_pw_mess);
            this.panel7.Controls.Add(this.btn_addmb_id_doubleck);
            this.panel7.Controls.Add(this.table_addmb);
            this.panel7.Controls.Add(this.panel11);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(421, 211);
            this.panel7.TabIndex = 1;
            // 
            // btn_addmb_save
            // 
            this.btn_addmb_save.BackColor = System.Drawing.Color.Black;
            this.btn_addmb_save.Enabled = false;
            this.btn_addmb_save.ForeColor = System.Drawing.Color.Yellow;
            this.btn_addmb_save.Location = new System.Drawing.Point(306, 173);
            this.btn_addmb_save.Name = "btn_addmb_save";
            this.btn_addmb_save.Size = new System.Drawing.Size(111, 34);
            this.btn_addmb_save.TabIndex = 8;
            this.btn_addmb_save.Text = "저장";
            this.btn_addmb_save.UseVisualStyleBackColor = false;
            this.btn_addmb_save.Click += new System.EventHandler(this.btn_addmb_save_Click);
            // 
            // label_addmb_ph_mess
            // 
            this.label_addmb_ph_mess.AutoSize = true;
            this.label_addmb_ph_mess.Location = new System.Drawing.Point(228, 134);
            this.label_addmb_ph_mess.Name = "label_addmb_ph_mess";
            this.label_addmb_ph_mess.Size = new System.Drawing.Size(111, 12);
            this.label_addmb_ph_mess.TabIndex = 7;
            this.label_addmb_ph_mess.Text = "\'-\' 없이 입력하세요";
            // 
            // label_addmb_name_mess
            // 
            this.label_addmb_name_mess.AutoSize = true;
            this.label_addmb_name_mess.Location = new System.Drawing.Point(228, 45);
            this.label_addmb_name_mess.Name = "label_addmb_name_mess";
            this.label_addmb_name_mess.Size = new System.Drawing.Size(173, 12);
            this.label_addmb_name_mess.TabIndex = 6;
            this.label_addmb_name_mess.Text = "반드시 실명으로 입력해주세요.";
            // 
            // label_addmb_pw_mess
            // 
            this.label_addmb_pw_mess.AutoSize = true;
            this.label_addmb_pw_mess.Location = new System.Drawing.Point(228, 103);
            this.label_addmb_pw_mess.Name = "label_addmb_pw_mess";
            this.label_addmb_pw_mess.Size = new System.Drawing.Size(161, 12);
            this.label_addmb_pw_mess.TabIndex = 5;
            this.label_addmb_pw_mess.Text = "(16자 이내의 영문/숫자조합)";
            // 
            // btn_addmb_id_doubleck
            // 
            this.btn_addmb_id_doubleck.BackColor = System.Drawing.Color.Black;
            this.btn_addmb_id_doubleck.ForeColor = System.Drawing.Color.White;
            this.btn_addmb_id_doubleck.Location = new System.Drawing.Point(230, 68);
            this.btn_addmb_id_doubleck.Name = "btn_addmb_id_doubleck";
            this.btn_addmb_id_doubleck.Size = new System.Drawing.Size(120, 23);
            this.btn_addmb_id_doubleck.TabIndex = 3;
            this.btn_addmb_id_doubleck.Text = "✔ 아이디 중복확인";
            this.btn_addmb_id_doubleck.UseVisualStyleBackColor = false;
            this.btn_addmb_id_doubleck.Click += new System.EventHandler(this.btn_addmb_id_doubleck_Click);
            // 
            // table_addmb
            // 
            this.table_addmb.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.table_addmb.ColumnCount = 2;
            this.table_addmb.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.table_addmb.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.table_addmb.Controls.Add(this.panel2, 1, 4);
            this.table_addmb.Controls.Add(this.panel26, 0, 5);
            this.table_addmb.Controls.Add(this.panel25, 0, 5);
            this.table_addmb.Controls.Add(this.panel24, 1, 3);
            this.table_addmb.Controls.Add(this.panel23, 0, 3);
            this.table_addmb.Controls.Add(this.panel20, 1, 2);
            this.table_addmb.Controls.Add(this.panel19, 0, 2);
            this.table_addmb.Controls.Add(this.panel18, 1, 1);
            this.table_addmb.Controls.Add(this.panel17, 0, 1);
            this.table_addmb.Controls.Add(this.panel16, 1, 0);
            this.table_addmb.Controls.Add(this.panel15, 0, 0);
            this.table_addmb.Controls.Add(this.panel1, 0, 4);
            this.table_addmb.Dock = System.Windows.Forms.DockStyle.Left;
            this.table_addmb.Location = new System.Drawing.Point(0, 35);
            this.table_addmb.Name = "table_addmb";
            this.table_addmb.RowCount = 6;
            this.table_addmb.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.table_addmb.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.table_addmb.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.table_addmb.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.table_addmb.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.table_addmb.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.table_addmb.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.table_addmb.Size = new System.Drawing.Size(220, 174);
            this.table_addmb.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.date_addmb_birthdate);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(71, 121);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(144, 21);
            this.panel2.TabIndex = 17;
            // 
            // date_addmb_birthdate
            // 
            this.date_addmb_birthdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.date_addmb_birthdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date_addmb_birthdate.Location = new System.Drawing.Point(0, 0);
            this.date_addmb_birthdate.Name = "date_addmb_birthdate";
            this.date_addmb_birthdate.Size = new System.Drawing.Size(144, 21);
            this.date_addmb_birthdate.TabIndex = 1;
            this.date_addmb_birthdate.Value = new System.DateTime(1999, 3, 12, 0, 0, 0, 0);
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.date_addmb_newdate);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(71, 150);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(144, 21);
            this.panel26.TabIndex = 15;
            // 
            // date_addmb_newdate
            // 
            this.date_addmb_newdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.date_addmb_newdate.Enabled = false;
            this.date_addmb_newdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date_addmb_newdate.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.date_addmb_newdate.Location = new System.Drawing.Point(0, 0);
            this.date_addmb_newdate.Name = "date_addmb_newdate";
            this.date_addmb_newdate.Size = new System.Drawing.Size(144, 21);
            this.date_addmb_newdate.TabIndex = 1;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.label_addmb_newdate);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(5, 150);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(58, 21);
            this.panel25.TabIndex = 14;
            // 
            // label_addmb_newdate
            // 
            this.label_addmb_newdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_addmb_newdate.ForeColor = System.Drawing.Color.White;
            this.label_addmb_newdate.Location = new System.Drawing.Point(0, 0);
            this.label_addmb_newdate.Name = "label_addmb_newdate";
            this.label_addmb_newdate.Size = new System.Drawing.Size(58, 21);
            this.label_addmb_newdate.TabIndex = 1;
            this.label_addmb_newdate.Text = "가입일";
            this.label_addmb_newdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.tbox_addmb_ph);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(71, 92);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(144, 21);
            this.panel24.TabIndex = 11;
            // 
            // tbox_addmb_ph
            // 
            this.tbox_addmb_ph.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_addmb_ph.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tbox_addmb_ph.Location = new System.Drawing.Point(0, 0);
            this.tbox_addmb_ph.MaxLength = 14;
            this.tbox_addmb_ph.Name = "tbox_addmb_ph";
            this.tbox_addmb_ph.Size = new System.Drawing.Size(144, 21);
            this.tbox_addmb_ph.TabIndex = 2;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.label_addmb_ph);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(5, 92);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(58, 21);
            this.panel23.TabIndex = 10;
            // 
            // label_addmb_ph
            // 
            this.label_addmb_ph.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_addmb_ph.ForeColor = System.Drawing.Color.White;
            this.label_addmb_ph.Location = new System.Drawing.Point(0, 0);
            this.label_addmb_ph.Name = "label_addmb_ph";
            this.label_addmb_ph.Size = new System.Drawing.Size(58, 21);
            this.label_addmb_ph.TabIndex = 2;
            this.label_addmb_ph.Text = "PH";
            this.label_addmb_ph.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.tbox_addmb_pw);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(71, 63);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(144, 21);
            this.panel20.TabIndex = 7;
            // 
            // tbox_addmb_pw
            // 
            this.tbox_addmb_pw.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_addmb_pw.Location = new System.Drawing.Point(0, 0);
            this.tbox_addmb_pw.MaxLength = 12;
            this.tbox_addmb_pw.Name = "tbox_addmb_pw";
            this.tbox_addmb_pw.PasswordChar = '*';
            this.tbox_addmb_pw.Size = new System.Drawing.Size(144, 21);
            this.tbox_addmb_pw.TabIndex = 1;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.label_addmb_pw);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(5, 63);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(58, 21);
            this.panel19.TabIndex = 6;
            // 
            // label_addmb_pw
            // 
            this.label_addmb_pw.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_addmb_pw.ForeColor = System.Drawing.Color.White;
            this.label_addmb_pw.Location = new System.Drawing.Point(0, 0);
            this.label_addmb_pw.Name = "label_addmb_pw";
            this.label_addmb_pw.Size = new System.Drawing.Size(58, 21);
            this.label_addmb_pw.TabIndex = 1;
            this.label_addmb_pw.Text = "PW";
            this.label_addmb_pw.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.tbox_addmb_id);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(71, 34);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(144, 21);
            this.panel18.TabIndex = 5;
            // 
            // tbox_addmb_id
            // 
            this.tbox_addmb_id.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_addmb_id.Location = new System.Drawing.Point(0, 0);
            this.tbox_addmb_id.MaxLength = 20;
            this.tbox_addmb_id.Name = "tbox_addmb_id";
            this.tbox_addmb_id.Size = new System.Drawing.Size(144, 21);
            this.tbox_addmb_id.TabIndex = 2;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.label_addmb_id);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(5, 34);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(58, 21);
            this.panel17.TabIndex = 4;
            // 
            // label_addmb_id
            // 
            this.label_addmb_id.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_addmb_id.ForeColor = System.Drawing.Color.White;
            this.label_addmb_id.Location = new System.Drawing.Point(0, 0);
            this.label_addmb_id.Name = "label_addmb_id";
            this.label_addmb_id.Size = new System.Drawing.Size(58, 21);
            this.label_addmb_id.TabIndex = 1;
            this.label_addmb_id.Text = "ID";
            this.label_addmb_id.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.tbox_addmb_name);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(71, 5);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(144, 21);
            this.panel16.TabIndex = 3;
            // 
            // tbox_addmb_name
            // 
            this.tbox_addmb_name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_addmb_name.Location = new System.Drawing.Point(0, 0);
            this.tbox_addmb_name.MaxLength = 5;
            this.tbox_addmb_name.Name = "tbox_addmb_name";
            this.tbox_addmb_name.Size = new System.Drawing.Size(144, 21);
            this.tbox_addmb_name.TabIndex = 1;
            this.tbox_addmb_name.WordWrap = false;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label_addmb_name);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(5, 5);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(58, 21);
            this.panel15.TabIndex = 2;
            // 
            // label_addmb_name
            // 
            this.label_addmb_name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_addmb_name.ForeColor = System.Drawing.Color.White;
            this.label_addmb_name.Location = new System.Drawing.Point(0, 0);
            this.label_addmb_name.Name = "label_addmb_name";
            this.label_addmb_name.Size = new System.Drawing.Size(58, 21);
            this.label_addmb_name.TabIndex = 1;
            this.label_addmb_name.Text = "이름";
            this.label_addmb_name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label_addmb_birthdate);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(5, 121);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(58, 21);
            this.panel1.TabIndex = 16;
            // 
            // label_addmb_birthdate
            // 
            this.label_addmb_birthdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_addmb_birthdate.ForeColor = System.Drawing.Color.White;
            this.label_addmb_birthdate.Location = new System.Drawing.Point(0, 0);
            this.label_addmb_birthdate.Name = "label_addmb_birthdate";
            this.label_addmb_birthdate.Size = new System.Drawing.Size(58, 21);
            this.label_addmb_birthdate.TabIndex = 2;
            this.label_addmb_birthdate.Text = "생년월일";
            this.label_addmb_birthdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.label_addmb_title);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Padding = new System.Windows.Forms.Padding(3);
            this.panel11.Size = new System.Drawing.Size(419, 35);
            this.panel11.TabIndex = 1;
            // 
            // label_addmb_title
            // 
            this.label_addmb_title.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_addmb_title.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_addmb_title.Location = new System.Drawing.Point(3, 3);
            this.label_addmb_title.Name = "label_addmb_title";
            this.label_addmb_title.Size = new System.Drawing.Size(411, 27);
            this.label_addmb_title.TabIndex = 0;
            this.label_addmb_title.Text = "회원추가";
            this.label_addmb_title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MBM_add_member
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(421, 211);
            this.Controls.Add(this.panel7);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MBM_add_member";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "회원추가";
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.table_addmb.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TableLayoutPanel table_addmb;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox tbox_addmb_pw;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label_addmb_pw;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox tbox_addmb_id;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label_addmb_id;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox tbox_addmb_name;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label_addmb_name;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label_addmb_title;
        private System.Windows.Forms.Button btn_addmb_id_doubleck;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label_addmb_newdate;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker date_addmb_birthdate;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.DateTimePicker date_addmb_newdate;
        private System.Windows.Forms.TextBox tbox_addmb_ph;
        private System.Windows.Forms.Label label_addmb_ph;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_addmb_birthdate;
        private System.Windows.Forms.Label label_addmb_pw_mess;
        private System.Windows.Forms.Label label_addmb_ph_mess;
        private System.Windows.Forms.Label label_addmb_name_mess;
        private System.Windows.Forms.Button btn_addmb_save;
    }
}