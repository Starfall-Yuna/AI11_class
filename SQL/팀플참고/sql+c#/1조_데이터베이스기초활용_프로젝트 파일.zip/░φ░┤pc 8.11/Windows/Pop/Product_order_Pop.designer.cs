﻿namespace mainPC.Windows.mainPC.상품관리 {
    partial class Product_order_Pop {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_beverage = new System.Windows.Forms.Button();
            this.btn_snack = new System.Windows.Forms.Button();
            this.btn_ramen = new System.Windows.Forms.Button();
            this.btn_etc = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel_goods = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.grid_main2 = new System.Windows.Forms.DataGridView();
            this.grid_select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.cartgoodsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cartgoodscountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cartorderpriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DisplaySet = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.p_name = new System.Data.DataColumn();
            this.p_price = new System.Data.DataColumn();
            this.p_memo = new System.Data.DataColumn();
            this.p_picture = new System.Data.DataColumn();
            this.p_category = new System.Data.DataColumn();
            this.dataTable3 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.소계 = new System.Data.DataColumn();
            this.선택 = new System.Data.DataColumn();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.tbox_result = new System.Windows.Forms.TextBox();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pbox_picture = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.tbox_name = new System.Windows.Forms.TextBox();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.tbox_price = new System.Windows.Forms.TextBox();
            this.panel31 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.tbox_memo = new System.Windows.Forms.RichTextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label_selected_price = new System.Windows.Forms.Label();
            this.tbox_amount = new System.Windows.Forms.TextBox();
            this.btn_select = new System.Windows.Forms.Button();
            this.btn_amount_plus = new System.Windows.Forms.Button();
            this.btn_amount_minus = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.tbox_hope = new System.Windows.Forms.RichTextBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btn_order_product = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.btn_close = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_main2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).BeginInit();
            this.panel23.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_picture)).BeginInit();
            this.panel7.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel17.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(911, 94);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel20);
            this.panel3.Controls.Add(this.panel21);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 53);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(911, 41);
            this.panel3.TabIndex = 1;
            // 
            // panel20
            // 
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.label7);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(603, 0);
            this.panel20.Name = "panel20";
            this.panel20.Padding = new System.Windows.Forms.Padding(3);
            this.panel20.Size = new System.Drawing.Size(308, 41);
            this.panel20.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(23, 3);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(136, 35);
            this.label7.TabIndex = 8;
            this.label7.Text = "상품상세정보";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.tableLayoutPanel4);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(603, 41);
            this.panel21.TabIndex = 7;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel4.ColumnCount = 5;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.Controls.Add(this.btn_all, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_beverage, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_snack, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_ramen, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.btn_etc, 4, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(603, 41);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // btn_all
            // 
            this.btn_all.BackColor = System.Drawing.Color.Black;
            this.btn_all.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_all.ForeColor = System.Drawing.Color.Yellow;
            this.btn_all.Location = new System.Drawing.Point(4, 4);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(113, 33);
            this.btn_all.TabIndex = 0;
            this.btn_all.Text = "전체";
            this.btn_all.UseVisualStyleBackColor = false;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_beverage
            // 
            this.btn_beverage.BackColor = System.Drawing.Color.Black;
            this.btn_beverage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_beverage.ForeColor = System.Drawing.Color.Yellow;
            this.btn_beverage.Location = new System.Drawing.Point(124, 4);
            this.btn_beverage.Name = "btn_beverage";
            this.btn_beverage.Size = new System.Drawing.Size(113, 33);
            this.btn_beverage.TabIndex = 1;
            this.btn_beverage.Text = "음료";
            this.btn_beverage.UseVisualStyleBackColor = false;
            this.btn_beverage.Click += new System.EventHandler(this.btn_beverage_Click);
            // 
            // btn_snack
            // 
            this.btn_snack.BackColor = System.Drawing.Color.Black;
            this.btn_snack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_snack.ForeColor = System.Drawing.Color.Yellow;
            this.btn_snack.Location = new System.Drawing.Point(244, 4);
            this.btn_snack.Name = "btn_snack";
            this.btn_snack.Size = new System.Drawing.Size(113, 33);
            this.btn_snack.TabIndex = 2;
            this.btn_snack.Text = "과자";
            this.btn_snack.UseVisualStyleBackColor = false;
            this.btn_snack.Click += new System.EventHandler(this.btn_snack_Click);
            // 
            // btn_ramen
            // 
            this.btn_ramen.BackColor = System.Drawing.Color.Black;
            this.btn_ramen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_ramen.ForeColor = System.Drawing.Color.Yellow;
            this.btn_ramen.Location = new System.Drawing.Point(364, 4);
            this.btn_ramen.Name = "btn_ramen";
            this.btn_ramen.Size = new System.Drawing.Size(113, 33);
            this.btn_ramen.TabIndex = 3;
            this.btn_ramen.Text = "라면";
            this.btn_ramen.UseVisualStyleBackColor = false;
            this.btn_ramen.Click += new System.EventHandler(this.btn_ramen_Click);
            // 
            // btn_etc
            // 
            this.btn_etc.BackColor = System.Drawing.Color.Black;
            this.btn_etc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_etc.ForeColor = System.Drawing.Color.Yellow;
            this.btn_etc.Location = new System.Drawing.Point(484, 4);
            this.btn_etc.Name = "btn_etc";
            this.btn_etc.Size = new System.Drawing.Size(115, 33);
            this.btn_etc.TabIndex = 4;
            this.btn_etc.Text = "기타";
            this.btn_etc.UseVisualStyleBackColor = false;
            this.btn_etc.Click += new System.EventHandler(this.btn_etc_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(911, 53);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 50);
            this.label1.TabIndex = 0;
            this.label1.Text = "< 음식 주문 >";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel_goods);
            this.panel4.Controls.Add(this.panel11);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 94);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(603, 543);
            this.panel4.TabIndex = 1;
            // 
            // panel_goods
            // 
            this.panel_goods.AutoScroll = true;
            this.panel_goods.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_goods.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_goods.Location = new System.Drawing.Point(0, 0);
            this.panel_goods.Name = "panel_goods";
            this.panel_goods.Size = new System.Drawing.Size(603, 404);
            this.panel_goods.TabIndex = 2;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.tableLayoutPanel2);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel11.Location = new System.Drawing.Point(0, 404);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(603, 139);
            this.panel11.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.80699F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.19301F));
            this.tableLayoutPanel2.Controls.Add(this.panel16, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel22, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel23, 1, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75.18248F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.81752F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(601, 137);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.label10);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(4, 4);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(88, 94);
            this.panel16.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(0, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 94);
            this.label10.TabIndex = 7;
            this.label10.Text = "주문목록";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.grid_main2);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(99, 4);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(498, 94);
            this.panel22.TabIndex = 2;
            // 
            // grid_main2
            // 
            this.grid_main2.AllowUserToAddRows = false;
            this.grid_main2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.DarkGray;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Yellow;
            this.grid_main2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.grid_main2.AutoGenerateColumns = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Yellow;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_main2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.grid_main2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_main2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.grid_select,
            this.cartgoodsnameDataGridViewTextBoxColumn,
            this.cartgoodscountDataGridViewTextBoxColumn,
            this.cartorderpriceDataGridViewTextBoxColumn});
            this.grid_main2.DataMember = "product_cart";
            this.grid_main2.DataSource = this.DisplaySet;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Yellow;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_main2.DefaultCellStyle = dataGridViewCellStyle3;
            this.grid_main2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_main2.EnableHeadersVisualStyles = false;
            this.grid_main2.Location = new System.Drawing.Point(0, 0);
            this.grid_main2.Name = "grid_main2";
            this.grid_main2.RowHeadersVisible = false;
            this.grid_main2.RowTemplate.Height = 23;
            this.grid_main2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_main2.Size = new System.Drawing.Size(498, 94);
            this.grid_main2.TabIndex = 0;
            // 
            // grid_select
            // 
            this.grid_select.DataPropertyName = "grid_select";
            this.grid_select.HeaderText = "선택";
            this.grid_select.Name = "grid_select";
            this.grid_select.Width = 60;
            // 
            // cartgoodsnameDataGridViewTextBoxColumn
            // 
            this.cartgoodsnameDataGridViewTextBoxColumn.DataPropertyName = "cart_goodsname";
            this.cartgoodsnameDataGridViewTextBoxColumn.HeaderText = "상품명";
            this.cartgoodsnameDataGridViewTextBoxColumn.Name = "cartgoodsnameDataGridViewTextBoxColumn";
            this.cartgoodsnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cartgoodscountDataGridViewTextBoxColumn
            // 
            this.cartgoodscountDataGridViewTextBoxColumn.DataPropertyName = "cart_goodscount";
            this.cartgoodscountDataGridViewTextBoxColumn.HeaderText = "수량";
            this.cartgoodscountDataGridViewTextBoxColumn.Name = "cartgoodscountDataGridViewTextBoxColumn";
            this.cartgoodscountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cartorderpriceDataGridViewTextBoxColumn
            // 
            this.cartorderpriceDataGridViewTextBoxColumn.DataPropertyName = "cart_orderprice";
            this.cartorderpriceDataGridViewTextBoxColumn.HeaderText = "소계";
            this.cartorderpriceDataGridViewTextBoxColumn.Name = "cartorderpriceDataGridViewTextBoxColumn";
            this.cartorderpriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // DisplaySet
            // 
            this.DisplaySet.DataSetName = "NewDataSet";
            this.DisplaySet.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1,
            this.dataTable3});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.p_name,
            this.p_price,
            this.p_memo,
            this.p_picture,
            this.p_category});
            this.dataTable1.TableName = "product_info";
            // 
            // p_name
            // 
            this.p_name.AllowDBNull = false;
            this.p_name.ColumnName = "p_name";
            // 
            // p_price
            // 
            this.p_price.ColumnName = "p_price";
            // 
            // p_memo
            // 
            this.p_memo.ColumnName = "p_memo";
            // 
            // p_picture
            // 
            this.p_picture.ColumnName = "p_picture";
            // 
            // p_category
            // 
            this.p_category.Caption = "p_category";
            this.p_category.ColumnName = "p_category";
            // 
            // dataTable3
            // 
            this.dataTable3.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.소계,
            this.선택});
            this.dataTable3.TableName = "product_cart";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "cart_goodsname";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "cart_goodscount";
            this.dataColumn2.DataType = typeof(int);
            // 
            // 소계
            // 
            this.소계.ColumnName = "cart_orderprice";
            this.소계.DataType = typeof(int);
            // 
            // 선택
            // 
            this.선택.ColumnName = "grid_select";
            this.선택.DataType = typeof(bool);
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.label2);
            this.panel23.Controls.Add(this.tbox_result);
            this.panel23.Controls.Add(this.btn_cancel);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(99, 105);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(498, 28);
            this.panel23.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(327, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "합계";
            // 
            // tbox_result
            // 
            this.tbox_result.Enabled = false;
            this.tbox_result.Location = new System.Drawing.Point(362, 3);
            this.tbox_result.Name = "tbox_result";
            this.tbox_result.Size = new System.Drawing.Size(119, 21);
            this.tbox_result.TabIndex = 1;
            this.tbox_result.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.Black;
            this.btn_cancel.ForeColor = System.Drawing.Color.Yellow;
            this.btn_cancel.Location = new System.Drawing.Point(3, 3);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_cancel.TabIndex = 0;
            this.btn_cancel.Text = "선택취소";
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel10);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(603, 94);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(308, 543);
            this.panel5.TabIndex = 2;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.pbox_picture);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(308, 259);
            this.panel6.TabIndex = 5;
            // 
            // pbox_picture
            // 
            this.pbox_picture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbox_picture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbox_picture.Enabled = false;
            this.pbox_picture.Location = new System.Drawing.Point(0, 0);
            this.pbox_picture.Name = "pbox_picture";
            this.pbox_picture.Size = new System.Drawing.Size(308, 259);
            this.pbox_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_picture.TabIndex = 8;
            this.pbox_picture.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.tableLayoutPanel3);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(0, 259);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(308, 113);
            this.panel7.TabIndex = 4;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.87625F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.12375F));
            this.tableLayoutPanel3.Controls.Add(this.panel19, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel27, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel28, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.panel30, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.panel31, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.panel32, 1, 2);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(308, 113);
            this.tableLayoutPanel3.TabIndex = 14;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.label9);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(4, 4);
            this.panel19.Name = "panel19";
            this.panel19.Padding = new System.Windows.Forms.Padding(3);
            this.panel19.Size = new System.Drawing.Size(97, 19);
            this.panel19.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(3, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "상품명";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.tbox_name);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(108, 4);
            this.panel27.Name = "panel27";
            this.panel27.Padding = new System.Windows.Forms.Padding(1);
            this.panel27.Size = new System.Drawing.Size(196, 19);
            this.panel27.TabIndex = 1;
            // 
            // tbox_name
            // 
            this.tbox_name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_name.Location = new System.Drawing.Point(1, 1);
            this.tbox_name.Name = "tbox_name";
            this.tbox_name.ReadOnly = true;
            this.tbox_name.Size = new System.Drawing.Size(194, 21);
            this.tbox_name.TabIndex = 0;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.label13);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel28.Location = new System.Drawing.Point(4, 30);
            this.panel28.Name = "panel28";
            this.panel28.Padding = new System.Windows.Forms.Padding(3);
            this.panel28.Size = new System.Drawing.Size(97, 19);
            this.panel28.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(3, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "가격";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.tbox_price);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel30.Location = new System.Drawing.Point(108, 30);
            this.panel30.Name = "panel30";
            this.panel30.Padding = new System.Windows.Forms.Padding(1);
            this.panel30.Size = new System.Drawing.Size(196, 19);
            this.panel30.TabIndex = 3;
            // 
            // tbox_price
            // 
            this.tbox_price.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_price.Location = new System.Drawing.Point(1, 1);
            this.tbox_price.Name = "tbox_price";
            this.tbox_price.ReadOnly = true;
            this.tbox_price.Size = new System.Drawing.Size(194, 21);
            this.tbox_price.TabIndex = 0;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.label14);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel31.Location = new System.Drawing.Point(4, 56);
            this.panel31.Name = "panel31";
            this.panel31.Padding = new System.Windows.Forms.Padding(3);
            this.panel31.Size = new System.Drawing.Size(97, 53);
            this.panel31.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(3, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 47);
            this.label14.TabIndex = 0;
            this.label14.Text = "메모";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.tbox_memo);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Location = new System.Drawing.Point(108, 56);
            this.panel32.Name = "panel32";
            this.panel32.Padding = new System.Windows.Forms.Padding(1);
            this.panel32.Size = new System.Drawing.Size(196, 53);
            this.panel32.TabIndex = 5;
            // 
            // tbox_memo
            // 
            this.tbox_memo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbox_memo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_memo.Location = new System.Drawing.Point(1, 1);
            this.tbox_memo.Name = "tbox_memo";
            this.tbox_memo.ReadOnly = true;
            this.tbox_memo.Size = new System.Drawing.Size(194, 51);
            this.tbox_memo.TabIndex = 0;
            this.tbox_memo.Text = "";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label3);
            this.panel8.Controls.Add(this.label_selected_price);
            this.panel8.Controls.Add(this.tbox_amount);
            this.panel8.Controls.Add(this.btn_select);
            this.panel8.Controls.Add(this.btn_amount_plus);
            this.panel8.Controls.Add(this.btn_amount_minus);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 372);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(308, 32);
            this.panel8.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(202, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 21);
            this.label3.TabIndex = 9;
            this.label3.Tag = "price*amount 원";
            this.label3.Text = "원";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_selected_price
            // 
            this.label_selected_price.Location = new System.Drawing.Point(111, 5);
            this.label_selected_price.Name = "label_selected_price";
            this.label_selected_price.Size = new System.Drawing.Size(85, 21);
            this.label_selected_price.TabIndex = 8;
            this.label_selected_price.Tag = "price*amount 원";
            this.label_selected_price.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbox_amount
            // 
            this.tbox_amount.Location = new System.Drawing.Point(42, 6);
            this.tbox_amount.Name = "tbox_amount";
            this.tbox_amount.Size = new System.Drawing.Size(28, 21);
            this.tbox_amount.TabIndex = 7;
            this.tbox_amount.Text = "1";
            this.tbox_amount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_select
            // 
            this.btn_select.BackColor = System.Drawing.Color.Black;
            this.btn_select.ForeColor = System.Drawing.Color.Yellow;
            this.btn_select.Location = new System.Drawing.Point(224, 4);
            this.btn_select.Name = "btn_select";
            this.btn_select.Size = new System.Drawing.Size(75, 23);
            this.btn_select.TabIndex = 6;
            this.btn_select.Text = "선택";
            this.btn_select.UseVisualStyleBackColor = false;
            this.btn_select.Click += new System.EventHandler(this.btn_select_Click);
            // 
            // btn_amount_plus
            // 
            this.btn_amount_plus.Location = new System.Drawing.Point(77, 5);
            this.btn_amount_plus.Name = "btn_amount_plus";
            this.btn_amount_plus.Size = new System.Drawing.Size(28, 22);
            this.btn_amount_plus.TabIndex = 5;
            this.btn_amount_plus.Text = "+";
            this.btn_amount_plus.UseVisualStyleBackColor = true;
            this.btn_amount_plus.Click += new System.EventHandler(this.btn_amount_plus_Click);
            // 
            // btn_amount_minus
            // 
            this.btn_amount_minus.Location = new System.Drawing.Point(9, 5);
            this.btn_amount_minus.Name = "btn_amount_minus";
            this.btn_amount_minus.Size = new System.Drawing.Size(28, 22);
            this.btn_amount_minus.TabIndex = 4;
            this.btn_amount_minus.Text = "-";
            this.btn_amount_minus.UseVisualStyleBackColor = true;
            this.btn_amount_minus.Click += new System.EventHandler(this.btn_amount_minus_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel13);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel9.Location = new System.Drawing.Point(0, 404);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(308, 100);
            this.panel9.TabIndex = 2;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.panel15);
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(308, 100);
            this.panel13.TabIndex = 2;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.tbox_hope);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(63, 0);
            this.panel15.Name = "panel15";
            this.panel15.Padding = new System.Windows.Forms.Padding(3);
            this.panel15.Size = new System.Drawing.Size(245, 100);
            this.panel15.TabIndex = 1;
            // 
            // tbox_hope
            // 
            this.tbox_hope.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbox_hope.Location = new System.Drawing.Point(3, 3);
            this.tbox_hope.MaxLength = 100;
            this.tbox_hope.Name = "tbox_hope";
            this.tbox_hope.Size = new System.Drawing.Size(239, 94);
            this.tbox_hope.TabIndex = 1;
            this.tbox_hope.Text = "";
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label8);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Name = "panel14";
            this.panel14.Padding = new System.Windows.Forms.Padding(3);
            this.panel14.Size = new System.Drawing.Size(63, 100);
            this.panel14.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Gray;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(3, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 94);
            this.label8.TabIndex = 0;
            this.label8.Text = "요청사항";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.tableLayoutPanel1);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(0, 504);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(308, 39);
            this.panel10.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel12, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel17, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(308, 39);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.btn_order_product);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(3, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(148, 33);
            this.panel12.TabIndex = 0;
            // 
            // btn_order_product
            // 
            this.btn_order_product.BackColor = System.Drawing.Color.Black;
            this.btn_order_product.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_order_product.ForeColor = System.Drawing.Color.Yellow;
            this.btn_order_product.Location = new System.Drawing.Point(0, 0);
            this.btn_order_product.Name = "btn_order_product";
            this.btn_order_product.Size = new System.Drawing.Size(148, 33);
            this.btn_order_product.TabIndex = 0;
            this.btn_order_product.Text = "상품주문";
            this.btn_order_product.UseVisualStyleBackColor = false;
            this.btn_order_product.Click += new System.EventHandler(this.btn_order_product_Click);
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.btn_close);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(157, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(148, 33);
            this.panel17.TabIndex = 1;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Black;
            this.btn_close.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_close.ForeColor = System.Drawing.Color.Yellow;
            this.btn_close.Location = new System.Drawing.Point(0, 0);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(148, 33);
            this.btn_close.TabIndex = 1;
            this.btn_close.Text = "닫기";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // Product_order_Pop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(911, 637);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Product_order_Pop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product_order_Pop";
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_main2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DisplaySet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).EndInit();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_picture)).EndInit();
            this.panel7.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label7;
        private System.Data.DataColumn p_category;
        private System.Data.DataColumn p_picture;
        private System.Data.DataColumn p_memo;
        private System.Data.DataColumn p_price;
        private System.Data.DataColumn p_name;
        private System.Data.DataTable dataTable1;
        private System.Data.DataSet DisplaySet;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_beverage;
        private System.Windows.Forms.Button btn_snack;
        private System.Windows.Forms.Button btn_ramen;
        private System.Windows.Forms.Button btn_etc;
        private System.Windows.Forms.Panel panel_goods;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pbox_picture;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.TextBox tbox_name;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.TextBox tbox_price;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.RichTextBox tbox_memo;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox tbox_amount;
        private System.Windows.Forms.Button btn_select;
        private System.Windows.Forms.Button btn_amount_plus;
        private System.Windows.Forms.Button btn_amount_minus;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.RichTextBox tbox_hope;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button btn_order_product;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Label label_selected_price;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.DataGridView grid_main2;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbox_result;
        private System.Data.DataTable dataTable3;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn 소계;
        private System.Data.DataColumn 선택;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn grid_select;
        private System.Windows.Forms.DataGridViewTextBoxColumn cartgoodsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cartgoodscountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cartorderpriceDataGridViewTextBoxColumn;
    }
}