﻿namespace Player_pc.Windows.Pop {
    partial class AddTimePop {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.Addtime10 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.Addtime9 = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.Addtime8 = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.Addtime7 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.Addtime6 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Addtime5 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.Addtime4 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Addtime3 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Addtime2 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Addtime1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(5);
            this.panel1.Size = new System.Drawing.Size(383, 58);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(5, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(373, 48);
            this.panel3.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("한컴산뜻돋움", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.LiveSetting = System.Windows.Forms.Automation.AutomationLiveSetting.Polite;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(373, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "시간 추가";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter1.Location = new System.Drawing.Point(5, 63);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(383, 3);
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(5, 66);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(5);
            this.panel2.Size = new System.Drawing.Size(383, 314);
            this.panel2.TabIndex = 2;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel13, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel12, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel11, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel10, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel9, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel8, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(5, 5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(373, 304);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.Addtime10);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(189, 240);
            this.panel13.Name = "panel13";
            this.panel13.Padding = new System.Windows.Forms.Padding(5);
            this.panel13.Size = new System.Drawing.Size(176, 56);
            this.panel13.TabIndex = 9;
            // 
            // Addtime10
            // 
            this.Addtime10.BackColor = System.Drawing.Color.Black;
            this.Addtime10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Addtime10.ForeColor = System.Drawing.Color.Yellow;
            this.Addtime10.Location = new System.Drawing.Point(5, 5);
            this.Addtime10.Name = "Addtime10";
            this.Addtime10.Size = new System.Drawing.Size(166, 46);
            this.Addtime10.TabIndex = 1;
            this.Addtime10.Text = "10시간 추가  \\10,000 ";
            this.Addtime10.UseVisualStyleBackColor = false;
            this.Addtime10.Click += new System.EventHandler(this.Addtime10_Click);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.Addtime9);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(8, 240);
            this.panel12.Name = "panel12";
            this.panel12.Padding = new System.Windows.Forms.Padding(5);
            this.panel12.Size = new System.Drawing.Size(175, 56);
            this.panel12.TabIndex = 8;
            // 
            // Addtime9
            // 
            this.Addtime9.BackColor = System.Drawing.Color.Black;
            this.Addtime9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Addtime9.ForeColor = System.Drawing.Color.Yellow;
            this.Addtime9.Location = new System.Drawing.Point(5, 5);
            this.Addtime9.Name = "Addtime9";
            this.Addtime9.Size = new System.Drawing.Size(165, 46);
            this.Addtime9.TabIndex = 1;
            this.Addtime9.Text = "9시간 추가  \\9,000 ";
            this.Addtime9.UseVisualStyleBackColor = false;
            this.Addtime9.Click += new System.EventHandler(this.Addtime9_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.Addtime8);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(189, 182);
            this.panel11.Name = "panel11";
            this.panel11.Padding = new System.Windows.Forms.Padding(5);
            this.panel11.Size = new System.Drawing.Size(176, 52);
            this.panel11.TabIndex = 7;
            // 
            // Addtime8
            // 
            this.Addtime8.BackColor = System.Drawing.Color.Black;
            this.Addtime8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Addtime8.ForeColor = System.Drawing.Color.Yellow;
            this.Addtime8.Location = new System.Drawing.Point(5, 5);
            this.Addtime8.Name = "Addtime8";
            this.Addtime8.Size = new System.Drawing.Size(166, 42);
            this.Addtime8.TabIndex = 1;
            this.Addtime8.Text = "8시간 추가  \\8,000 ";
            this.Addtime8.UseVisualStyleBackColor = false;
            this.Addtime8.Click += new System.EventHandler(this.Addtime8_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.Addtime7);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(8, 182);
            this.panel10.Name = "panel10";
            this.panel10.Padding = new System.Windows.Forms.Padding(5);
            this.panel10.Size = new System.Drawing.Size(175, 52);
            this.panel10.TabIndex = 6;
            // 
            // Addtime7
            // 
            this.Addtime7.BackColor = System.Drawing.Color.Black;
            this.Addtime7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Addtime7.ForeColor = System.Drawing.Color.Yellow;
            this.Addtime7.Location = new System.Drawing.Point(5, 5);
            this.Addtime7.Name = "Addtime7";
            this.Addtime7.Size = new System.Drawing.Size(165, 42);
            this.Addtime7.TabIndex = 1;
            this.Addtime7.Text = "7시간 추가  \\7,000 ";
            this.Addtime7.UseVisualStyleBackColor = false;
            this.Addtime7.Click += new System.EventHandler(this.Addtime7_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.Addtime6);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(189, 124);
            this.panel9.Name = "panel9";
            this.panel9.Padding = new System.Windows.Forms.Padding(5);
            this.panel9.Size = new System.Drawing.Size(176, 52);
            this.panel9.TabIndex = 5;
            // 
            // Addtime6
            // 
            this.Addtime6.BackColor = System.Drawing.Color.Black;
            this.Addtime6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Addtime6.ForeColor = System.Drawing.Color.Yellow;
            this.Addtime6.Location = new System.Drawing.Point(5, 5);
            this.Addtime6.Name = "Addtime6";
            this.Addtime6.Size = new System.Drawing.Size(166, 42);
            this.Addtime6.TabIndex = 1;
            this.Addtime6.Text = "6시간 추가  \\6,000 ";
            this.Addtime6.UseVisualStyleBackColor = false;
            this.Addtime6.Click += new System.EventHandler(this.Addtime6_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.Addtime5);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(8, 124);
            this.panel8.Name = "panel8";
            this.panel8.Padding = new System.Windows.Forms.Padding(5);
            this.panel8.Size = new System.Drawing.Size(175, 52);
            this.panel8.TabIndex = 4;
            // 
            // Addtime5
            // 
            this.Addtime5.BackColor = System.Drawing.Color.Black;
            this.Addtime5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Addtime5.ForeColor = System.Drawing.Color.Yellow;
            this.Addtime5.Location = new System.Drawing.Point(5, 5);
            this.Addtime5.Name = "Addtime5";
            this.Addtime5.Size = new System.Drawing.Size(165, 42);
            this.Addtime5.TabIndex = 1;
            this.Addtime5.Text = "5시간 추가  \\5,000 ";
            this.Addtime5.UseVisualStyleBackColor = false;
            this.Addtime5.Click += new System.EventHandler(this.Addtime5_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.Addtime4);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(189, 66);
            this.panel7.Name = "panel7";
            this.panel7.Padding = new System.Windows.Forms.Padding(5);
            this.panel7.Size = new System.Drawing.Size(176, 52);
            this.panel7.TabIndex = 3;
            // 
            // Addtime4
            // 
            this.Addtime4.BackColor = System.Drawing.Color.Black;
            this.Addtime4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Addtime4.ForeColor = System.Drawing.Color.Yellow;
            this.Addtime4.Location = new System.Drawing.Point(5, 5);
            this.Addtime4.Name = "Addtime4";
            this.Addtime4.Size = new System.Drawing.Size(166, 42);
            this.Addtime4.TabIndex = 1;
            this.Addtime4.Text = "4시간 추가  \\4,000 ";
            this.Addtime4.UseVisualStyleBackColor = false;
            this.Addtime4.Click += new System.EventHandler(this.Addtime4_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.Addtime3);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(8, 66);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(5);
            this.panel6.Size = new System.Drawing.Size(175, 52);
            this.panel6.TabIndex = 2;
            // 
            // Addtime3
            // 
            this.Addtime3.BackColor = System.Drawing.Color.Black;
            this.Addtime3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Addtime3.ForeColor = System.Drawing.Color.Yellow;
            this.Addtime3.Location = new System.Drawing.Point(5, 5);
            this.Addtime3.Name = "Addtime3";
            this.Addtime3.Size = new System.Drawing.Size(165, 42);
            this.Addtime3.TabIndex = 1;
            this.Addtime3.Text = "3시간 추가  \\3,000 ";
            this.Addtime3.UseVisualStyleBackColor = false;
            this.Addtime3.Click += new System.EventHandler(this.Addtime3_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.Addtime2);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(189, 8);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(5);
            this.panel5.Size = new System.Drawing.Size(176, 52);
            this.panel5.TabIndex = 1;
            // 
            // Addtime2
            // 
            this.Addtime2.BackColor = System.Drawing.Color.Black;
            this.Addtime2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Addtime2.ForeColor = System.Drawing.Color.Yellow;
            this.Addtime2.Location = new System.Drawing.Point(5, 5);
            this.Addtime2.Name = "Addtime2";
            this.Addtime2.Size = new System.Drawing.Size(166, 42);
            this.Addtime2.TabIndex = 1;
            this.Addtime2.Text = "2시간 추가  \\2,000 ";
            this.Addtime2.UseVisualStyleBackColor = false;
            this.Addtime2.Click += new System.EventHandler(this.Addtime2_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.Addtime1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(8, 8);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(5);
            this.panel4.Size = new System.Drawing.Size(175, 52);
            this.panel4.TabIndex = 0;
            // 
            // Addtime1
            // 
            this.Addtime1.BackColor = System.Drawing.Color.Black;
            this.Addtime1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Addtime1.ForeColor = System.Drawing.Color.Yellow;
            this.Addtime1.Location = new System.Drawing.Point(5, 5);
            this.Addtime1.Name = "Addtime1";
            this.Addtime1.Size = new System.Drawing.Size(165, 42);
            this.Addtime1.TabIndex = 0;
            this.Addtime1.Text = "1시간 추가  \\1,000 ";
            this.Addtime1.UseVisualStyleBackColor = false;
            this.Addtime1.Click += new System.EventHandler(this.Addtime1_Click);
            // 
            // AddTimePop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(393, 385);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panel1);
            this.Name = "AddTimePop";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddTimePop";
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button Addtime1;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button Addtime10;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button Addtime9;
        private System.Windows.Forms.Button Addtime8;
        private System.Windows.Forms.Button Addtime7;
        private System.Windows.Forms.Button Addtime6;
        private System.Windows.Forms.Button Addtime5;
        private System.Windows.Forms.Button Addtime4;
        private System.Windows.Forms.Button Addtime3;
        private System.Windows.Forms.Button Addtime2;
        private System.Windows.Forms.Label label1;
    }
}